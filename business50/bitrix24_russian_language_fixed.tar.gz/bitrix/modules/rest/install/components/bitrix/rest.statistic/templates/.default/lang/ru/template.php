<?php
$MESS['REST_STATISTIC_GRAPHS_QUERY'] = 'Запросов';
$MESS['REST_STATISTIC_GRAPHS_REMAIN'] = 'Прочее';
$MESS['REST_STATISTIC_GRAPHS_LOT_OF'] = 'Количество пунктов превышает возможное для отображения на графике';
$MESS['REST_STATISTIC_EMPTY_DATA'] = 'Нет данных';