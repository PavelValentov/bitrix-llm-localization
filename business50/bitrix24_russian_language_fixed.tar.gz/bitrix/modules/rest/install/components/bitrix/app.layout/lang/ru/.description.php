<?php
$MESS["RMP_LAYOUT_COMP_NAME_2"] = "Страница приложения";
$MESS["RMP_LAYOUT_COMP_DESCR_2"] = "Страница приложения";
$MESS["RMP_PATH_B24MP_DESCR_2"] = "Битрикс24.Маркет";
$MESS["RMP_PATH_B24MP_DESCR_2_MSGVER_1"] = "Маркетплейс";