<?
$MESS['REST_RSP_CLASS'] = 'Реализующий класс';
?>