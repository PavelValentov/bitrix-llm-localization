<?php

$MESS["REST_AL_ERROR_APP_NOT_FOUND"] = "Приложение не найдено.";
$MESS["REST_AL_ERROR_APP_NOT_INSTALLED"] = "Приложение не установлено. Обратитесь к администратору портала.";
$MESS["REST_AL_ERROR_APP_PLACEMENT_NOT_INSTALLED"] = "Невозможно отобразить приложение в текущем контексте.";
$MESS["REST_AL_ERROR_APP_NOT_FOUND_MARKETPLACE"] = "Приложение не опубликовано в каталоге решений или снято с публикации разработчиком.";
$MESS["REST_AL_ERROR_APP_INSTALL_NOT_FINISH"] = "Приложение ещё не установлено до конца. Обратитесь к администратору вашего Битрикс24, чтобы он завершил установку.";
$MESS["REST_AL_ERROR_APP_NOT_ACCESSIBLE"] = "У вас недостаточно прав для доступа к данному приложению. Обратитесь к администратору вашего Битрикс24.";
$MESS["REST_AL_ERROR_APP_ACCESS_DENIED"] = 'Нет доступа';
$MESS["REST_AL_ERROR_APP_GET_OAUTH_TOKEN"] = 'Ошибка получения токена авторизации';