<?php
$MESS["RMP_VA_ID"] = "ID приложения";
$MESS["RMP_SEF_APPLICATION"] = "Адрес страницы приложения";
$MESS["RMP_DETAIL_URL_2"] = "Шаблон ссылки на страницу приложения";

