<?
$MESS['REST_TAB_SET'] = "Настройки";
$MESS['REST_TAB_TITLE_SET'] = "Настройка параметров модуля";
$MESS['REST_TAB_LOG'] = "Логирование";
$MESS['REST_TAB_TITLE_LOG'] = "Настройка логирования";
$MESS['REST_OPT_ENABLE_MOD_ZIP'] = 'Модуль <a href="https://www.nginx.com/resources/wiki/modules/zip/" target="_blank">mod_zip</a> включен и настроен (требуется для экспорта)';
$MESS['REST_OPT_MAX_IMPORT_SIZE'] = 'Максимальный размер импортируемого файла (МБ)';
$MESS["REST_OPT_ACTIVE"] = "Активность логирования";
$MESS["REST_OPT_ACTIVE_Y"] = "Работает";
$MESS["REST_OPT_ACTIVE_N"] = "Отключено";
$MESS["REST_OPT_SET_ACTIVE"] = "Включить логирование";
$MESS["REST_OPT_CLEAR_DATA"] = "Удалить собранные ранее данные";
$MESS["REST_OPT_ACTIVE_TO"] = "До окончания активности осталось";
$MESS["REST_OPT_LOG_RECS_COUNT"] = "Собрано данных";
$MESS["REST_OPT_SET_IN_ACTIVE"] = "Отключить логирование";
$MESS["REST_OPT_MINUTES"] = "#HOURS#:#MINUTES#:#SECONDS# (часов:минут:секунд)";
$MESS["REST_OPT_INTERVAL_NO"] = "нет";
$MESS["REST_OPT_INTERVAL_600_SEC"] = "на 10 минут";
$MESS["REST_OPT_INTERVAL_3600_SEC"] = "на 1 час";
$MESS["REST_OPT_INTERVAL_24_HOURS"] = "на сутки";
$MESS["REST_OPT_LOG_FILTERS"] = "Настройки фильтрации";
$MESS["REST_OPT_LOG_FILTER_CLIENT_ID"] = "Идентификатор клиента";
$MESS["REST_OPT_LOG_FILTER_PASSWORD_ID"] = "Идентификатор пароля";
$MESS["REST_OPT_LOG_FILTER_SCOPE"] = "Область видимости";
$MESS["REST_OPT_LOG_FILTER_METHOD"] = "Метод";
$MESS["REST_OPT_LOG_FILTER_USER_ID"] = "Идентификатор пользователя";
?>