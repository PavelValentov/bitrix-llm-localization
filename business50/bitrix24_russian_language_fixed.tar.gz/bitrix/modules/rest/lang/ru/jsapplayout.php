<?
$MESS["REST_ALT_USER_SELECT"] = "Выбрать";
?>