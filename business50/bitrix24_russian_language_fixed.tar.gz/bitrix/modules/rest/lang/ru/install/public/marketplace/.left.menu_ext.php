<?php
$MESS["MENU_MARKETPLACE_ALL"] = "Все приложения";
$MESS["MENU_MARKETPLACE_INSTALLED"] = "Установленные";
$MESS["MENU_MARKETPLACE_HOOK"] = "Вебхуки";
$MESS["MENU_MARKETPLACE_LOCAL"] = "Мои приложения";
$MESS["REST_MENU_MARKETPLACE_DEVOPS"] = "Разработчикам";