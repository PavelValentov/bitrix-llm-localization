<?
$MESS['REST_MODULE_NAME'] = "REST API";
$MESS['REST_MODULE_DESCRIPTION'] = "Программный интерфейс для внешних и внутренних приложений";
$MESS['REST_INSTALL_TITLE'] = "Установка модуля \"REST API\"";
$MESS['REST_UNINSTALL_TITLE'] = "Удаление модуля \"REST API\"";
$MESS['REST_MOD_REWRITE_ERROR'] = "Для корректной работы модуля под Apache требуется наличие модуля mod_rewrite!";
$MESS['REST_IBLOCK_NAME_2'] = "Хранилище данных для приложений";
$MESS['REST_IBLOCK_SECTION_NAME'] = "Разделы";
$MESS['REST_IBLOCK_ELEMENT_NAME'] = "Элементы";
?>