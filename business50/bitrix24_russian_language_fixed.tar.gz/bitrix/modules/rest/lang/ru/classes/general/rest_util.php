<?
$MESS['REST_PARAM_METHOD_NAME'] = 'Имя переменной, содержащей название метода';
$MESS['REST_PARAM_PATH'] = 'Формат пути';
$MESS['REST_APP_INSTALL_NOTIFY_TEXT'] = 'Пользователь #USER_NAME# установил приложение #APP_NAME# (#APP_CODE#). <a href="#APP_LINK#">Перейти на страницу приложения</a>';
?>