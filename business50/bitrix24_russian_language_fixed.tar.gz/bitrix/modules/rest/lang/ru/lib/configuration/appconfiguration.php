<?php
$MESS['REST_CONFIGURATION_ERROR_UNKNOWN_APP'] = 'При установке обнаружено неизвестное дополнительное приложение. Обратитесь к автору приложения или конфигурационного файла';
$MESS['REST_CONFIGURATION_ERROR_INSTALL_APP_CONTENT'] = 'Ошибка установки дополнительного приложения';
$MESS['REST_CONFIGURATION_ERROR_INSTALL_APP_CONTENT_DATA'] = 'Ошибка установки дополнительного приложения: #ERROR_MESSAGE# (#ERROR_CODE#)';
