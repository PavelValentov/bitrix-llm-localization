<?php
$MESS["REST_PLACEMENT_DEFAULT_TITLE"] = "Расширение №#ID#";