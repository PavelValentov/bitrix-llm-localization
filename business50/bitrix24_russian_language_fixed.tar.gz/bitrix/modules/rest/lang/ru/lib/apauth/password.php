<?php
$MESS["REST_APP_TITLE"] = "Внешний доступ к REST API";
$MESS["REST_APP_SYSCOMMENT"] = "Внешний доступ для #TITLE#";
$MESS["REST_APP_COMMENT"] = "Сгенерировано автоматически";
$MESS["REST_APP_DESC"] = "Получите пароль для внешних сервисов, использующих REST API.";