<?php

$MESS['REST_MARKET_CONFIG_ACTIVATE_ERROR'] = "Ошибка активации. Обратитесь в <a href='mailto:sales@1c-bitrix.ru'>отдел продаж</a>.";
$MESS['REST_MARKET_ACTIVATE_DEMO_ACCESS_DENIED'] = 'Недостаточно прав, обратитесь к администратору вашего Битрикс24.';
$MESS['REST_MARKET_ACTIVATE_DEMO_NOT_AVAILABLE'] = 'Пробный период недоступен.';
