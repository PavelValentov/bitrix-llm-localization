<?php

$MESS['REST_INTEGRATION_OPTION_SECTION_NAME_MIGRATION'] = 'Импортировать/экспортировать данные';
$MESS['REST_INTEGRATION_OPTION_SECTION_DESCRIPTION_MIGRATION'] = 'Скопируйте из любого внешнего источника данные клиентов, перечень сотрудников, задачи или, наоборот, перенесите данные, накопленные в Битрикс24 во внешнюю систему';

$MESS['REST_INTEGRATION_OPTION_SECTION_NAME_EXTERNAL_SYSTEMS'] = 'Интегрировать с внешними системами';
$MESS['REST_INTEGRATION_OPTION_SECTION_DESCRIPTION_EXTERNAL_SYSTEMS'] = 'Автоматизируйте сбор лидов из формы на сайте, синхронизируйте изменение контактных данных клиентов со складской или бухгалтерской системой';

$MESS['REST_INTEGRATION_OPTION_SECTION_NAME_AUTOMATE_SALES'] = 'Автоматизировать продажи';
$MESS['REST_INTEGRATION_OPTION_SECTION_DESCRIPTION_AUTOMATE_SALES'] = 'Автоматически двигайте лиды и сделки по воронке и проверяйте правильность данных в CRM';

$MESS['REST_INTEGRATION_OPTION_SECTION_NAME_AUTOMATE_CONTROL'] = 'Автоматизировать управление';
$MESS['REST_INTEGRATION_OPTION_SECTION_DESCRIPTION_AUTOMATE_CONTROL'] = 'Автоматически ставьте задачи сотрудникам, информируйте руководство о возникающих проблемах и публикуйте отчеты в живой ленте';

$MESS['REST_INTEGRATION_OPTION_SECTION_NAME_WIDGET'] = 'Встроить виджет';
$MESS['REST_INTEGRATION_OPTION_SECTION_DESCRIPTION_WIDGET'] = 'Кастомизируйте интерфейс Битрикс24: выводите свою информацию прямо в карточке клиента, скрипты продаж - в карточке звонка';

$MESS['REST_INTEGRATION_OPTION_SECTION_NAME_CHAT_BOT'] = 'Добавить чат-бот';
$MESS['REST_INTEGRATION_OPTION_SECTION_DESCRIPTION_CHAT_BOT'] = 'Создайте чатботов, которые будут отправлять нотификации и отчеты сотрудникам прямо в мессенджер';

$MESS['REST_INTEGRATION_OPTION_SECTION_NAME_CUSTOM'] = 'Добавить свою интеграцию';
$MESS['REST_INTEGRATION_OPTION_SECTION_DESCRIPTION_CUSTOM'] = 'Реализуйте свои сценарии получения и изменения данных в Битрикс24';

$MESS['REST_INTEGRATION_OPTION_SECTION_NAME_STANDARD'] = 'Другое';
$MESS['REST_INTEGRATION_OPTION_SECTION_DESCRIPTION_STANDARD'] = 'Создайте входящий вебхук, исходящий вебхук или локальное приложение';
