<?php
$MESS["REST_MARKETPLACE_NOTIFICATION_REST_BUY_MESS"] = 'С 1 января приложения Битрикс24.Маркет и REST будут доступны только на коммерческих тарифах. Подберите нужный тариф заранее со скидкой до 40%. #BTN#';
$MESS["REST_MARKETPLACE_NOTIFICATION_REST_BUY_MESS_MSGVER_1"] = 'С 1 января приложения Маркетплейса и REST будут доступны только на коммерческих тарифах. Подберите нужный тариф заранее со скидкой до 40%.';
$MESS["REST_MARKETPLACE_NOTIFICATION_REST_BUY_BTN"] = 'Подробнее';
$MESS["REST_MARKETPLACE_NOTIFICATION_REST_BUY_URL"] = 'https://goodbye2020.bitrix24.tech/';

$MESS["REST_MARKETPLACE_NOTIFICATION_SUBSCRIPTION_MARKET_DEMO_END_MESS"] = 'Деморежим подписки закончился. На любом коммерческом тарифе вы можете установить до 2 бесплатных приложений. #BTN#';
$MESS["REST_MARKETPLACE_NOTIFICATION_SUBSCRIPTION_MARKET_DEMO_END_MESS_MSGVER_1"] = 'Деморежим подписки закончился. На любом коммерческом тарифе вы можете установить до 2 бесплатных приложений.';
$MESS["REST_MARKETPLACE_NOTIFICATION_SUBSCRIPTION_MARKET_DEMO_END_MESS_MSGVER_2"] = 'Демо-режим подписки на Маркетплейс закончился. Оформите подписку, чтобы продолжить работу с приложениями';
$MESS["REST_MARKETPLACE_NOTIFICATION_SUBSCRIPTION_MARKET_DEMO_END_BTN"] = 'Купить тариф';
$MESS["REST_MARKETPLACE_NOTIFICATION_SUBSCRIPTION_MARKET_DEMO_END_BTN_MSGVER_1"] = 'Оформить подписку';
$MESS["REST_MARKETPLACE_NOTIFICATION_SUBSCRIPTION_MARKET_DEMO_END_URL"] = '/settings/license_all.php';

$MESS["REST_MARKETPLACE_NOTIFICATION_SUBSCRIPTION_MARKET_TARIFF_MARKET_MESS"] = 'Деморежим подписки закончился. Чтобы продолжать пользоваться установленными и другими приложениями, перейдите на расширенный тариф с подпиской. #BTN#';
$MESS["REST_MARKETPLACE_NOTIFICATION_SUBSCRIPTION_MARKET_TARIFF_MARKET_MESS_MSGVER_1"] = 'Деморежим подписки закончился. Чтобы продолжать пользоваться установленными и другими приложениями, перейдите на расширенный тариф с подпиской.';
$MESS["REST_MARKETPLACE_NOTIFICATION_SUBSCRIPTION_MARKET_TARIFF_MARKET_BTN"] = 'Купить';
$MESS["REST_MARKETPLACE_NOTIFICATION_SUBSCRIPTION_MARKET_TARIFF_MARKET_URL"] = '/settings/license_all.php';

$MESS["REST_MARKETPLACE_NOTIFICATION_SUBSCRIPTION_MARKET_TRIAL_END_MESS"] = 'Деморежим подписки закончился. Оформите подписку, чтобы продолжить пользоваться всеми приложениями. #BTN#';
$MESS["REST_MARKETPLACE_NOTIFICATION_SUBSCRIPTION_MARKET_TRIAL_END_MESS_MSGVER_1"] = 'Деморежим подписки закончился. Оформите подписку, чтобы продолжить пользоваться всеми приложениями.';
$MESS["REST_MARKETPLACE_NOTIFICATION_SUBSCRIPTION_MARKET_TRIAL_END_BTN"] = 'Купить подписку';
$MESS["REST_MARKETPLACE_NOTIFICATION_SUBSCRIPTION_MARKET_TRIAL_END_URL"] = '/settings/license_all.php?subscr=o';
$MESS["REST_MARKETPLACE_NOTIFICATION_HOLD_REST_OVERLOAD_MESS"] = 'REST API был частично заблокирован. Пожалуйста, обратитесь в поддержку для решения данной проблемы. #BTN#';
$MESS["REST_MARKETPLACE_NOTIFICATION_HOLD_REST_OVERLOAD_MESS_MSGVER_1"] = 'REST API был частично заблокирован. Пожалуйста, обратитесь в поддержку для решения данной проблемы.';
$MESS["REST_MARKETPLACE_NOTIFICATION_HOLD_REST_OVERLOAD_BTN"] = 'Посмотреть';