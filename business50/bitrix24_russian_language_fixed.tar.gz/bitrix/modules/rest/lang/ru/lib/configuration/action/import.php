<?php
$MESS['REST_CONFIGURATION_IMPORT_ERROR_CONTENT'] = 'Не удалось получить данные файла №#STEP#.';
$MESS['REST_CONFIGURATION_IMPORT_ERROR_SANITIZE_SHORT'] = 'Данные файла №#STEP# признаны опасными.';
