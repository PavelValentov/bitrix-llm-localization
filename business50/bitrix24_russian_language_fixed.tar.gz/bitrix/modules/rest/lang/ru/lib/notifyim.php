<?php
$MESS['REST_NOTIFY_CONFIRM'] = 'Разрешить на час';
$MESS['REST_NOTIFY_DECLINE'] = 'Запретить';
$MESS['REST_APP_INSTALL_REQUEST'] = "Спасибо, что согласились установить приложение \"#APP_NAME#\" по запросу пользователя. Для установки перейдите, пожалуйста, на <a href=\"#APP_URL#\">страницу приложения</a>.";