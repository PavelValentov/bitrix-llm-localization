<?php
$MESS['REST_AP_AUTH_ERROR_LOGOUT_BEFORE'] = 'Чтобы продолжить, вам нужно выйти из своего текущего аккаунта Битрикс24';
