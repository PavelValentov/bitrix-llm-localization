<?php
$MESS["REST_MP_CONFIG_ACTIVATE_ERROR"] = "Ошибка активации. Обратитесь в отдел продаж.";
$MESS["REST_ACTIVATE_DEMO_ACCESS_DENIED"] = "Доступ запрещен. Обратитесь к администратору.";