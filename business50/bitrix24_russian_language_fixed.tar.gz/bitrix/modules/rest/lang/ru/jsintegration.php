<?
$MESS["REST_INTEGRATION_LIST_ERROR_OPEN_URL"] = "Неизвестная ошибка открытия страницы.";
$MESS["REST_INTEGRATION_LIST_OPEN_PROCESS"] = "Интеграция загружается...";