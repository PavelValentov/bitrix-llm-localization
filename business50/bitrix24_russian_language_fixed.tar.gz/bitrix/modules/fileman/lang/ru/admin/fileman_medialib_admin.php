<?
$MESS["FM_ML_NEW_COLLECTION"] = "Новая коллекция";
$MESS["FM_ML_NEW_COLLECTION_TITLE"] = "Создать новую колекцию в медиабиблиотеке";
$MESS["FM_ML_NEW_ITEM"] = "Новый элемент";
$MESS["FM_ML_NEW_ITEM_TITLE"] = "Создать новый элемент в медиабиблиотеке";
$MESS["FM_ML_MASS_UPLOAD"] = "Множественная загрузка";
$MESS["FM_ML_MASS_UPLOAD_TITLE"] = "Загрузка сразу двух и более изображений в коллекцию";
$MESS["FM_ML_ACCESS"] = "Доступ";
$MESS["FM_ML_ACCESS_TITLE"] = "Настроить права доступа для различных коллекций";
$MESS["FM_ML_SEARCH"] = "Поиск";
$MESS["FM_ML_SEARCH_BUT"] = "Искать";
$MESS["FM_ML_SEARCH_BUT_TITLE"] = "Искать элементы медиабиблиотеки";
$MESS["FM_ML_HIDE"] = "Скрыть";
$MESS["FM_ML_HIDE_TITLE"] = "Скрыть результаты поиска";
$MESS["FM_ML_TAGS_CLOUD"] = "Облако тегов";
$MESS["FM_ML_TAGS_CLOUD_TITLE"] = "Показать облако тегов";
$MESS["FM_ML_MANAGE_TYPES"] = "Настроить типы";
$MESS["FM_ML_MANAGE_TYPES_TITLE"] = "Настроить типы содержимого медиабиблиотеки в настройках модуля";
$MESS["FM_ML_SEARCH_TEXT"] = "Поиск...";
$MESS["FM_ML_NEW_ADD"] = "Добавить";
$MESS["FM_ML_SETTINGS"] = "Настройки";
$MESS["ML_MEDIALIB"] = "Медиабиблиотека";
?>