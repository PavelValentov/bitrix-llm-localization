<?
$MESS ['FILEMAN_T_FILES'] = "Файлы";
?>