<?
$MESS["FILEMAN_RENAME_TITLE2"] = "Переименование файла";
$MESS["FILEMAN_RENAME_SAVE"] = "Переименовать";
$MESS["FILEMAN_RENAME_RESET"] = "Сбросить";
$MESS["FILEMAN_RENAME_LIST_EMPTY"] = "Список файлов для переименования пуст";
$MESS["FILEMAN_RENAME_ACCESS_DENIED"] = "Недостаточно прав для изменения параметров доступа к";
$MESS["FILEMAN_RENAME_NEW_NAME"] = "Введите новое название для";
$MESS["FILEMAN_RENAME_ACCESS_ERROR"] = "Недостаточно прав доступа для переименования!";
$MESS["FILEMAN_RENAME_FILE"] = "Файл (папка)";
$MESS["FILEMAN_RENAME_ERROR"] = "Ошибка при переименовании";
$MESS["FILEMAN_RENAME_IN"] = "в";
$MESS["FILEMAN_RENAME_NOT_FOUND"] = "не найден(а)";
$MESS["FILEMAN_RENAME_TOPHPFILE_ERROR"] = "Недостаточно прав для переименования из неисполняемого файла в файл PHP.";
$MESS["FILEMAN_RENAME_FROMPHPFILE_ERROR"] = "Недостаточно прав для переименования из PHP файла в неисполняемый файл.";
$MESS["FILEMAN_RENAME_FILE_EXISTS"] = "Файл с таким именем уже существует!";
?>