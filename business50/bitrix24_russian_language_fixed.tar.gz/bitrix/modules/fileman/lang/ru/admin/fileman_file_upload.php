<?
$MESS ['FILEMAN_FILEUPLOAD_NAME'] = "Имя файла";
$MESS ['FILEMAN_FILEUPLOAD_FILE'] = "Файл для загрузки";
$MESS ['FILEMAN_FILEUPLOAD_UPLOAD'] = "Загрузить файлы";
$MESS ['FILEMAN_FILEUPLOAD_ACCESS_DENIED'] = "Недостаточно прав для создания файла";
$MESS ['FILEMAN_FILEUPLOAD_SIZE_ERROR'] = "Превышен максимальный допустимый размер для загружаемого файла: \"#FILE_NAME#\"";
$MESS ['FILEMAN_FILEUPLOAD_FILE_EXISTS1'] = "Файл с именем";
$MESS ['FILEMAN_FILEUPLOAD_FILE_EXISTS2'] = "уже существует";
$MESS ['FILEMAN_FILEUPLOAD_FILE_CREATE_ERROR'] = "Ошибка при создании файла";
$MESS ['FILEMAN_FILEUPLOAD_PHPERROR'] = "Недостаточно прав для загрузки PHP файла";
$MESS ['FILEMAN_FILE_UPLOAD_TITLE'] = "Загрузка файлов";
$MESS ['FILEMAN_UPL_TAB'] = "Загрузка файлов";
$MESS ['FILEMAN_UPL_TAB_ALT'] = "Загрузка файлов";
?>