<?
$MESS ['FILEMAN_SERV_ACCESS_TITLE'] = "Права на доступ сервера";
$MESS ['FILEMAN_SA_TAB'] = "Права на доступ сервера";
$MESS ['FILEMAN_SA_TAB_ALT'] = "Установка прав сервера на файлы и папки (ОС Unix/Linux)";
$MESS ['FILEMAN_SA_WINDOWS_WARN'] = "Данный функционал недоступен для ОС Microsoft Windows";
$MESS ['FILEMAN_SA_BACK_2_FOLDER'] = "Назад в папку";
$MESS ['FILEMAN_SA_BACK_2_SEARCH_RES'] = "Назад к результатам поиска";

$MESS ['FILEMAN_SA_CHANGE_TO'] = "Изменение прав доступа на файлы/папки";
$MESS ['FILEMAN_SA_CUR_VAL'] = "Текущее значение";
$MESS ['FILEMAN_SA_CUR_VALUE_DIFF'] = "Внимание! Значения прав доступа отличаются для рассматриваемых файлов(папок)!";

$MESS ['FM_SA_OWNER'] = "Владелец";
$MESS ['FM_SA_GROUP'] = "Группа";
$MESS ['FM_SA_PUBLIC'] = "Все";
$MESS ['FM_SA_READ'] = "Чтение";
$MESS ['FM_SA_WRITE'] = "Запись";
$MESS ['FM_SA_EXECUTE'] = "Выполнение";
$MESS ['FM_SA_VALUE'] = "Значение";
$MESS ['FM_SA_RES_VALUE'] = "Итоговое значение";
$MESS ['FM_SA_SET_RECURCIVE'] = "Установить рекурсивно для всех файлов и папок";

$MESS ['FM_SA_SET_NEW'] = "Установить новое значение";
$MESS ['FM_SA_SUCCESS_NOTE'] = "Изменение прав для всех выбранные файлов и папок успешно завершено.";
$MESS ['FM_SA_FILE_PATH'] = "Путь";
$MESS ['FM_SA_CUR_VAL'] = "Текущее значение";
$MESS ['FM_SA_CHANGE_STATUS'] = "Статус изменения";
$MESS ['FM_SA_SEARCH_RESULT'] = "Результаты поиска";
$MESS ['FM_SA_ERRORS_NOTE'] = "При изменении прав на следующие файлы (папки) произошли ошибки";
?>