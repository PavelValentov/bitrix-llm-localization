<?
$MESS["TASK_NAME_FILEMAN_DENIED"] = "Доступ закрыт";
$MESS["TASK_NAME_FILEMAN_ALLOWED_FOLDERS"] = "Редактирование файлов и папок";
$MESS["TASK_NAME_FILEMAN_FULL_ACCESS"] = "Полный доступ";
$MESS["TASK_DESC_FILEMAN_DENIED"] = "Доступ к модулю 'Управление структурой' запрещен";
$MESS["TASK_DESC_FILEMAN_ALLOWED_FOLDERS"] = "Разрешено редактирование файлов и папок, для которых установлены соответствующие права";
$MESS["TASK_DESC_FILEMAN_FULL_ACCESS"] = "Разрешено редактирование файлов и папок, для которых установлены соответствующие права, а также изменение настроек модуля";
$MESS["TASK_NAME_MEDIALIB_DENIED"] = "Доступ закрыт";
$MESS["TASK_NAME_MEDIALIB_VIEW"] = "Просмотр коллекций";
$MESS["TASK_NAME_MEDIALIB_ONLY_NEW"] = "Создание новых";
$MESS["TASK_NAME_MEDIALIB_EDIT_ITEMS"] = "Редактирование элементов";
$MESS["TASK_NAME_MEDIALIB_EDITOR"] = "Редактирование элементов и коллекций";
$MESS["TASK_NAME_MEDIALIB_FULL"] = "Полный доступ";
$MESS["TASK_DESC_MEDIALIB_DENIED"] = "Запрещен доступ к медиабиблиотеке";
$MESS["TASK_DESC_MEDIALIB_VIEW"] = "Разрешен просмотр коллекций и вставка элементов через диалог медиабиблиотеки";
$MESS["TASK_DESC_MEDIALIB_ONLY_NEW"] = "Создание новых элементов и коллекций без возможности редактирования существующих";
$MESS["TASK_DESC_MEDIALIB_EDIT_ITEMS"] = "Создание, редактирование и удаление элементов в существующих коллекциях медиабиблиотеки";
$MESS["TASK_DESC_MEDIALIB_EDITOR"] = "Создание, редактирование и удаление элементов и коллекций медиабиблиотеки";
$MESS["TASK_DESC_MEDIALIB_FULL"] = "Полный доступ, включая возможность изменения прав доступа к коллекциям медиабиблиотеки";
$MESS["TASK_NAME_STICKERS_DENIED"] = "Доступ закрыт";
$MESS["TASK_NAME_STICKERS_READ"] = "Просмотр стикеров";
$MESS["TASK_NAME_STICKERS_EDIT"] = "Редактирование стикеров";
$MESS["TASK_DESC_STICKERS_DENIED"] = "Доступ к функционалу стикеров закрыт";
$MESS["TASK_DESC_STICKERS_READ"] = "Разрешен просмотр стикеров без возможности добавления и редактирования";
$MESS["TASK_DESC_STICKERS_EDIT"] = "Разрешено добавление, удаление, и редактирование стикеров";
$MESS["TASK_BINDING_STICKERS"] = "Стикеры";
$MESS["TASK_BINDING_MEDIALIB"] = "Медиабиблиотека";
?>