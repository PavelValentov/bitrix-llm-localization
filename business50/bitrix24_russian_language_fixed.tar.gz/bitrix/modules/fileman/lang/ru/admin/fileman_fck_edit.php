<?
$MESS ['FILEMAN_FILEEDIT_FILE_EXISTS'] = "Файл с таким именем уже существует!";
$MESS ['FILEMAN_FILEEDIT_FOLDER_EXISTS'] = "С таким именем определена папка!";
$MESS ['FILEMAN_FILEEDIT_AS_MENU'] = "Редактировать как меню";
$MESS ['FILEMAN_FILEEDIT_AS_HTML'] = "Редактировать как HTML";
$MESS ['FILEMAN_FILEEDIT_RENAME'] = "Переименовать";
$MESS ['FILEMAN_FILEEDIT_DOWNLOAD'] = "Скачать файл";
$MESS ['FILEMAN_FILEEDIT_NAME'] = "Имя файла:";
$MESS ['FILEMAN_FILEEDIT_SAVE'] = "Сохранить";
$MESS ['FILEMAN_FILEEDIT_APPLY'] = "Применить";
$MESS ['FILEMAN_FILEEDIT_RESET'] = "Отменить";
$MESS ['FILEMAN_FILEEDIT_TEMPLATE'] = "Шаблон:";
$MESS ['FILEMAN_FILEEDIT_CHANGE'] = "Недостаточно прав для вставки PHP кода.";
$MESS ['FILEMAN_FILEEDIT_CHANGE_ACCESS'] = "Недостаточно прав для изменения страниц с PHP кодом";
$MESS ['FILEMAN_FILEEDIT_TITLE'] = "Заголовок страницы:";
$MESS ['FILEMAN_FILEEDIT_BAD_FNAME'] = "Название файла не должно начинаться с точки!";
$MESS ['FILEMAN_EDIT_FILEPROPS'] = "Свойства страницы:";
$MESS ['FILEMAN_EDIT_PROPSCODE'] = "Код";
$MESS ['FILEMAN_EDIT_PROPSVAL'] = "Значение";
$MESS ['FILEMAN_EDIT_PROPSDEL'] = "Удалить";
$MESS ['FILEMAN_EDIT_PROPSMORE'] = "Еще...";
$MESS ['FILEMAN_FILE_EDIT_FOLDER_PROP'] = "Текущее значение из свойств раздела:";
$MESS ['FILEMAN_FILEEDIT_AS_TXT'] = "Редактировать как текст";
$MESS ['FILEMAN_FILEEDIT_AS_PHP'] = "Редактировать как PHP";
$MESS ['FILEMAN_FILE_VIEW'] = "Просмотр файла";
?>