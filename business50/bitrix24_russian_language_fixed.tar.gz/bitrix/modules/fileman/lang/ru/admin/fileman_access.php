<?
$MESS ['FILEMAN_ACCESS_TITLE'] = "Права на доступ продукта";

$MESS ['FM_FOLDER_ACCESS_DENIED'] = "Запрещен";
$MESS ['FM_FOLDER_ACCESS_READ'] = "Чтение";
$MESS ['FM_FOLDER_ACCESS_WRITE'] = "Запись";
$MESS ['FM_FOLDER_ACCESS_FULL'] = "Полный доступ";
$MESS ['FM_FOLDER_ACCESS_WORKFLOW'] = "Документооборот";
$MESS ['FILEMAN_FOLDER_ACCESS_INHERIT'] = "Наследовать";

$MESS ['FILEMAN_ACCESS_TO_DENIED'] = "Недостаточно прав для изменения параметров доступа к";
$MESS ['FILEMAN_ACCESS_CHANGE_TO'] = "Изменение прав доступа на";
$MESS ['FILEMAN_ACCESS_FOLDERS_FILES'] = " файлы/папки:";
$MESS ['FILEMAN_ACCESS_DIFFERENT'] = "Параметры доступа данной группы имеют различные права для папок! После сохранения все папки будут иметь одинаковые права доступа для данной группы.";
$MESS ['FILEMAN_ACCESS_GROUP'] = "Группа";
$MESS ['FILEMAN_ACCESS_LEVEL'] = "Право";
$MESS ['FILEMAN_ACCESS_LEVEL_CUR'] = "Текущее право";
$MESS ['FILEMAN_ACCESS_LEVEL_NOTCH'] = "(оставить без изменений)";
$MESS ['FILEMAN_ACCESS_DIFF_GROUP'] = "Некоторые файлы или папки имеют на данный момент различные уровни доступа для данной группы:";
$MESS ['FILEMAN_ACCESS_GROUP_INHERIT'] = "Все группы для которых уровень доступа &quot;Наследовать&quot;";
$MESS ['FILEMAN_ACCESS_DIFF_LEVEL'] = "Некоторые файлы или папки имеют на данный момент различные уровни доступа:";
$MESS ['FILEMAN_ACCESS_SAVE'] = "Сохранить";
$MESS ['FILEMAN_ACCESS_APPLY'] = "Применить";
$MESS ['FILEMAN_ACCESS_RESET'] = "Сбросить";
$MESS ['FILEMAN_ACCESS_FOR_GROUP'] = "На группу пользователей";
$MESS ['FILEMAN_ACCESS_FOR_GROUP2'] = "установлены права на запись. Любой зарегистрированный посетитель сможет изменять эти файлы/папки. Сохранить изменения?";
$MESS ['FILEMAN_ACCESS_FILE'] = "файл";
$MESS ['FILEMAN_CMENU_CAT'] = "Каталог";
$MESS ['FILEMAN_TAB'] = "Права на доступ продукта";
$MESS ['FILEMAN_TAB_ALT'] = "Установка прав на доступ продукта";
$MESS ['FILEMAN_FILE_OR_FOLDER'] = "Файл/папка";
?>