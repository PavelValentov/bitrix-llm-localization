<?
$MESS ['FILEMAN_FOLDER_TITLE'] = "Свойства папки";
$MESS ['FILEMAN_FOLDER_SECTION_NAME'] = "Заголовок:";
$MESS ['FILEMAN_FOLDER_ACCESS'] = "Права доступа";
$MESS ['FILEMAN_FOLDER_ACCESS_GROUP'] = "Группа";
$MESS ['FILEMAN_FOLDER_ACCESS_LEVEL'] = "Право";

$MESS ['FM_FOLDER_ACCESS_DENIED'] = "Запрещен";
$MESS ['FM_FOLDER_ACCESS_READ'] = "Чтение";
$MESS ['FM_FOLDER_ACCESS_WRITE'] = "Запись";
$MESS ['FM_FOLDER_ACCESS_FULL'] = "Полный доступ";
$MESS ['FM_FOLDER_ACCESS_WORKFLOW'] = "Документооборот";
$MESS ['FILEMAN_FOLDER_ACCESS_INHERIT'] = "Наследовать";

$MESS ['FILEMAN_FOLDER_ACCESS_FOR_INHERIT'] = "Все группы для которых уровень доступа &quot;Наследовать&quot;";
$MESS ['FILEMAN_FOLDER_SAVE'] = "Сохранить";
$MESS ['FILEMAN_FOLDER_APPLY'] = "Применить";
$MESS ['FILEMAN_FOLDER_RESET'] = "Сбросить";
$MESS ['FILEMAN_FOLDER_FILEPROPS'] = "Свойства папки";
$MESS ['FILEMAN_FOLDER_PROPSCODE'] = "Код";
$MESS ['FILEMAN_FOLDER_PROPSVAL'] = "Значение";
$MESS ['FILEMAN_FOLDER_PROPSDEL'] = "Удалить";
$MESS ['FILEMAN_FOLDER_PROPSMORE'] = "Еще...";
$MESS ['FILEMAN_FOLDER_CURVAL'] = "Текущее значение:";
$MESS ['FILEMAN_FOLDER_BACK'] = "Каталог";
$MESS ['FILEMAN_TAB'] = "Свойства каталога";
$MESS ['FILEMAN_TAB_ALT'] = "Свойства каталога";
$MESS ['FILEMAN_ACCESS'] = "Доступ";
$MESS ['FILEMAN_OPTION_PROPS_DESCR'] = "Описание";
$MESS ['FILEMAN_OPTION_PROPS_KEYW'] = "Ключевые слова";
?>