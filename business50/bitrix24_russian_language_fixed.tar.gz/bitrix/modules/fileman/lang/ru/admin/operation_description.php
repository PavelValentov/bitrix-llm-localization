<?
$MESS["OP_NAME_FILEMAN_VIEW_ALL_SETTINGS"] = "Просмотр настроек модуля";
$MESS["OP_NAME_FILEMAN_EDIT_MENU_TYPES"] = "Управление типами меню";
$MESS["OP_NAME_FILEMAN_ADD_ELEMENT_TO_MENU"] = "Добавление пунктов в меню";
$MESS["OP_NAME_FILEMAN_EDIT_MENU_ELEMENTS"] = "Редактирование пунктов меню";
$MESS["OP_NAME_FILEMAN_EDIT_EXISTENT_FILES"] = "Редактирование файлов";
$MESS["OP_NAME_FILEMAN_EDIT_EXISTENT_FOLDERS"] = "Редактирование параметров папок/разделов";
$MESS["OP_NAME_FILEMAN_ADMIN_FILES"] = "Управление файлами";
$MESS["OP_NAME_FILEMAN_ADMIN_FOLDERS"] = "Управление папками";
$MESS["OP_NAME_FILEMAN_VIEW_PERMISSIONS"] = "Просмотр прав доступа для файлов и папок";
$MESS["OP_NAME_FILEMAN_EDIT_ALL_SETTINGS"] = "Редактирование настроек модуля";
$MESS["OP_NAME_FILEMAN_UPLOAD_FILES"] = "Загрузка файлов";
$MESS["OP_NAME_FILEMAN_VIEW_FILE_STRUCTURE"] = "Просмотр файловой структуры";
$MESS["OP_NAME_FILEMAN_INSTALL_CONTROL"] = "Установка / удаление модуля";
$MESS["OP_NAME_MEDIALIB_VIEW_COLLECTION"] = "Просмотр коллекций медиабиблиотеки";
$MESS["OP_NAME_MEDIALIB_NEW_COLLECTION"] = "Создание новый коллекций медиабиблиотеки";
$MESS["OP_NAME_MEDIALIB_EDIT_COLLECTION"] = "Редактирование коллекций медиабиблиотеки";
$MESS["OP_NAME_MEDIALIB_DEL_COLLECTION"] = "Удаление коллекций медиабиблиотеки";
$MESS["OP_NAME_MEDIALIB_ACCESS"] = "Управление правами доступа к коллекциям";
$MESS["OP_NAME_MEDIALIB_NEW_ITEM"] = "Создание элементов медиабиблиотеки";
$MESS["OP_NAME_MEDIALIB_EDIT_ITEM"] = "Редактирование элементов медиабиблиотеки";
$MESS["OP_NAME_MEDIALIB_DEL_ITEM"] = "Удаление элементов медиабиблиотеки";
$MESS["OP_NAME_STICKER_VIEW"] = "Просмотр стикеров";
$MESS["OP_NAME_STICKER_EDIT"] = "Редактирование стикеров";
$MESS["OP_NAME_STICKER_NEW"] = "Добавление новых стикеров";
$MESS["OP_NAME_STICKER_DEL"] = "Удаление стикеров";
?>