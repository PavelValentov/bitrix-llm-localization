<?
$MESS ['FILEMAN_NEWFOLDER_ENTER_NAME'] = "Введите название!";
$MESS ['FILEMAN_NEWFOLDER_EXISTS'] = "Папка с таким именем уже существует!";
$MESS ['FILEMAN_NEWFOLDER_NAME'] = "Имя папки:";
$MESS ['FILEMAN_NEWFOLDER_SEACTION_NAME'] = "Название раздела:";
$MESS ['FILEMAN_NEWFOLDER_MAKE_INDEX'] = "Создать индексную страницу раздела:";
$MESS ['FILEMAN_NEWFOLDER_INDEX_TEMPLATE'] = "Шаблон:";
$MESS ['FILEMAN_NEWFOLDER_INDEX_EDIT'] = "Перейти к редактированию:";
$MESS ['FILEMAN_NEWFOLDER_SAVE'] = "Создать папку";
$MESS ['FILEMAN_NEWFOLDER_ADDMENU'] = "Создать пункт меню:";
$MESS ['FILEMAN_NEWFOLDER_MENU'] = "Меню:";
$MESS ['FILEMAN_NEWFOLDER_MENUITEM'] = "Название пункта:";
$MESS ['FILEMAN_BACK'] = "Папка";
$MESS ['FILEMAN_TAB1'] = "Новая папка";
$MESS ['FILEMAN_TAB1_ALT'] = "Создание новой папки";
$MESS ['FILEMAN_TRANS_LINKED'] = "Генерация имени папки из названия раздела: Включено";
$MESS ['FILEMAN_TRANS_UNLINKED'] = "Генерация имени папки из названия раздела: Выключено";
?>