<?
$MESS["FILEMAN_FILEVIEW_EDIT_AS_TEXT"] = "Редактировать как текст";
$MESS["FILEMAN_FILEVIEW_EDIT_AS_PHP"] = "Редактировать как PHP";
$MESS["FILEMAN_FILEVIEW_EDIT_AS_HTML"] = "Редактировать как HTML";
$MESS["FILEMAN_FILEVIEW_RENAME"] = "Переименовать";
$MESS["FILEMAN_FILEVIEW_DOWNLOAD"] = "Скачать файл";
$MESS["FILEMAN_FILEVIEW_NAME"] = "Имя файла:";
$MESS["FILEMAN_FILEVIEW_TYPE"] = "Тип:";
$MESS["FILEMAN_FILEVIEW_SIZE"] = "Размер:";
$MESS["FILEMAN_FILEVIEW_TIMESTAMP"] = "Последнее изменение:";
$MESS["FILEMAN_FILEVIEW_LAST_ACCESS"] = "Последний доступ:";
$MESS["FILEMAN_FILEVIEW_ENLARGE"] = "Нажмите для увеличения";
$MESS["FILEMAN_FILEVIEW_PHPERROR"] = "Недостаточно прав для просмотра исполняемого файла.";
$MESS["FILEMAN_VIEW_TAB"] = "Просмотр файла";
$MESS["FILEMAN_VIEW_TAB_ALT"] = "Просмотр файла";
$MESS["FILEMAN_VIEW_CONT"] = "Содержимое файла";
$MESS["FILEMAN_FILE_DELETE"] = "Удалить файл";
$MESS["FILEMAN_FILE_DELETE_CONFIRM"] = "Вы действительно хотите удалить файл?";
$MESS["FILEMAN_FILE_EDIT"] = "Редактировать";
$MESS["FILEMAN_FILEVIEW_TITLE"] = "Просмотр файла";
?>