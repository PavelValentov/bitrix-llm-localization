<?
$MESS ['FILEMAN_FILE_DOWNLOAD_PHPERROR'] = "Недостаточно прав для скачивания файла PHP.";
?>