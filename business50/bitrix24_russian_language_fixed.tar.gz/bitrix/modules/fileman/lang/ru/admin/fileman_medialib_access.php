<?
$MESS ['FM_ML_ACCESS_TITLE'] = "Права доступа для коллекций медиабиблиотеки";
$MESS ['FM_ML_TAB_NAME'] = "Права на доступ";
$MESS ['FM_ML_TAB_TITLE'] = "Установка прав на доступ к коллекциям медиабиблиотеки";
$MESS ['ML_SELECT_COLLECTION'] = "Выберите коллекцию из списка";
$MESS ['ML_ACCESS_FOR_ALL'] = "Общий доступ для всех коллекций";
$MESS ['ML_ACCESS_GROUP'] = "Группа";
$MESS ['ML_ACCESS_TASK'] = "Уровень доступа";
$MESS ['ML_TASK_INHERIT'] = "Наследовать";
$MESS ['ML_TASK_MEDIALIB_DENIED'] = "Запрещен";
$MESS ['ML_TASK_MEDIALIB_VIEW'] = "Просмотр";
$MESS ['ML_TASK_MEDIALIB_ONLY_NEW'] = "Создавать новые";
$MESS ['ML_TASK_MEDIALIB_EDIT_ITEMS'] = "Редактировать только элементы";
$MESS ['ML_TASK_MEDIALIB_EDITOR'] = "Редактировать";
$MESS ['ML_TASK_MEDIALIB_FULL'] = "Полный доступ";
$MESS ['FM_ML_BACK_IN_ML'] = "Вернуться в медиабиблиотеку";
?>