<?
$MESS ['FM_STATIC_CONTROL'] = "Управление";
$MESS ['FM_STATIC_CONTROL_ALT'] = "Управление файлами и папками, меню, правами доступа";
$MESS ['FM_MENU_TITLE'] = "Структура сайта";
$MESS ['FILEMAN_MNU_WN'] = "<Без названия>";
$MESS ['FILEMAN_MNU_STRUC'] = "Структура сайта";
$MESS ['FILEMAN_MNU_F_AND_F'] = "Файлы и папки";
$MESS ['FILEMAN_MNU_F_AND_F_TITLE'] = "Структура файлов и папок на диске";
$MESS ['FM_MENU_DESC'] = "Управление структурой и файлами";
$MESS ['FM_MENU_MEDIALIB'] = "Медиабиблиотека";
$MESS ['FM_MENU_MEDIALIB_TITLE'] = "Управление коллекциями и элементами в медиабиблиотеке";
$MESS["FMST_STICKERS"] = "Стикеры";
$MESS["FMST_STICKERS_TITLE"] = "Управление стикерами";
?>