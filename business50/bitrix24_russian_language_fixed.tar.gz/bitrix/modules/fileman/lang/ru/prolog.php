<?
$MESS["FILEMAN_ICON_ALT"] = "Управление структурой";
?>