<?
$MESS["HTMLED_SEARCH_PLACEHOLDER"] = "Поиск...";
$MESS["HTMLED_SEARCH_NOTHING"] = "Ничего не найдено";
$MESS["HTMLED_SEARCH_CANCEL"] = "Отменить фильтрацию";
$MESS["HTMLED_VIDEO_NOT_FOUND"] = "Видео не найдено";
$MESS["HTMLED_VIDEO_FORBIDDEN"] = "Доступ к видео запрещен";
?>