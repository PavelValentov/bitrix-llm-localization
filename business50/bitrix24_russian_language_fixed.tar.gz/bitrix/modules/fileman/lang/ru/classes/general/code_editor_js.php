<?
$MESS["GoToLine"] = "Быстрый переход на строку";
$MESS["Line"] = "строка";
$MESS["Char"] = "символ";
$MESS["Total"] = "Всего";
$MESS["Lines"] = "строк";
$MESS["Chars"] = "символов";
$MESS["LineTitle"] = "Текущая строка";
$MESS["CharTitle"] = "Текущий символ";
$MESS["EnableHighlight"] = "подсветка синтаксиса";
$MESS["EnableHighlightTitle"] = "Включить/выключить подсветку синтаксиса";
$MESS["DarkTheme"] = "темный фон";
$MESS["LightTheme"] = "светлый фон";
$MESS["HighlightWrongwarning"] = "В текущем браузере подсветка синтаксиса может работать некорректно.";
?>