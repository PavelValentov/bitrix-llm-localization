<?
$MESS ['PAR_MAN_SELECT_OTHER'] = "(другое)";
$MESS ['PAR_MAN_SELECT_NO_VALUE'] = "(не выбрано)";
$MESS ['PAR_MAN_SEARCH'] = "Поиск";
$MESS ['PAR_MAN_NO_SEARCH_RESULTS'] = "Ничего не найдено";
$MESS ['PAR_MAN_TEMPLATE_GROUP'] = "Шаблон компонента";
$MESS ['PAR_MAN_DEF_TEMPLATE'] = "Встроенный шаблон";
$MESS ['PAR_MAN_DEFAULT'] = "Общий шаблон";
?>