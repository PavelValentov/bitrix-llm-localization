<?
$MESS["ADM_FILE_ADD"] = "Добавить файл";
$MESS["ADM_FILE_ADD_M"] = "Добавить файлы";
$MESS["ADM_FILE_UPLOAD"] = "Загрузить с компьютера";
$MESS["ADM_FILE_MEDIALIB"] = "Выбрать из медиабиблиотеки";
$MESS["ADM_FILE_SITE"] = "Выбрать из структуры";
$MESS["ADM_FILE_CLOUD"] = "Загрузить из облаков";
$MESS["ADM_FILE_NEW_UPLOAD"] = "Заменить файлом с компьютера";
$MESS["ADM_FILE_NEW_MEDIALIB"] = "Заменить файлом из медиабиблиотеки";
$MESS["ADM_FILE_NEW_SITE"] = "Заменить файлом из структуры";
$MESS["ADM_FILE_NEW_CLOUD"] = "Заменить файлом из облаков";
$MESS["ADM_FILE_CLEAR"] = "Отменить выбор";
$MESS["ADM_FILE_DELETE"] = "Удалить";
$MESS["ADM_FILE_ADD_DESC"] = "Добавить описание";
$MESS["ADM_FILE_DESC"] = "описание...";
$MESS["ADM_FILE_DESCRIPTION"] = "Описание";
$MESS["ADM_FILE_INFO_SIZE"] = "Объем";
$MESS["ADM_FILE_INFO_DIM"] = "Размер";
$MESS["ADM_FILE_INFO_LINK"] = "Ссылка";
$MESS["ADM_FILE_DELETED_TITLE"] = "Изображение<br>будет<br>удалено";
$MESS["ADM_FILE_CANCEL_DEL"] = "Отменить удаление";
$MESS["ADM_FILE_INSERT_PATH"] = "Вставить путь к файлу";
$MESS["ADM_FILE_NOT_FOUND"] = "Файл не найден";
?>