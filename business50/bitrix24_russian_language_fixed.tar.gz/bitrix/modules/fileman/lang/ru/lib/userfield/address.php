<?php
$MESS["USER_TYPE_ADDRESS_DESCRIPTION"] = "Адрес";
$MESS["USER_TYPE_ADDRESS_SHOW_MAP"] = "Показывать карту";
$MESS["USER_TYPE_ADDRESS_NO_KEY_HINT"] = "Для работы с картами нужен ключ Google API. Введите его <a href=\"#settings_path##google_api_key\" target=\"_blank\">в настройках</a>.";
$MESS["USER_TYPE_ADDRESS_NO_KEY_HINT_B24"] = "Для работы с картами нужен ключ Google API. Введите его <a href=\"#settings_path##google_api_key\" target=\"_blank\">в настройках</a>.";
$MESS["USER_TYPE_ADDRESS_TRIAL_TITLE"] = "Пробный период работы Google-карт подошел к концу";
$MESS["USER_TYPE_ADDRESS_TRIAL"] = "<span>Google-карты – всемирно известный сервис, который позволяет:</span><ol><li>Использовать подсказки при наборе адреса</li><li>Показывать сам адрес на интерактивной карте</li></ol><span>Добавление Google-карт к карточке CRM доступно, начиная с тарифа \"Проект+\" всего за 990 рублей.</span>";
