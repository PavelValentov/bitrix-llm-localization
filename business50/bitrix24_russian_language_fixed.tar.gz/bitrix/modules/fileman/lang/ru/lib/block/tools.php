<?php
$MESS["BLOCK_EDITOR_TOOLS_DEFAULT"] = "по умолчанию";
$MESS["BLOCK_EDITOR_TOOLS_COLOR"] = "сменить цвет";