<?
$MESS["UF_ADDRESS_NO_RESULT"] = "Ничего не найдено";
$MESS["UF_ADDRESS_ADD"] = "Добавить";
$MESS["GOOGLE_MAP_TRIAL_HINT"] = "Использование Google-карт доступно только на коммерческих тарифах.";
$MESS["GOOGLE_MAP_TRIAL_HINT_MORE"] = "Подробнее";
?>