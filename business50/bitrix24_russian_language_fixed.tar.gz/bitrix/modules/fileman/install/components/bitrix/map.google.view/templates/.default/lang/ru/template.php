<?
$MESS['MYMS_TPL_SEARCH'] = 'Поиск по адресу';
$MESS['MYMS_TPL_SUBMIT'] = 'Искать';
$MESS['MYMS_TPL_JS_ERROR'] = 'Ошибка';
$MESS['MYMS_TPL_JS_SEARCH'] = 'Результаты поиска';
$MESS['MYMS_TPL_JS_RESULTS'] = 'результатов найдено';
$MESS['MYMS_TPL_JS_RESULTS_EMPTY'] = 'Ничего не найдено';
?>