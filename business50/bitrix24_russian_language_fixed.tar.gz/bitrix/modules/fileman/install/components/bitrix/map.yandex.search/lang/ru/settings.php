<?
$MESS ['MYMV_SET_POPUP_TITLE'] = "Настройки карты";
$MESS ['MYMV_SET_POPUP_WINDOW_TITLE'] = "Редактирование настроек карты";
$MESS ['MYMV_SET_POPUP_WINDOW_DESCRIPTION'] = "Управление видом карты и списком отображаемых объектов";
$MESS ['MYMV_SET_START_POS'] = "Начальная позиция карты";
$MESS ['MYMV_SET_START_POS_FIX'] = "зафиксировать";
$MESS ['MYMV_SET_START_POS_RESTORE'] = "восстановить";
$MESS ['MYMV_SET_START_POS_LAT'] = "Широта";
$MESS ['MYMV_SET_START_POS_LON'] = "Долгота";
$MESS ['MYMV_SET_START_POS_SCALE'] = "Масштаб";
$MESS ['MYMV_SET_START_POS_VIEW'] = "Вид";
$MESS ['MYMV_SET_POINTS'] = "Точки карты";
$MESS ['MYMV_SET_POINTS_ADD'] = "Добавить точки";
$MESS ['MYMV_SET_POINTS_ADD_DESCRIPTION'] = "Отметьте двойным щелчком мыши произвольное количество точек на карте.";
$MESS ['MYMV_SET_POINTS_ADD_FINISH'] = "Закончить";
$MESS ['MYMV_SET_SUBMIT'] = "Сохранить";
$MESS ['MYMV_SET_NONAME'] = "--- без названия ---";
$MESS ['MYMS_PARAM_INIT_MAP_TYPE_MAP'] = "схема";
$MESS ['MYMS_PARAM_INIT_MAP_TYPE_SATELLITE'] = "спутник";
$MESS ['MYMS_PARAM_INIT_MAP_TYPE_HYBRID'] = "гибрид";
$MESS ['MYMS_PARAM_INIT_MAP_TYPE_PUBLIC'] = "народная карта";
$MESS ['MYMS_PARAM_INIT_MAP_TYPE_PUBLIC_HYBRID'] = "народный гибрид";
$MESS ['MYMS_PARAM_INIT_MAP_NOTHING_FOUND'] = "(не найдено)";
$MESS ['MYMV_SET_ADDRESS_SEARCH'] = "Найти на карте";
?>