<?
$MESS ['MYMS_COMP_NAME'] = "Яндекс.Карты: поиск по адресу";
$MESS ['MYMS_COMP_DESCRIPTION'] = "Яндекс.Карта с формой поиска по адресу";
$MESS ['MAIN_YANDEX_MAP_SERVICE'] = "Яндекс.Карты";
$MESS ['MAIN_Y_CONTENT'] = "Контент";
?>