<?
$MESS ['EC_FILEMAN_MODULE_NOT_INSTALLED'] = "Модуль \"Управление структурой\" не установлен";
?>