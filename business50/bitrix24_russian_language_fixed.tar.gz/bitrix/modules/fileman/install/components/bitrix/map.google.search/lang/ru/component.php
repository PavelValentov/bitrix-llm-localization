<?
$MESS ['MYMS_NO_POSITION'] = "Не задана начальная позиция для карты.";
$MESS ['MYMS_ERROR_NO_KEY'] = "Не указан ключ доступа!";
?>