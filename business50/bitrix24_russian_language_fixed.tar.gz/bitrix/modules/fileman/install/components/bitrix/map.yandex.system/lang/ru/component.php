<?
$MESS ['MYMS_ERROR_NO_KEY'] = 'Не указан ключ доступа!';
?>