<?
$MESS["MYMS_PARAM_INIT_MAP_TYPE"] = "Стартовый тип карты";
$MESS["MYMS_PARAM_INIT_MAP_TYPE_MAP"] = "схема";
$MESS["MYMS_PARAM_INIT_MAP_TYPE_SATELLITE"] = "спутник";
$MESS["MYMS_PARAM_INIT_MAP_TYPE_HYBRID"] = "гибрид";
$MESS["MYMS_PARAM_INIT_MAP_TYPE_TERRAIN"] = "ландшафт";
$MESS["MYMS_PARAM_OPTIONS"] = "Настройки";
$MESS["MYMS_PARAM_OPTIONS_ENABLE_SCROLL_ZOOM"] = "изменение масштаба колесом мыши";
$MESS["MYMS_PARAM_OPTIONS_ENABLE_DBLCLICK_ZOOM"] = "изменение масштаба двойным щелчком мыши";
$MESS["MYMS_PARAM_OPTIONS_ENABLE_DRAGGING"] = "перетаскивание карты";
$MESS["MYMS_PARAM_OPTIONS_ENABLE_KEYBOARD"] = "управление с клавиатуры";
$MESS["MYMS_PARAM_CONTROLS"] = "Элементы управления";
$MESS["MYMS_PARAM_CONTROLS_SMALL_ZOOM_CONTROL"] = "Кнопки масштаба";
$MESS["MYMS_PARAM_CONTROLS_TYPECONTROL"] = "Тип карты";
$MESS["MYMS_PARAM_CONTROLS_SCALELINE"] = "Шкала масштаба";
$MESS["MYMS_PARAM_MAP_HEIGHT"] = "Высота карты";
$MESS["MYMS_PARAM_MAP_WIDTH"] = "Ширина карты";
$MESS["MYMS_PARAM_MAP_ID"] = "Идентификатор карты";
$MESS["MYMS_PARAM_API_KEY"] = "Ключ JavaScript API";
?>