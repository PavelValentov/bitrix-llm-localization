<?
$MESS ['LIGHT_EDITOR'] = "Упрощенный HTML-редактор";
$MESS ['LIGHT_EDITOR_DESCRIPTION'] = "Элемент управления: Упрощенный визуальный редактор";
?>