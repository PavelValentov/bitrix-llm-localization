<?
$MESS ['MGMS_COMP_NAME'] = "Google: поиск по адресу";
$MESS ['MGMS_COMP_DESCRIPTION'] = "Карта Google Maps с формой поиска по адресу";
$MESS ['MAIN_GOOGLE_MAP_SERVICE'] = "Google Maps";
$MESS ['MAIN_G_CONTENT'] = "Контент";
?>