<?
$MESS['MYMV_COMP_NAME'] = 'Яндекс.Карты: настраиваемая карта';
$MESS['MYMV_COMP_DESCRIPTION'] = 'Яндекс.Карта с возможностью вывода произвольных объектов';
$MESS['MAIN_YANDEX_MAP_SERVICE'] = 'Яндекс.Карты';
$MESS['MAIN_Y_CONTENT'] = 'Контент';
?>