<?php
$MESS['PDF_JS_DEFAULT_TITLE'] = 'Просмотр pdf файла';