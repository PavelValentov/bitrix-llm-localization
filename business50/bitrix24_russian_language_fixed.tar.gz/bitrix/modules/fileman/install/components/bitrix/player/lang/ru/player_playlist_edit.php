<?
$MESS ['PLAYLIST_EDIT_NO_DATA'] = "--Нет данных--";
$MESS ['PLAYLIST_TITLE_EDIT'] = "Редактирование списка воспроизведения";
$MESS ['PLAYLIST_TITLE_CREATE'] = "Создание списка воспроизведения";
$MESS ['PLAYLIST_TITLE_DESCRIPTION'] = "Диалог создания и редактирования списков воспроизведения";
$MESS ['PLAYLIST_EDIT_SESSION_EXPIRED'] = "Ваша сессия истекла. Пересохраните список воспроизведения еще раз.";
$MESS ['CONFIRM_INCORRECT_XML_FORMAT'] = "Открываемый список воспроизведения имеет некорректный формат. Продолжить редактирование?";
$MESS ['PLAYLIST_EDIT_CLICK_TO_EDIT'] = "Нажмите, чтобы отредактировать";
$MESS ['OPEN_FD_TITLE'] = "Открыть файловый диалог";
$MESS ['PLAYLIST_ITEM_UP'] = "Переместить элемент вверх";
$MESS ['PLAYLIST_ITEM_DOWN'] = "Переместить элемент вниз";
$MESS ['PLAYLIST_ITEM_DELETE'] = "Удалить элемент";
$MESS ['PLAYLIST_ITEM_DRAG'] = "Переместить элемент";
$MESS ['PLAYLIST_ITEM_ADD'] = "Добавить элемент";
$MESS ['PLAYLIST_EDIT_TITLE'] = "Название";
$MESS ['PLAYLIST_EDIT_AUTHOR'] = "Автор";
$MESS ['PLAYLIST_EDIT_LOCATION'] = "Путь к файлу";
$MESS ['PLAYLIST_EDIT_IMAGE'] = "Путь к рисунку";
$MESS ['PLAYLIST_EDIT_DURATION'] = "Время";
?>