<?php
$MESS['FILEMAN_ADDRESS_UF_LOCATION_NOTICE'] = 'Модуль Адреса и Местоположения не установлен';
