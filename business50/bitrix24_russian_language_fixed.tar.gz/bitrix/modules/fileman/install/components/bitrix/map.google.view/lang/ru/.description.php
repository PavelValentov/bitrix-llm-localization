<?
$MESS ['MYMV_COMP_NAME'] = "Google: настраиваемая карта";
$MESS ['MYMV_COMP_DESCRIPTION'] = "Карта Google Maps с возможностью вывода произвольных объектов";
$MESS ['MAIN_GOOGLE_MAP_SERVICE'] = "Google Maps";
$MESS ['MAIN_G_CONTENT'] = "Контент";
?>