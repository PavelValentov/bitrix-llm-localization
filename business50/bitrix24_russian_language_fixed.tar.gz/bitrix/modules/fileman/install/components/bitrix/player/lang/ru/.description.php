<?
$MESS["PLAYER_COMPONENT"] = "Медиа проигрыватель";
$MESS["PLAYER_COMPONENT_DESCRIPTION"] = "Компонент для проигрывания аудио-видео файлов";
$MESS ['MEDIA'] = "Медиа";
?>