<?php
$MESS["FILEMAN_PDFVIEWER_COMPONENT_NAME"] = "Просмотр pdf-файлов";
$MESS["FILEMAN_PDFVIEWER_COMPONENT_DESCRIPTION"] = "Позволяет просмотреть любые файлы формата .pdf";
$MESS["MEDIA"] = "Медиа";