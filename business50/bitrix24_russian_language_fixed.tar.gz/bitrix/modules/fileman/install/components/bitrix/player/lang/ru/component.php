<?
$MESS["INCORRECT_FILE"] = "Файл для проигрывания не найден.";
$MESS["INCORRECT_PLAYLIST"] = "Указанный список воспроизведения не найден.";
$MESS["ABOUT_TEXT"] = "1С-Битрикс: Медиа-плеер";
$MESS["ABOUT_LINK"] = "https://www.1c-bitrix.ru/products/cms/features/mediaplayer.php";
$MESS["PLAYER_PLAYLIST_EDIT"] = "Редактировать список воспроизведения";
$MESS["PLAYER_PLAYLIST_ADD"] = "Создать список воспроизведения";
$MESS["SWF_DENIED"] = "Неподдерживаемый тип данных.";
$MESS["INCORRECT_PLAYLIST_FORMAT"] = "Неверный формат плейлиста";
$MESS["JWPLAYER_DEPRECATED"] = "Эта версия плеера устарела. Пожалуйста, переключитесь на плеер на основе video.js";
$MESS["PLAYLIST_AUDIO_AND_VIDEO_NOT_SUPPORTED"] = "Плеер не поддерживает отображение видео и аудио в одном плейлисте";
$MESS["PLAYLIST_VIMEO_NOT_SUPPORTED"] = "Плеер не поддерживает отображение видео с vimeo.com в плейлисте";
$MESS["PLAYLIST_STREAMING_VIDEO_NOT_SUPPORTED"] = "Плеер не поддерживает отображение потокового видео в плейлисте";
$MESS["NO_SUPPORTED_FILES"] = "Нет доступных к воспроизведению файлов";
$MESS["PLAYLIST_FILE_NOT_FOUND"] = "не является поддерживаемым типом файла";
$MESS["VIDEOJS_NOT_SUPPORTED_MESSAGE"] = "Не найдено подходящего способа для воспроизведения";
?>