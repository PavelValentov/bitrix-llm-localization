<?php

$MESS ['BPT_ST_AUTHOR'] = "Автор;";
$MESS ['BPT_ST_NAME_1'] = "Утверждение документа со статусами";
$MESS ['BPT_ST_DESC_1'] = "Прохождение документом цепочки утверждения со статусами";
$MESS ['BPT_ST_CREATORS_MSGVER_1'] = "Кто может изменять документ";
$MESS ['BPT_ST_APPROVERS_MSGVER_1'] = "Кто утверждает документ";
$MESS ['BPT_ST_BP_NAME_1'] = "Бизнес-процесс со статусами";
$MESS ['BPT_ST_ST_DRAFT'] = "Черновик";
$MESS ['BPT_ST_F'] = "Оболочка события";
$MESS ['BPT_ST_CMD_APPR'] = "Отправить на утверждение";
$MESS ['BPT_ST_SETSTATE_1'] = "Установить статус";
$MESS ['BPT_ST_CMD_PUBLISH'] = "Опубликовать";
$MESS ['BPT_ST_CMD_APP'] = "Утверждение";
$MESS ['BPT_ST_INIT_1'] = "Вход в статус";
$MESS ['BPT_ST_SUBJECT_MSGVER_1'] = "Необходимо утвердить документ \"{=Document:NAME}\"";
$MESS ['BPT_ST_TEXT_MSGVER_1'] = "Вы должны утвердить или отклонить документ \"{=Document:NAME}\".
 
Для утверждения документа перейдите по ссылке #BASE_HREF##TASK_URL#
 
Содержание документа:
{=Document:DETAIL_TEXT}
 
Автор: {=Document:CREATED_BY_PRINTABLE}";
$MESS ['BPT_ST_MAIL_TITLE'] = "Почтовое сообщение";
$MESS ['BPT_ST_APPROVE_NAME_MSGVER_1'] = "Утверждение документа \"{=Document:NAME}\"";
$MESS ['BPT_ST_APPROVE_DESC_MSGVER_1'] = "Вы должны утвердить документ \"{=Document:NAME}\":
 
Содержание документа:
{=Document:PREVIEW_TEXT}
 
Автор:
{=Document:CREATED_BY_PRINTABLE}";
$MESS ['BPT_ST_APPROVE_TITLE_MSGVER_1'] = "Утверждение документа";
$MESS ['BPT_ST_SEQ'] = "Последовательность действий";
$MESS ['BPT_ST_SET_PUB'] = "Установить статус Публикация";
$MESS ['BPT_ST_SET_DRAFT'] = "Установить статус Черновик";
$MESS ['BPT_ST_TP'] = "Опубликован";
$MESS ['BPT_ST_INS'] = "Вход в статус";
$MESS ['BPT_ST_SAVEH'] = "Сохранение истории";
$MESS ['BPT_ST_PUBDC_MSGVER_1'] = "Публикация документа";
