<?php

$MESS ['BP_REVW_TITLE_MSGVER_1'] = "Ознакомление с документом";
$MESS ['BP_REVW_T'] = "Последовательный бизнес-процесс";
$MESS ['BP_REVW_TASK_MSGVER_1'] = "Необходимо ознакомиться с документом \"{=Document:NAME}\"";
$MESS ['BP_REVW_TASK_DESC_MSGVER_1'] = "Вы должны ознакомиться с документом \"{=Document:NAME}\".

Для ознакомления с документом перейдите по ссылке: #BASE_HREF##TASK_URL#

Автор: {=Document:CREATED_BY_PRINTABLE}";
$MESS ['BP_REVW_MAIL'] = "Почтовое сообщение";
$MESS ['BP_REVW_REVIEW_MSGVER_1'] = "Ознакомьтесь с документом {=Document:NAME}";
$MESS ['BP_REVW_REVIEW_DESC_MSGVER_1'] = "Вам необходимо ознакомиться с документом \"{=Document:NAME}\".

Автор: {=Document:CREATED_BY_PRINTABLE}";
$MESS ['BP_REVW_MAIL_SUBJ_MSGVER_1'] = "Ознакомление с документом \"{=Document:NAME}\" закончено";
$MESS ['BP_REVW_MAIL_TEXT_MSGVER_1'] = "Ознакомление с документом \"{=Document:NAME}\" закончено.";
$MESS ['BP_REVW_PARAM1'] = "Ознакомить";
$MESS ['BP_REVW_DESC'] = "Предназначен для ситуаций, когда группу сотрудников нужно ознакомить с каким-то документом. В рамках процесса задается группа работников, которая должна быть поставлена в известность. Дается право оставлять комментарии.";
