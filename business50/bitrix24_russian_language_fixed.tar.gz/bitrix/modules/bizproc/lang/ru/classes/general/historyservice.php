<?
$MESS ['BPCGHIST_INVALID_ID'] = "Запись с кодом #ID# не найдена";
?>