<?php

$MESS ['BPCGWF_TERMINATED_MSGVER_1'] = "Выполнение прервано";
$MESS ['BPCGWF_EXCEPTION_TITLE'] = "Ошибка";
$MESS ['BPCGWF_COMPLETED_COMMENT_TEXT'] = "Процесс завершён";
