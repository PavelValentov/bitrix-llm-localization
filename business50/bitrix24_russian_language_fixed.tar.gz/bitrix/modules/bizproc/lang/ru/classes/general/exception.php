<?
$MESS ['BPCGERR_INVALID_TYPE1'] = "Аргумент '#PARAM#' должен иметь тип '#VALUE#'";
$MESS ['BPCGERR_INVALID_ARG1'] = "Аргумент '#PARAM#' имеет недопустимое значение '#VALUE#'";
$MESS ['BPCGERR_INVALID_ARG'] = "Аргумент '#PARAM#' имеет недопустимое значение";
$MESS ['BPCGERR_NULL_ARG'] = "Аргумент '#PARAM#' не определен";
$MESS ['BPCGERR_INVALID_TYPE'] = "Аргумент '#PARAM#' имеет недопустимый тип";
?>