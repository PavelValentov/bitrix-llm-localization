<?php

$MESS['BPGA_ACTIVITY_NOT_FOUND_1'] = 'Действие не найдено (#ACTIVITY#)';
