<?php
$MESS ['BPCGDOC_LIMIT_SIMULTANEOUS_PROCESSES'] = "Для каждого документа может одновременно быть запущено не более #NUM# процесса(ов)";
$MESS ['BPCGDOC_WORKFLOW_RECURSION_LOCK'] = "Рекурсивный запуск шаблона заблокирован";
$MESS ['BPRA_IS_TIMEOUT'] = 'Таймаут операции';
