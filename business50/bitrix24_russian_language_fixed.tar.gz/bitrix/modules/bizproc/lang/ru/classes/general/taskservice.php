<?
$MESS["BPTS_AI_BIZ_PROC"] = "Бизнес-процессы";
$MESS["BPTS_AI_EX_TASKS"] = "Есть задания.";
$MESS["BPTS_AI_TASKS_NUM"] = "Заданий к исполнению:";
$MESS["BPTS_AI_TASKS_PERF"] = "Перейти к списку заданий";
$MESS["BPTS_AI_AR_USERS"] = "Список пользователей пуст";
?>