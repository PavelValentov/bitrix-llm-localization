<?php

$MESS['BIZPROC_VIEW_HELPER_FILE_NOT_FOUND'] = "Файл не найден";
