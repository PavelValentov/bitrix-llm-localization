<?
$MESS ['BPCGWTL_CANT_DELETE'] = "Шаблон бизнес-процесса не может быть удален, так как существуют запущенные по этому шаблону бизнес-процессы";
$MESS ['BPCGWTL_UNKNOWN_ERROR'] = "Неизвестная ошибка";
$MESS ['BPCGWTL_INVALID_WF_ID'] = "Шаблон бизнес-процесса с кодом '#ID#' не найден";
$MESS ['BPCGWTL_EMPTY_TEMPLATE'] = "Шаблон бизнес-процесса с кодом '#ID#' имеет пустое тело";
$MESS ['BPCGWTL_INVALID1'] = "Значение поля '#NAME#' не является целым числом";
$MESS ['BPCGWTL_INVALID2'] = "Значение поля '#NAME#' не является действительным числом";
$MESS ['BPCGWTL_INVALID3'] = "Значение поля '#NAME#' не верно";
$MESS ['BPCGWTL_INVALID4'] = "Значение поля '#NAME#' не может быть интерпретировано как 'да' или 'нет'";
$MESS ['BPCGWTL_INVALID5'] = "Значение даты в поле '#NAME#' не соответствует формату '#FORMAT#'";
$MESS ['BPCGWTL_INVALID6'] = "Для параметра '#NAME#' типа 'Пользователь' требуется установка модуля социальной сети";
$MESS ['BPCGWTL_INVALID7'] = "Тип параметра '#NAME#' не определен";
$MESS ['BPCGWTL_INVALID8'] = "Поле '#NAME#' должно быть обязательно заполнено";
$MESS ['BPCGWTL_WRONG_TEMPLATE'] = "Некорректный шаблон бизнес-процесса";
$MESS ['BPWTL_ERROR_MESSAGE_PREFIX'] = "Действие '#TITLE#':";
?>