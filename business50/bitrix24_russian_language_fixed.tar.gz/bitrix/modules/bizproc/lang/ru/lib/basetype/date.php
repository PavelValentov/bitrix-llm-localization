<?php
$MESS['BPDT_DATE_INVALID'] = 'Значение поля не является корректной датой.';
$MESS['BPDT_DATE_MOBILE_SELECT'] = 'Выбрать';
$MESS['BPDT_DATE_SERVER_TZ'] = 'Время сервера';
$MESS['BPDT_DATE_CURRENT_TZ'] = 'Мое время';