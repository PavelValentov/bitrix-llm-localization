<?php

$MESS['BIZPROC_LIB_API_TASK_ACCESS_SERVICE_DELEGATE_ERROR_ONLY_INTRANET_USER'] = 'Делегирование заданий доступно только для интранет-пользователей';
$MESS['BIZPROC_LIB_API_TASK_ACCESS_SERVICE_ERROR_SUBORDINATION_MSGVER_1'] = 'Вы не можете посмотреть задания выбранного сотрудника, так как он не является вашим подчиненным';
$MESS['BIZPROC_LIB_API_TASK_ACCESS_SERVICE_DELEGATE_ERROR_SUBORDINATION'] = 'Вы не можете делегировать задания выбранного сотрудника, так как он не является вашим подчинённым';
$MESS['BIZPROC_LIB_API_TASK_ACCESS_SERVICE_VIEW_TASKS_ERROR_ONLY_INTRANET_USER'] = 'Задания доступны только для интранет-пользователей';
