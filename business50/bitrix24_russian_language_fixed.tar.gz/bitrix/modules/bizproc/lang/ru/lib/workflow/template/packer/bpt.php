<?php
$MESS["BIZPROC_WF_TEMPLATE_BPT_WRONG_DATA"] = "Некорректный шаблон бизнес-процесса";
