<?php

$MESS['BIZPROC_CONTROLLER_WORKFLOW_FACES_CAN_READ_ERROR'] = 'Недостаточно прав для просмотра участников процесса';
