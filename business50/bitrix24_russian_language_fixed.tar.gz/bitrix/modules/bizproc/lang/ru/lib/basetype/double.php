<?php
$MESS["BPDT_DOUBLE_INVALID"] = "Значение поля не является корректным числом.";