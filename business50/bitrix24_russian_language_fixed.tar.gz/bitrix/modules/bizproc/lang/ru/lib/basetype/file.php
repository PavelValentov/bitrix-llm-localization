<?php
$MESS["BPDT_FILE_INVALID"] = "При сохранении файла произошла ошибка.";
$MESS["BPDT_FILE_SECURITY_ERROR"] = "Доступ к файлу запрещен настройками безопасности.";
$MESS["BPDT_FILE_CHOOSE_FILE"] = "Выбрать файл";