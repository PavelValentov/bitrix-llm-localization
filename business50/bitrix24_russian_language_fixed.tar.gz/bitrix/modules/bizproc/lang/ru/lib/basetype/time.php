<?php

$MESS['BPDT_TIME_INVALID'] = 'Значение поля не является корректным временем.';
$MESS['BPDT_TIME_NOT_SET'] = '[не установлено]';