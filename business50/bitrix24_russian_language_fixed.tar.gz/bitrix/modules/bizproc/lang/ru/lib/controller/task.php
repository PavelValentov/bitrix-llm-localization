<?php

$MESS['BIZPROC_CONTROLLER_TASK_DELEGATE_EMPTY_TASK_IDS'] = 'Укажите, какое задание вы хотите делегировать';
$MESS['BIZPROC_CONTROLLER_TASK_DELEGATE_INCORRECT_USER_ID'] = 'Делегирование заданий возможно только между пользователями с положительным ID';
