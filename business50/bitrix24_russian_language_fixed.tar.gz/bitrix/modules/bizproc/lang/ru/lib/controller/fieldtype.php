<?php

$MESS ['BIZPROC_ACCESS_DENIED'] = "Доступ запрещен.";
