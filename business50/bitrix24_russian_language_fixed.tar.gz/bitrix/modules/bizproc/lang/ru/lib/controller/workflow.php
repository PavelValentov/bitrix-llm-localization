<?php

$MESS['BIZPROC_CONTROLLER_WORKFLOW_TEMPLATE_NO_PRERMISSIONS'] = 'Недостаточно прав для просмотра бизнес-процессов. Обратитесь к администратору вашего Битрикс24';
$MESS['BIZPROC_CONTROLLER_WORKFLOW_TEMPLATE_NO_LIST'] = 'Нет процессов для просмотра';
