<?
$MESS ['BIZPROC_VALIDATOR_ENUM'] = "Поле `#name#` должно быть одним из доступных значений `#enum#`.";
$MESS ['BIZPROC_VALIDATOR_IS_ARRAY'] = "Поле `#name#` должно быть массивом.";
$MESS ['BIZPROC_VALIDATOR_ARRAY_KEY'] = "В массиве `#name#` задан некорректный ключ `#val#`.";
$MESS ['BIZPROC_VALIDATOR_ARRAY_VAL'] = "В массиве `#name#` задано некорректное значение `#val#`.";
$MESS ['BIZPROC_VALIDATOR_IS_NUM'] = "Поле `#name#` должно быть числом.";
$MESS ['BIZPROC_VALIDATOR_NUM_MIN'] = "Поле `#name#` должно быть не меньше #min#";
$MESS ['BIZPROC_VALIDATOR_NUM_MAX'] = "Поле `#name#` должно быть не больше #max#";
$MESS ['BIZPROC_VALIDATOR_IS_STRING'] = "Поле `#name#` должно быть строкой.";
$MESS ['BIZPROC_VALIDATOR_STRING_MIN'] = "Поле `#name#` должно быть длиной не меньше #min#";
$MESS ['BIZPROC_VALIDATOR_STRING_MAX'] = "Поле `#name#` должно быть длиной не больше #max#";
$MESS ['BIZPROC_VALIDATOR_REQUIRE'] = "Поле `#name#` обязательное.";
$MESS ['BIZPROC_VALIDATOR_REGEXP'] = "Поле `#name#` не соответствует регулярному выражению `#pattern#`.";
