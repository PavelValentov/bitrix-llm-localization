<?php

$MESS["BIZPROC_CALC_FUNCTION_GETDOCUMENTURL_DESCRIPTION_MSGVER_1"] = "Возвращает ссылку на элемент, на котором запущен бизнес-процесс";
