<?php

$MESS['BP_FIELDTYPE_MAIL_SENDER'] = 'Отправитель E-mail';
$MESS['BP_FIELDTYPE_MAIL_SENDER_AUTO'] = 'Автоматический выбор';
$MESS['BP_FIELDTYPE_MAIL_SENDER_ADD'] = 'Добавить отправителя';
