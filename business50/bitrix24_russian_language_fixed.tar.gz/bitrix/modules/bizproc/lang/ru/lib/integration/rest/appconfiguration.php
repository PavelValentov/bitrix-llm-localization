<?php
$MESS['BIZPROC_ERROR_CONFIGURATION_IMPORT_EXCEPTION'] = 'Ошибка импорта, пропущен импорт сущности (#CODE#)';
$MESS['BIZPROC_ERROR_CONFIGURATION_EXPORT_EXCEPTION'] = 'Ошибка экспорта, пропущен экспорт сущности (#CODE#)';
$MESS['BIZPROC_ERROR_CONFIGURATION_CLEAR_EXCEPTION'] = 'Ошибка очистки данных, пропущена очистка сущности (#CODE#)';
$MESS['BIZPROC_ERROR_CONFIGURATION_IMPORT_EXCEPTION_BP'] = 'Ошибка импорта, пропущен импорт бизнес-процесса';