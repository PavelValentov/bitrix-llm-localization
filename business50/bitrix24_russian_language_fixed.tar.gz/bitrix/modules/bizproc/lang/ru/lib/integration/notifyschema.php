<?php

$MESS['BIZPROC_NOTIFY_SCHEMA_ACTIVITY'] = 'Уведомления из бизнес-процессов';
