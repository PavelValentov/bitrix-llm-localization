<?php

$MESS["BIZPROC_CALC_FUNCTION_IMPLODE_DESCRIPTION"] = "Объединяет множественные значения в строку";
$MESS["BIZPROC_CALC_FUNCTION_MERGE_DESCRIPTION"] = "Объединение множественных значений";
$MESS["BIZPROC_CALC_FUNCTION_EXPLODE_DESCRIPTION"] = "Разбивает строку с помощью разделителя";
$MESS["BIZPROC_CALC_FUNCTION_SHUFFLE_DESCRIPTION"] = "Перемешивает значения множественного поля";
$MESS["BIZPROC_CALC_FUNCTION_FIRSTVALUE_DESCRIPTION"] = "Возвращает первое значение множественного поля";
$MESS["BIZPROC_CALC_FUNCTION_SWIRL_DESCRIPTION"] = "Перемещает первое значение множественного поля в конец";
