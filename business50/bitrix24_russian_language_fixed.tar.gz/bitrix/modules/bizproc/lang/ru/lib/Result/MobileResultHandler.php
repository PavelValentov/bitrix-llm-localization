<?php

$MESS['BIZPROC_RESULT_BP_RESULT_NO_RIGHTS'] = 'Недостаточно прав для просмотра результата';
