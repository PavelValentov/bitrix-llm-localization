<?php

$MESS['BIZPROC_AUTOMATION_SCHEME_TEMPLATE_ERROR'] = 'Один из шаблонов не может быть выбран';
$MESS['BIZPROC_AUTOMATION_SCHEME_MISSING_TEMPLATE_ERROR'] = 'Выбранного шаблона не существует';
