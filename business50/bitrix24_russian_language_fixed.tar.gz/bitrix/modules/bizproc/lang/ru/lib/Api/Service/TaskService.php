<?php

$MESS['BIZPROC_LIB_API_TASK_SERVICE_DELEGATE_TASK_SUCCESS_MESSAGE'] = 'Задание делегировано пользователю #USER_NAME#';
$MESS['BIZPROC_LIB_API_TASK_SERVICE_DELEGATE_TASK_ERROR_NO_TASKS'] = 'Укажите, какое задание вы хотите делегировать';
$MESS['BIZPROC_LIB_API_TASK_SERVICE_DELEGATE_TASK_ERROR_TASKS_NOT_FOUND'] = 'Пользователь не является ответственным за задание';
$MESS['BIZPROC_LIB_API_TASK_SERVICE_DELEGATE_TASK_ERROR_INCORRECT_USER_ID'] = 'Делегирование заданий возможно только между пользователями с положительным ID';
$MESS["BIZPROC_LIB_API_TASK_SERVICE_DO_TASK_ERROR_NO_TASK"] = "Задание не найдено";
$MESS["BIZPROC_LIB_API_TASK_SERVICE_DO_TASK_ERROR_ALREADY_DONE"] = "Задание было выполнено ранее";
$MESS["BIZPROC_LIB_API_TASK_SERVICE_DO_INLINE_TASK_COMPLETE_ERROR"] = "Задание \"#NAME#\" не может быть выполнено таким действием";
$MESS['BIZPROC_LIB_API_TASK_SERVICE_ERROR_CURRENT_USER_NOT_MEMBER'] = 'Вы не являетесь участником этого задания';
$MESS['BIZPROC_LIB_API_TASK_SERVICE_ERROR_TASK_ALREADY_DONE'] = 'Задание уже выполнено';
$MESS['BIZPROC_LIB_API_TASK_SERVICE_ERROR_TARGET_USER_NOT_MEMBER'] = 'Сотрудник уже не участвует в этом задании';
