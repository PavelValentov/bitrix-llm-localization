<?php
$MESS["BIZPROC_WF_TEMPLATE_ROBOPACKAGE_WRONG_DATA"] = "Некорректный шаблон Роботов";
$MESS["BIZPROC_WF_TEMPLATE_ROBOPACKAGE_EXTERNAL_MODIFIED"] = "Невозможно экспортировать Роботов из шаблона";