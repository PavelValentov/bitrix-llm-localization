<?php

$MESS['BIZPROC_AUTOMATION_SETTINGS_WAIT_FOR_CLOSURE_TASK'] = 'Сотрудник самостоятельно закрывает дела с заданиями';
$MESS['BIZPROC_AUTOMATION_SETTINGS_WAIT_FOR_CLOSURE_TASK_DESCR'] = 'Сотрудник сам решает, когда завершить дело, даже если задание уже выполнено. Если опция выключена, то дела завершаются автоматически после выполнения задания';
$MESS['BIZPROC_AUTOMATION_SETTINGS_WAIT_FOR_CLOSURE_COMMENTS'] = 'Сотрудник самостоятельно закрывает дела с комментариями';
$MESS['BIZPROC_AUTOMATION_SETTINGS_WAIT_FOR_CLOSURE_COMMENTS_DESCR'] = 'Сотрудник сам решает, когда завершить дело, даже если комментарии прочитаны. Если опция выключена, то дела завершаются автоматически после прочтения комментариев';
$MESS['BIZPROC_AUTOMATION_SETTINGS_SECTION_TITLE_MAIN'] = 'Бизнес-процессы';
