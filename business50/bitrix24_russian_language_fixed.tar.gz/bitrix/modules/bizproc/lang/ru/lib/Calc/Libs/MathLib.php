<?php

$MESS["BIZPROC_CALC_FUNCTION_ABS_DESCRIPTION"] = "Вычисление модуля числа";
$MESS["BIZPROC_CALC_FUNCTION_INTVAL_DESCRIPTION"] = "Возвращает целое число";
$MESS["BIZPROC_CALC_FUNCTION_FLOATVAL_DESCRIPTION"] = "Возвращает число";
$MESS["BIZPROC_CALC_FUNCTION_MIN_DESCRIPTION"] = "Возвращает наименьшее число";
$MESS["BIZPROC_CALC_FUNCTION_MAX_DESCRIPTION"] = "Возвращает наибольшее число";
$MESS["BIZPROC_CALC_FUNCTION_RAND_DESCRIPTION"] = "Возвращает случайное число";
$MESS["BIZPROC_CALC_FUNCTION_ROUND_DESCRIPTION"] = "Округляет число";
$MESS["BIZPROC_CALC_FUNCTION_CEIL_DESCRIPTION"] = "Округляет дробь в большую сторону";
$MESS["BIZPROC_CALC_FUNCTION_FLOOR_DESCRIPTION"] = "Округляет дробь в меньшую сторону";
