<?php
$MESS["BPDT_INTERNALSELECT_OPT_LABEL"] = "Поле документа";