<?php

$MESS['BIZPROC_LIB_TASK_ACCESS_SERVICE_DELEGATE_ERROR_ONLY_INTRANET_USER'] = 'Делегирование заданий доступно только для интранет-пользователей';
