<?php

$MESS['BIZPROC_LIB_API_WORKFLOW_SERVICE_UNKNOWN_CREATE_WORKFLOW_ERROR'] = 'Не удалось запустить бизнес-процесс';
$MESS['BIZPROC_LIB_API_WORKFLOW_SERVICE_NO_ACCESS'] = 'Недостаточно прав для остановки процесса';
$MESS['BIZPROC_LIB_API_WORKFLOW_SERVICE_COMPLETED'] = 'Бизнес-процесс уже завершён';
$MESS['BIZPROC_LIB_API_WORKFLOW_SERVICE_ROBOTS_NOT_FOUND'] = 'На этой стадии нет запущенных роботов';
$MESS['BIZPROC_LIB_API_WORKFLOW_SERVICE_ROBOTS_NO_ACCESS'] = 'Недостаточно прав для остановки роботов';
