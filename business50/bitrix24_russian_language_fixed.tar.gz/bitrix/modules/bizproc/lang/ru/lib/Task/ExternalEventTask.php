<?php

$MESS['BIZPROC_LIB_TASK_EXTERNAL_EVENT_TASK_NAME'] = 'Команда в бизнес-процессе';
$MESS['BIZPROC_LIB_TASK_EXTERNAL_EVENT_TASK_DESCRIPTION'] = 'Команда даёт пользователю возможность выбрать, по какому сценарию продолжить выполнение бизнес-процесса. Если в бизнес-процессе несколько команд, то они выполняются последовательно';
$MESS['BIZPROC_LIB_TASK_EXTERNAL_EVENT_TASK_FIELD_NAME'] = 'Значение команды';
$MESS['BIZPROC_LIB_TASK_EXTERNAL_EVENT_TASK_SEND_BUTTON_NAME'] = 'Сохранить';
$MESS['BIZPROC_LIB_TASK_EXTERNAL_EVENT_TASK_DEFAULT_OPTION_NAME'] = 'Не выбирать';
$MESS['BIZPROC_LIB_TASK_EXTERNAL_EVENT_TASK_ERROR_UNKNOWN_COMMAND'] = 'Команда недоступна';
