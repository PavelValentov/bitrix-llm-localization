<?php

$MESS['BIZPROC_CONTROLLER_GLOBALFIELD_MODE_NOT_DEFINED'] = 'Неверный режим.';

$MESS['BIZPROC_CONTROLLER_GLOBALFIELD_NOT_EXISTS_VARIABLE'] = 'Запрашиваемая переменная не найдена.';
$MESS['BIZPROC_CONTROLLER_GLOBALFIELD_CANT_DELETE_VARIABLE'] = 'Не удалось удалить переменную.';
$MESS['BIZPROC_CONTROLLER_GLOBALFIELD_CANT_UPSERT_VARIABLE_RIGHT'] = 'Недостаточно прав для добавления или изменения переменной.';
$MESS['BIZPROC_CONTROLLER_GLOBALFIELD_CANT_DELETE_VARIABLE_RIGHT'] = 'Недостаточно прав для удаления переменной.';

$MESS['BIZPROC_CONTROLLER_GLOBALFIELD_NOT_EXISTS_CONSTANT'] = 'Запрашиваемая константа не найдена.';
$MESS['BIZPROC_CONTROLLER_GLOBALFIELD_CANT_DELETE_CONSTANT'] = 'Не удалось удалить константу.';
$MESS['BIZPROC_CONTROLLER_GLOBALFIELD_CANT_UPSERT_CONSTANT_RIGHT'] = 'Недостаточно прав для добавления или изменения константы.';
$MESS['BIZPROC_CONTROLLER_GLOBALFIELD_CANT_DELETE_CONSTANT_RIGHT'] = 'Недостаточно прав для удаления константы.';