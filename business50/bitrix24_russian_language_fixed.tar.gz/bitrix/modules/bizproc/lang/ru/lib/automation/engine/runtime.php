<?php
$MESS["BIZPROC_AUTOMATION_TEMPLATE_TERMINATED"] = "Автоматическое завершение по переходу в следующий статус.";
?>