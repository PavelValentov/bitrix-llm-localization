<?php

$MESS['BIZPROC_LIB_API_WORKFLOW_ACCESS_SERVICE_START_WORKFLOW_RIGHTS_ERROR'] = 'Недостаточно прав для запуска бизнес-процесса';
$MESS['BIZPROC_LIB_API_WORKFLOW_ACCESS_SERVICE_VIEW_TIMELINE_RIGHTS_ERROR_MSGVER_1'] = 'Недостаточно прав на просмотр. Обратитесь к администратору вашего Битрикс24';
