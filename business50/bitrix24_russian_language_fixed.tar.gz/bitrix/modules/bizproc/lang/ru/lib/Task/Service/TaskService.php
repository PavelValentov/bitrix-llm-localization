<?php

$MESS['BIZPROC_LIB_TASK_TASK_SERVICE_DELEGATE_TASK_SUCCESS_MESSAGE'] = 'Задание делегировано пользователю #USER_NAME#';
$MESS['BIZPROC_LIB_TASK_TASK_SERVICE_DELEGATE_TASK_ERROR_NO_TASKS'] = 'Укажите, какое задание вы хотите делегировать';
$MESS['BIZPROC_LIB_TASK_TASK_SERVICE_DELEGATE_TASK_ERROR_INCORRECT_USER_ID'] = 'Делегирование заданий возможно только между пользователями с положительным ID';
