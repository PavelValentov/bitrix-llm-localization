<?php

$MESS['BIZPROC_LIB_SCRIPT_START_SCRIPT_RESULT_NOT_ENOUGH_RIGHTS'] = 'Недостаточно прав для запуска Умного сценария';
$MESS['BIZPROC_LIB_SCRIPT_START_SCRIPT_RESULT_SCRIPT_NOT_EXIST'] = 'Запрашиваемый Умный сценарий не найден';
$MESS['BIZPROC_LIB_SCRIPT_START_SCRIPT_RESULT_INACTIVE_SCRIPT'] = 'Умный сценарий деактивирован. Запуск невозможен';
$MESS['BIZPROC_LIB_SCRIPT_START_SCRIPT_RESULT_TEMPLATE_NOT_EXIST'] = 'Умный сценарий поврежден (не удалось прочитать данные шаблона)';
$MESS['BIZPROC_LIB_SCRIPT_START_SCRIPT_RESULT_EMPTY_TEMPLATE_PARAMETERS'] = 'Не заполнены параметры Умного сценария';
