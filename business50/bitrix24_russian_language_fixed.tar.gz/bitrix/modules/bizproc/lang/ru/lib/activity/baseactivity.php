<?php

$MESS['BIZPROC_BA_EMPTY_PROP'] = 'Не заполнено обязательное поле: #PROPERTY#';