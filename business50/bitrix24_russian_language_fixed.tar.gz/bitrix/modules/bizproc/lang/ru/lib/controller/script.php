<?php
$MESS["BIZPROC_CONTROLLER_SCRIPT_CANT_START"] = "Недостаточно прав для запуска Умного сценария";
$MESS["BIZPROC_CONTROLLER_SCRIPT_CANT_START_INACTIVE"] = "Умный сценарий деактивирован. Запуск невозможен";
$MESS["BIZPROC_CONTROLLER_SCRIPT_CANT_TERMINATE"] = "Недостаточно прав для остановки Умного сценария";
$MESS["BIZPROC_CONTROLLER_SCRIPT_CANT_DELETE_QUEUE"] = "Недостаточно прав для удаления запуска Умного сценария";
$MESS["BIZPROC_CONTROLLER_SCRIPT_CANT_DELETE_SCRIPT"] = "Недостаточно прав для удаления Умного сценария";
$MESS["BIZPROC_CONTROLLER_SCRIPT_CANT_UPDATE_SCRIPT"] = "Недостаточно прав для изменения Умного сценария";
$MESS["BIZPROC_CONTROLLER_SCRIPT_CANT_DELETE_RUNNING_SCRIPT"] = "Сценарий не может быть удален, так как существуют бизнес-процессы, запущенные по этому сценарию";
$MESS["BIZPROC_CONTROLLER_SCRIPT_CANT_TERMINATE_FINISHED"] = "Невозможно остановить Умный сценарий, он уже отработал";
$MESS["BIZPROC_CONTROLLER_SCRIPT_ERROR_DOCUMENT_ID_LIMIT"] = "Превышен лимит количества элементов для запуска Умного сценария (Выбрано #SELECTED#, разрешено #LIMIT#)";
$MESS["BIZPROC_CONTROLLER_SCRIPT_ERROR_QUEUES_LIMIT"] = "Превышен лимит запусков Умного сценария (В работе #CNT#, разрешено #LIMIT#)";
$MESS["BIZPROC_CONTROLLER_SCRIPT_NOT_EXISTS"] = "Запрашиваемый Умный сценарий не найден";
$MESS["BIZPROC_CONTROLLER_SCRIPT_NO_TEMPLATE"] = "Умный сценарий поврежден (Не удалось прочитать данные шаблона)";
