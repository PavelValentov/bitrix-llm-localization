<?php
$MESS["BPDT_INT_INVALID"] = "Значение поля не является целым числом.";