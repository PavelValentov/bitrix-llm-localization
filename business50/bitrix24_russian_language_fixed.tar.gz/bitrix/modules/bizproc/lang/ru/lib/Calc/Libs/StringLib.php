<?php

$MESS["BIZPROC_CALC_FUNCTION_SUBSTR_DESCRIPTION"] = "Возвращает подстроку";
$MESS["BIZPROC_CALC_FUNCTION_STRPOS_DESCRIPTION"] = "Возвращает позицию первого вхождения подстроки";
$MESS["BIZPROC_CALC_FUNCTION_RANDSTRING_DESCRIPTION"] = "Возвращает случайную строку";
$MESS["BIZPROC_CALC_FUNCTION_STRLEN_DESCRIPTION"] = "Возвращает длину строки";
$MESS["BIZPROC_CALC_FUNCTION_URLENCODE_DESCRIPTION"] = "URL-кодирование строки";
$MESS["BIZPROC_CALC_FUNCTION_STRTOLOWER_DESCRIPTION"] = "Преобразует строку в нижний регистр";
$MESS["BIZPROC_CALC_FUNCTION_STRTOUPPER_DESCRIPTION"] = "Преобразует строку в верхний регистр";
$MESS["BIZPROC_CALC_FUNCTION_UCWORDS_DESCRIPTION"] = "Преобразует в верхний регистр первый символ каждого слова в строке";
$MESS["BIZPROC_CALC_FUNCTION_UCFIRST_DESCRIPTION"] = "Преобразует первый символ строки в верхний регистр";
$MESS["BIZPROC_CALC_FUNCTION_NUMBER_FORMAT_DESCRIPTION"] = "Форматирует число с разделением групп";
$MESS['BIZPROC_CALC_FUNCTION_TRIM_DESCRIPTION'] = 'Удаляет пробелы из начала и конца строки';
