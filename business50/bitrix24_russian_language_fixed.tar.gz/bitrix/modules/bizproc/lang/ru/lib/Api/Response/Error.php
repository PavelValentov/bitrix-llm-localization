<?php

$MESS['BIZPROC_LIB_SERVICES_ERROR_UNAUTHORIZED'] = 'Вы не авторизованы';
$MESS['BIZPROC_LIB_SERVICES_ERROR_WORKFLOW_NOT_FOUND'] = 'Такого бизнес-процесса нет';
