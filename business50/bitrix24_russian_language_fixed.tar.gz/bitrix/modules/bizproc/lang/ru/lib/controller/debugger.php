<?php

$MESS['BIZPROC_CONTROLLER_DEBUGGER_CAN_DEBUG_ERROR'] = 'Недостаточно прав для работы с отладкой';
$MESS['BIZPROC_CONTROLLER_DEBUGGER_CAN_FINISH_ERROR'] = 'Недостаточно прав для завершения сессии отладки';
$MESS['BIZPROC_CONTROLLER_DEBUGGER_NO_SESSION'] = 'Не удалось получить данные сессии отладки';
$MESS['BIZPROC_CONTROLLER_DEBUGGER_NO_DOCUMENT'] = 'Не удалось получить данные элемента отладки';
$MESS['BIZPROC_CONTROLLER_DEBUGGER_NO_WORKFLOW'] = 'Не удалось получить данные отлаживаемого процесса';
$MESS['BIZPROC_CONTROLLER_DEBUGGER_DOCUMENT_TITLE'] = '#ENTITY# в отладке';
