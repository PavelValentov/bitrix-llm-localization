<?php

$MESS['BIZPROC_ERROR_MODULE_NOT_INSTALLED'] = 'Модуль "#MODULE_NAME#" не установлен';
$MESS['BIZPROC_ERROR_USER_NOT_FOUND'] = 'Пользователь не найден';
$MESS['BIZPROC_ERROR_FILE_NOT_FOUND'] = 'Файл не найден';
