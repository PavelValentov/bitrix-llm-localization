<?php

$MESS['BIZPROC_DEBUGGER_SESSION_SESSION_SHORT_DESCRIPTION'] = 'Отладчик запущен пользователем #USER# в разделе #ENTITY#';
$MESS['BIZPROC_DEBUGGER_SESSION_SESSION_DESCRIPTION'] = 'Отладчик запущен #DATE# пользователем #USER# в разделе #ENTITY#';
$MESS['BIZPROC_DEBUGGER_SESSION_ERROR_UNKNOWN_DOCUMENT_ID_1'] = 'Для отладки роботов можно взять только ту сделку, которая поступила из входящих каналов или лидов после запуска отладчика';
$MESS['BIZPROC_DEBUGGER_SESSION_ERROR_DOCUMENT_ID_ALREADY_FIXED'] = 'Элемент уже выбран';
