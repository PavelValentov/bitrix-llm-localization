<?php
$MESS['BPDT_BASE_ADD'] = 'Добавить';