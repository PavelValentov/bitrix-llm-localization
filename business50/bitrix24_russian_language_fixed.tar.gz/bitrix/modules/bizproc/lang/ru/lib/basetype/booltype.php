<?php
$MESS['BPDT_BOOL_YES'] = 'Да';
$MESS['BPDT_BOOL_NO'] = 'Нет';
$MESS['BPDT_BOOL_NOT_SET'] = 'Не установлено';
$MESS['BPDT_BOOL_INVALID'] = 'Значение поля не является корректным значением Да/Нет.';