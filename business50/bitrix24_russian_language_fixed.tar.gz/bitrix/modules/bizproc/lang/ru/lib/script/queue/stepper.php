<?php

$MESS["BIZPROC_SCRIPT_QUEUE_CAN_START_ERROR"] = "Недостаточно прав для запуска сценария";
