<?php

$MESS['BIZPROC_LIB_API_CONTROLLER_WORKFLOW_STARTER_ERROR_BIZPROC_FEATURE_DISABLED'] = 'Бизнес-процесс недоступен. Обратитесь к администратору вашего Битрикс24';
$MESS['BIZPROC_LIB_API_CONTROLLER_WORKFLOW_STARTER_ERROR_INCORRECT_AUTO_EXECUTE_TYPE'] = 'Некорректное значение типа автозапуска бизнес-процесса';
$MESS['BIZPROC_LIB_API_CONTROLLER_WORKFLOW_STARTER_ERROR_ACCESS_DENIED'] = 'Недостаточно прав для запуска бизнес-процесса. Обратитесь к руководителю или администратору вашего Битрикс24';
$MESS['BIZPROC_LIB_API_CONTROLLER_WORKFLOW_STARTER_ERROR_INCORRECT_DOCUMENT_TYPE'] = 'Некорректное значение типа документа';
$MESS['BIZPROC_LIB_API_CONTROLLER_WORKFLOW_STARTER_ERROR_INCORRECT_DOCUMENT_ID'] = 'Некорректное значение кода документа';
$MESS['BIZPROC_LIB_API_CONTROLLER_WORKFLOW_STARTER_ERROR_DOC_TYPE_DONT_MATCH_DOC_ID'] = 'Код документа не относится к переданному типу документа';
