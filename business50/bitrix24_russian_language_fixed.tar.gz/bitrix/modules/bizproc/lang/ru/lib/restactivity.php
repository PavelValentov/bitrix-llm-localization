<?php
$MESS["BPRAT_PROPERTIES_LENGTH_ERROR"] = "Для значения поля \"#FIELD_TITLE#\" превышена максимальная длина: 65535.";