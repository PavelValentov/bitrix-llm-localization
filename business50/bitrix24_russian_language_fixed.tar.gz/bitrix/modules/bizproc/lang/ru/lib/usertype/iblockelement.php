<?php
$MESS["BP_FIELDTYPE_UF_INFOBLOCK"] = "Инфоблок";
