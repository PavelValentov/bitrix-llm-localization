<?
$MESS ['BIZPROC_INSTALL_DESCRIPTION'] = "Модуль для создания и работы с бизнес-процессами";
$MESS ['BIZPROC_PERM_D'] = "доступ запрещен";
$MESS ['BIZPROC_INSTALL_NAME'] = "Бизнес-процессы";
$MESS ['BIZPROC_INSTALL_TITLE'] = "Установка модуля";
$MESS ['BIZPROC_PERM_R'] = "чтение";
$MESS ['BIZPROC_PERM_W'] = "запись";
$MESS ['BIZPROC_BIZPROCDESIGNER_INSTALLED'] = "Установлен модуль дизайнера бизнес-процессов. Удалите сначала его.";
?>