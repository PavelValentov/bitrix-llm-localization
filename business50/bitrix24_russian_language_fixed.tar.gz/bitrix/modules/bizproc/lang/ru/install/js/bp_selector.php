<?php

$MESS["BIZPROC_JS_BP_SELECTOR_PARAMETERS"] = "Параметры";
$MESS["BIZPROC_JS_BP_SELECTOR_VARIABLES"] = "Переменные";
$MESS["BIZPROC_JS_BP_SELECTOR_CONSTANTS"] = "Константы";
$MESS["BIZPROC_JS_BP_SELECTOR_DOCUMENT"] = "Документ";
$MESS["BIZPROC_JS_BP_SELECTOR_ACTIVITIES"] = "Доп.результаты";
$MESS["BIZPROC_JS_BP_SELECTOR_SYSTEM"] = "Системные";
$MESS["BIZPROC_JS_BP_SELECTOR_WORKFLOW_ID"] = "Идентификатор бизнес-процесса";
$MESS["BIZPROC_JS_BP_SELECTOR_USER_ID"] = "Текущий пользователь";
$MESS["BIZPROC_JS_BP_SELECTOR_NOW"] = "Время сервера";
$MESS["BIZPROC_JS_BP_SELECTOR_NOW_LOCAL"] = "Время локальное";
$MESS["BIZPROC_JS_BP_SELECTOR_DATE"] = "Текущая дата";
$MESS["BIZPROC_JS_BP_SELECTOR_EOL"] = "Символ конца строки";
$MESS["BIZPROC_JS_BP_SELECTOR_HOST_URL"] = "URL сайта";
$MESS["BIZPROC_JS_BP_SELECTOR_EMPTY_LIST"] = "Ничего не найдено";
$MESS["BIZPROC_JS_BP_SELECTOR_TARGET_USER"] = "Пользователь, запустивший процесс";
$MESS["BIZPROC_JS_BP_SELECTOR_FUNCTIONS"] = "Функции";
