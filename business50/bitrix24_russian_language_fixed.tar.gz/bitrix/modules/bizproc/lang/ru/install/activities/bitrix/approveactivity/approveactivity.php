<?
$MESS ['BPAA_LOG_Y'] = "Утвержден";
$MESS ['BPAA_LOG_N'] = "Отклонен";
$MESS ['BPAA_LOG_COMMENTS'] = "Комментарий";
?>