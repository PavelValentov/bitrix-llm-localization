<?php

$MESS["BIZPROC_JS_BP_FIELD_TYPE_YES"] = "Да";
$MESS["BIZPROC_JS_BP_FIELD_TYPE_NO"] = "Нет";
$MESS["BIZPROC_JS_BP_FIELD_TYPE_NOT_SELECTED"] = "[не установлено]";
$MESS["BIZPROC_JS_BP_FIELD_TYPE_ADD"] = "добавить";
$MESS["BIZPROC_JS_BP_FIELD_TYPE_CHOOSE_FILE"] = "Выбрать файл";

$MESS['BIZPROC_JS_BP_FIELD_TYPE_SELECT_OPTIONS1'] = 'Каждый вариант значения в новой строке. Если значение варианта отличается от названия, укажите его в квадратных скобках перед названием. Например, [v1]Вариант 1';
$MESS['BIZPROC_JS_BP_FIELD_TYPE_SELECT_OPTIONS2'] = "По окончании заполнения нажмите кнопку \"Установить\"";
$MESS['BIZPROC_JS_BP_FIELD_TYPE_SELECT_OPTIONS3'] = 'Установить';
