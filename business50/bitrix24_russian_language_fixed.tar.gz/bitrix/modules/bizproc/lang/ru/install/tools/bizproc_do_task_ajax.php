<?php

$MESS["BIZPROC_DO_TASK_AJAX_ERROR_NOT_FOUND_MSGVER_1"] = "Задание не найдено.";
$MESS["BIZPROC_DO_TASK_AJAX_ERROR_ALREADY_DONE_MSGVER_1"] = "Задание было выполнено ранее.";
