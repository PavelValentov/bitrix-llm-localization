<?
$MESS["BIZPROC_MAIL_TEMPLATE_NAME_1"] = "Сообщение действия отправки почты";
$MESS["BIZPROC_HTML_MAIL_TEMPLATE_NAME_1"] = "Сообщение действия отправки почты (HTML)";
$MESS["BIZPROC_MAIL_TEMPLATE_DESC"] = "#SENDER# - Отправитель сообщения
#RECEIVER# - Получатель сообщения
#TITLE# - Заголовок сообщения
#MESSAGE# - Сообщение";
?>