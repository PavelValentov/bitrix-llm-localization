<?
$MESS["BIZPROC_JS_BP_STARTER_REQUEST_FAILURE"] = "Во время запроса произошла ошибка. Попробуйте перезагрузить страницу.";
$MESS["BIZPROC_JS_BP_STARTER_CANCEL"] = "Отменить";
$MESS["BIZPROC_JS_BP_STARTER_START"] = "Запустить";
$MESS["BIZPROC_JS_BP_STARTER_SAVE"] = "Сохранить";
$MESS["BIZPROC_JS_BP_STARTER_AUTOSTART"] = "Автоматический запуск бизнес-процессов";
$MESS["BIZPROC_JS_BP_STARTER_NO_TEMPLATES"] = "Нет ни одного шаблона бизнес-процессов";
$MESS ['BIZPROC_JS_BP_STARTER_DESTINATION_CHOOSE'] = "выбрать";
$MESS ['BIZPROC_JS_BP_STARTER_DESTINATION_EDIT'] = "изменить";
$MESS ['BIZPROC_JS_BP_STARTER_FILE_CHOOSE'] = "Выбрать файл";
$MESS ['BIZPROC_JS_BP_STARTER_CONTROL_CLONE'] = "добавить";
?>