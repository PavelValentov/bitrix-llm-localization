<?
$MESS ['BIZPROC_MENU_TEXT'] = "Бизнес-процессы";
$MESS ['BIZPROC_MENU_TITLE'] = "Бизнес-процессы";
$MESS ['BIZPROC_MENU_TASKS_1'] = "Задания";
$MESS ['BIZPROC_MENU_TASKS_ALT'] = "Список ваших заданий";
?>