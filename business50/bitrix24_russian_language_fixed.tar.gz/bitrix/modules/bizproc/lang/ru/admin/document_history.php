<?
$MESS ['BPADH_RECOVERY_SUCCESS'] = "Запись успешно восстановлена из истории";
$MESS ['BPADH_F_AUTHOR_ANY'] = "любой";
$MESS ['BPADH_DELETE_DOC_CONFIRM'] = "Вы уверены, что хотите удалить эту запись?";
$MESS ['BPADH_RECOVERY_DOC_CONFIRM'] = "Вы уверены, что хотите восстановить документ из этой записи?";
$MESS ['BPADH_AUTHOR'] = "Автор";
$MESS ['BPADH_F_AUTHOR'] = "Автор";
$MESS ['BPADH_RECOVERY_ERROR'] = "Не удалось восстановить запись из истории";
$MESS ['BPADH_DELETE_DOC'] = "Удалить запись";
$MESS ['BPADH_TITLE'] = "История документа";
$MESS ['BPADH_ERROR'] = "Ошибка";
$MESS ['BPADH_F_MODIFIED'] = "Изменен";
$MESS ['BPADH_MODIFIED'] = "Изменен";
$MESS ['BPADH_NAME'] = "Название";
$MESS ['BPADH_RECOVERY_DOC'] = "Восстановить документ";
$MESS ['BPADH_NO_ENTITY'] = "Не указана сущность документа";
$MESS ['BPADH_NO_DOC_ID'] = "Не указан код документа";
$MESS ['BPADH_USER_PROFILE'] = "Профиль пользователя";
$MESS ['BPADH_VIEW_DOC'] = "Посмотреть документ";
$MESS ['BPADH_NO_PERMS'] = "У вас нет прав на доступ к истории данного документа";
?>