<?php

$MESS["BIZPROC_SEL_USERS_TAB_GROUPS"] = "– Группы";
$MESS["BIZPROC_SEL_USERS_TAB_USERS"] = "– Пользователи";
$MESS["BIZPROC_SEL_FIELDS_TAB"] = "Поля документа";
$MESS["BIZPROC_SEL_TITLEBAR_DESC"] = "Выберите необходимое поле двойным кликом или нажатием на кнопку &quot;Вставить&quot;.";
$MESS["BIZPROC_SEL_INSERT"] = "Вставить";
$MESS["BIZPROC_SEL_PARAMS_TAB"] = "Параметры шаблона";
$MESS["BIZPROC_SEL_USERS_TAB"] = "Пользователи";
$MESS["BIZPROC_SEL_GROUPS_TAB"] = "Категории пользователей";
$MESS["BIZPROC_SEL_ERR"] = "Необходимо выбрать поле для вставки из одного из списков!";
$MESS["BP_SEL_VARS"] = "Переменные";
$MESS["BP_SEL_ADDIT"] = "Дополнительные результаты";
$MESS["BIZPROC_AS_TITLE"] = "Вставка значения";
$MESS["BIZPROC_AS_TITLE_TOOLBAR"] = "Вставка значения";
$MESS["BP_SEL_CONSTANTS"] = "Константы";
$MESS["BP_SEL_GCONST"] = "Глобальные константы";
$MESS['BP_SEL_GVAR'] = 'Глобальные переменные';
