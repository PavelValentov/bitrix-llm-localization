<?php

$MESS ['BPABS_MESSAGE_SUCCESS'] = "Бизнес-процесс по шаблону '#TEMPLATE#' успешно запущен";
$MESS ['BPABS_BACK'] = "Вернуться";
$MESS ['BPABS_TAB'] = "Бизнес-процесс";
$MESS ['BPABS_TAB1'] = "Бизнес-процесс";
$MESS ['BPABS_TAB_TITLE'] = "Задайте параметры запуска бизнес-процесса";
$MESS ['BPABS_DESCRIPTION'] = "Описание шаблона бизнес-процесса";
$MESS ['BPABS_NAME'] = "Название шаблона бизнес-процесса";
$MESS ['BPABS_DO_CANCEL'] = "Отменить";
$MESS ['BPABS_MESSAGE_ERROR'] = "Бизнес-процесс по шаблону '#TEMPLATE#' не запущен";
$MESS ['BPABS_ERROR'] = "Ошибка";
$MESS ['BPABS_NO_TEMPLATES'] = "Для данного типа документа нет ни одного шаблона бизнес-процесса.";
$MESS ['BPABS_EMPTY_DOC_ID'] = "Не указан код документа, для которого запускается бизнес-процесс";
$MESS ['BPABS_EMPTY_ENTITY'] = "Не указана сущность, для которой запускается бизнес-процесс";
$MESS ['BPABS_TITLE'] = "Запуск бизнес-процесса";
$MESS ['BPABS_TAB1_TITLE'] = "Выберите шаблон бизнес-процесса для запуска";
$MESS ['BPABS_DO_START'] = "Запустить";
$MESS ['BPABS_EMPTY_DOC_TYPE'] = "Не указан тип документа";
$MESS ['BPABS_NO_PERMS'] = "У вас нет прав на запуск бизнес-процесса для данного документа";
