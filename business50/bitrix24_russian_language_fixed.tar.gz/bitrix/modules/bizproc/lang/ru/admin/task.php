<?php

$MESS["BPAT_BACK"] = "Вернуться";
$MESS["BPAT_GOTO_DOC"] = "Перейти к документу";
$MESS["BPAT_TAB_1"] = "Задание";
$MESS["BPAT_TAB_TITLE_1"] = "Задание";
$MESS["BPAT_TITLE_1"] = "Задание #ID#";
$MESS["BPAT_DESCR"] = "Описание задания";
$MESS["BPAT_NAME"] = "Название задания";
$MESS["BPAT_NO_TASK_MSGVER_1"] = "Задание не найдено";
$MESS["BPAT_USER"] = "Пользователь";
$MESS["BPAT_USER_NOT_FOUND"] = "(Не найден)";
$MESS["BPAT_NO_STATE"] = "Бизнес-процесс не найден.";
$MESS['BPAT_ACTION_DELEGATE'] = "Делегировать";
