<?
$MESS ['BIZPROC_ICON_TITLE'] = "Бизнес-процессы";
?>