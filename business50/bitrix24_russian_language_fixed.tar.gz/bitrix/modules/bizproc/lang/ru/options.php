<?php

$MESS["BIZPROC_LOG_CLEANUP_DAYS"] = "Время хранения лога выполнения бизнес-процесса (дней)";
$MESS["BIZPROC_SEARCH_CLEANUP_DAYS"] = "Время хранения поискового индекса бизнес-процесса (дней)";
$MESS["BIZPROC_EMPLOYEE_COMPATIBLE_MODE"] = "Включить режим совместимости для типа \"Привязка к сотруднику\"";
$MESS["BIZPROC_TAB_SET"] = "Настройки";
$MESS["BIZPROC_TAB_SET_ALT"] = "Настройки модуля";
$MESS["BIZPROC_NAME_TEMPLATE"] = "Формат отображения имени";
$MESS["BIZPROC_OPTIONS_NAME_IN_SITE_FORMAT"] = "Формат сайта";
$MESS["BIZPROC_LOG_SKIP_TYPES"] = "Не сохранять в лог события";
$MESS["BIZPROC_LOG_SKIP_TYPES_1_1"] = "запуск действия";
$MESS["BIZPROC_LOG_SKIP_TYPES_2_1"] = "завершение действия";
$MESS["BIZPROC_LIMIT_SIMULTANEOUS_PROCESSES"] = "Максимальное количество одновременно запущенных над документом процессов";
$MESS["BIZPROC_OPT_USE_GZIP_COMPRESSION"] = "Использовать компрессию при хранении данных";
$MESS["BIZPROC_OPT_USE_GZIP_COMPRESSION_EMPTY"] = "по умолчанию";
$MESS["BIZPROC_OPT_USE_GZIP_COMPRESSION_Y"] = "да";
$MESS["BIZPROC_OPT_USE_GZIP_COMPRESSION_N"] = "нет";
$MESS["BIZPROC_OPT_LOCKED_WI_PATH"] = "Путь к списку зависших бизнес-процессов";
$MESS["BIZPROC_OPT_TIME_LIMIT"] = "Минимальное время ожидания для действий";
$MESS["BIZPROC_OPT_TIME_LIMIT_S"] = "секунд";
$MESS["BIZPROC_OPT_TIME_LIMIT_M"] = "минут";
$MESS["BIZPROC_OPT_TIME_LIMIT_H"] = "часов";
$MESS["BIZPROC_OPT_TIME_LIMIT_D"] = "дней";
$MESS["BIZPROC_AUTOMATION_NO_FORCED_TRACKING"] = "Не сохранять в лог статусы роботов";
