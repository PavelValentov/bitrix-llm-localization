<?
$MESS ['BPWC_WLCT_NEW'] = "Новая заявка";
$MESS ['BPWC_WLCT_VARS'] = "Переменные бизнес-процесса";
$MESS ['BPWC_WLCT_BP'] = "Бизнес-процесс";
$MESS ['BPWC_WLCT_F_NAME'] = "Название";
$MESS ['BPWC_WLCT_F_STATE'] = "Статус";
$MESS ['BPWC_WLCT_F_EVENTS'] = "События";
$MESS ['BPWC_WLCT_F_TASKS'] = "Задания";
$MESS ['BPWC_WLCT_F_ACT'] = "Действия";
$MESS ['BPWC_WLCT_SAVE'] = "Сохранить";
$MESS ['BPWC_WLCT_STOP'] = "Остановить";
$MESS ['BPWC_WLCT_LIST'] = "Список бизнес-процессов";
$MESS ['BPWC_WLCT_F_AUTHOR'] = "Автор";
$MESS ['BPWC_WLCT_TOTAL'] = "Всего";
?>