<?
$MESS["BPABL_SLIDER_TITLE"] = "Журнал бизнес-процесса";
$MESS["BPABL_SLIDER_ERROR"] = "Не передан идентификатор Бизнес-процесса";
?>