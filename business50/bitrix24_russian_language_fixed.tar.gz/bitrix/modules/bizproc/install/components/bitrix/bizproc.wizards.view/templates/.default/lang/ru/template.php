<?
$MESS ['BPWC_WNCT_STATE'] = "Текущий статус";
$MESS ['BPWC_WNCT_TASKS'] = "Ваши задания";
$MESS ['BPWC_WNCT_EVENTS'] = "Отправить событие";
$MESS ['BPWC_WLC_MISSING_DOCUMENT'] = "Бизнес-процесс не найден";
$MESS ['BPWC_WNCT_2LIST'] = "Список бизнес-процессов";
$MESS ['BPWC_WNCT_NAME'] = "Название";
$MESS ['BPWC_WNCT_TAB1'] = "Основное";
$MESS ['BPWC_WNCT_TAB2'] = "Дополнительно";
$MESS ['BPWC_WNCT_TL_DATE'] = "Дата";
$MESS ['BPWC_WNCT_TL_NAME'] = "Название";
$MESS ['BPWC_WNCT_TL_NOTE'] = "Примечание";
$MESS ['BPWC_WNCT_TL_TOTAL'] = "Всего";
$MESS ['BPWC_WNCT_TL_HISTORY'] = "История выполнения";
?>