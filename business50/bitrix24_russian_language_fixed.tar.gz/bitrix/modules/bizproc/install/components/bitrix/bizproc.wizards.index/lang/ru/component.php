<?
$MESS ['BPWC_WIC_EMPTY_IBLOCK_TYPE'] = "Не указан тип информационного блока";
$MESS ['BPWC_WIC_WRONG_IBLOCK_TYPE'] = "Указанный в настройках компонента тип информационного блока не найден";
$MESS ['BPWC_WIC_ERROR'] = "Ошибка";
?>