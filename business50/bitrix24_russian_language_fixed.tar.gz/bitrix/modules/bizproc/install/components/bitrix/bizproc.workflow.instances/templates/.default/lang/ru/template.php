<?
$MESS ['BPWIT_TOTAL'] = "Всего";
$MESS ['BPWIT_PAGES'] = "Страницы";
$MESS ['BPWIT_PREV'] = "предыдущая";
$MESS ['BPWIT_NEXT'] = "следующая";
$MESS ["BPWIT_UNKNOWN"] = "неизвестно";
$MESS ["BPWIT_DELETE_NOTIFICATION"] = "Бизнес-процесс удалён";
$MESS ["BPWIT_TERMINATE_NOTIFICATION"] = "Бизнес-процесс остановлен";
?>