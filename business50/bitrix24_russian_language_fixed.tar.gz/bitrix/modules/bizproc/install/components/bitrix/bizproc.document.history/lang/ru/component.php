<?php

$MESS["W_WEBDAV_IS_NOT_INSTALLED_MSGVER_1"] = "Модуль библиотеки документов не установлен.";
$MESS["BPADH_RECOVERY_ERROR"] = "Не удалось восстановить запись из истории.";
$MESS["BPADH_RECOVERY_OK"] = "Запись восстановлена из истории.";
$MESS["BPADH_DELETE_OK"] = "Запись удалена из истории.";
$MESS["BPADH_TITLE"] = "История документа";
$MESS["BPABS_EMPTY_DOC_ID"] = "Не указан код документа, для которого запускается бизнес-процесс.";
$MESS["BPABS_EMPTY_ENTITY"] = "Не указана сущность, для которой запускается бизнес-процесс.";
$MESS["BPABS_EMPTY_DOC_TYPE"] = "Не указан тип документа.";
$MESS["BPATT_NO_MODULE_ID"] = "Не указан модуль.";
$MESS["BPADH_NAV_TITLE"] = "Версии документа";
$MESS["BPADH_NO_PERMS"] = "У вас нет прав на доступ к истории данного документа.";
$MESS["BPADH_DELETE_DOC_CONFIRM"] = "Вы уверены, что хотите удалить эту запись?";
$MESS["BPADH_DELETE_DOC"] = "Удалить";
$MESS["BPADH_RECOVERY_DOC"] = "Восстановить";
$MESS["BPADH_VIEW_DOC"] = "Посмотреть документ";
