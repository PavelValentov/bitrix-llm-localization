<?
$MESS ['BPWC_WNCT_STATE'] = "Текущий статус";
$MESS ['BPWC_WNCT_TASKS'] = "Ваши задания";
$MESS ['BPWC_WNCT_EVENTS'] = "Отправить событие";
$MESS ['BPWC_WLC_MISSING_DOCUMENT'] = "Бизнес-процесс не найден";
$MESS ['BPWC_WNCT_2LIST'] = "Список бизнес-процессов";
$MESS ['BPWC_WNCT_NAME'] = "Название";
?>