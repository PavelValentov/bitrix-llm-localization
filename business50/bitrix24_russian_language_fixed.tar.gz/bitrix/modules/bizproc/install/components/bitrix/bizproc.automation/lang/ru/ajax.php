<?php

$MESS["BIZPROC_AUTOMATION_AJAX_NO_DATA_ERROR"] = "Произошла ошибка при передаче данных";