<?
$MESS['BPAT_GOTO_DOC'] = "Перейти к документу";
$MESS['BPATL_SUCCESS'] = "Задание выполнено.";
$MESS['BPAT_COMMENT'] = "Комментарий";
$MESS['BPATL_DOC_HISTORY'] = "История изменений документа";
$MESS['BPATL_COMMENTS'] = "Комментарии";
$MESS['BPATL_TASK_TITLE_1'] = "Задание";
$MESS["BPATL_USER_STATUS_YES"] = "Вы утвердили документ";
$MESS["BPATL_USER_STATUS_NO"] = "Вы отклонили документ";
$MESS["BPATL_USER_STATUS_OK"] = "Вы ознакомились с документом";