<?php

$MESS["BPWCWV_TEMPLATE_NAME"] = "Плоский";
