<?
$MESS ['BPWC_WICT_NEW_BP'] = "Новый бизнес-процесс";
$MESS ['BPWC_WICT_CREATE'] = "Создать";
$MESS ['BPWC_WICT_DELETE_PROMT'] = "Будет удалена вся информация связанная с этим процессом! Продолжить?";
$MESS ['BPWC_WICT_DELETE'] = "Удалить";
$MESS ['BPWC_WICT_EDIT'] = "Изменить";
$MESS ['BPWC_WICT_EMPTY'] = "Нет ни одного доступного типа бизнес-процесса";
?>