<?
$MESS ['IBEL_BIZPROC_STOP'] = "остановить";
$MESS ['IBEL_BIZPROC_DEL'] = "удалить";
$MESS ['IBEL_BIZPROC_LOG'] = "журнал";
$MESS ['IBEL_BIZPROC_DATE_MSGVER_1'] = "Дата текущего состояния:";
$MESS ['IBEL_BIZPROC_STATE_MSGVER_1'] = "Текущий статус:";
$MESS ['IBEL_BIZPROC_RUN_CMD'] = "Выполнить команду";
$MESS ['IBEL_BIZPROC_RUN_CMD_NO'] = "Не выполнять";
$MESS ['IBEL_BIZPROC_TASKS_MSGVER_1'] = "Задачи по бизнес-процессу:";
$MESS ['IBEL_BIZPROC_NEW'] = "Новый бизнес-процесс";
$MESS ['IBEL_BIZPROC_START'] = "Запустить новый бизнес-процесс";
$MESS ['IBEL_BIZPROC_SAVE'] = "Сохранить";
$MESS ['IBEL_BIZPROC_APPLY'] = "Применить";
$MESS ['IBEL_BIZPROC_CANCEL'] = "Отменить";
?>
