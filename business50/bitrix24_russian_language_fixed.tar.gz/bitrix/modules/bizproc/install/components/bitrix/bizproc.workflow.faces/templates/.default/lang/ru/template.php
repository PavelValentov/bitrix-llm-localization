<?php
$MESS['BPWLFC_MORE'] = 'еще';
$MESS['BPWLFC_MORE_1'] = 'ещё #N#';
$MESS['BPWLFC_WORKFLOW_NOT_FOUND'] = 'Процесс не найден.';
$MESS['BPWLFC_TOTAL'] = 'всего';
$MESS['BPWLFC_TOTAL_1'] = 'всего #N#';