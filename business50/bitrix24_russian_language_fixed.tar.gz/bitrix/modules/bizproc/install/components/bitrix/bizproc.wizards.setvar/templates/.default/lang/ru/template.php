<?
$MESS ['BPWC_WVCT_2LIST'] = "Список бизнес-процессов";
$MESS ['BPWC_WVCT_SUBTITLE'] = "Настройка параметров бизнес-процесса";
$MESS ['BPWC_WVCT_EMPTY'] = "У данного бизнес-процесса нет параметров";
$MESS ['BPWC_WVCT_SAVE'] = "Сохранить";
$MESS ['BPWC_WVCT_APPLY'] = "Применить";
$MESS ['BPWC_WVCT_CANCEL'] = "Отмена";
?>