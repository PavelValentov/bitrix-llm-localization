<?
$MESS ['BPWFSC_PAGE_TITLE'] = "#NAME#: Константы бизнес-процесса";
$MESS ['BPWFSC_ERROR'] = "Ошибка";
$MESS ['BPWFSC_ARGUMENT_NULL'] = "Не заполнено обязательное значение '#PARAM#'.";
$MESS ['BPWFSC_ARGUMENT_ERROR'] = "#PARAM#: #ERROR#";
?>