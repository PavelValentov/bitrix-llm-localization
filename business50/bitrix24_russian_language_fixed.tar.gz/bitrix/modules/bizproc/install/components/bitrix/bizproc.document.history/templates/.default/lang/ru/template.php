<?
$MESS ['BPADH_AUTHOR'] = "Автор";
$MESS ['BPADH_MODIFIED'] = "Изменен";
$MESS ['BPADH_NAME'] = "Название";
$MESS ['BPADH_ALL'] = "Всего";
?>