<?php

$MESS ['BPAT_TITLE'] = "Задание";
$MESS ['BPAT_NO_TASK_MSGVER_1'] = "Задание не найдено.";
$MESS ['BPAT_EMPTY_TASK'] = "Не указан код задания.";
$MESS ['BPAT_NO_ACCESS_MSGVER_1'] = "Вы не можете просмотреть выбранное задание.";
$MESS ["BPAT_NO_STATE"] = "Бизнес-процесс не найден.";
$MESS ["BPAT_NO_PARAMETERS"] = "Был превышен лимит данных задания. Перенастройте Бизнес-процесс";
$MESS ['BPAT_DELEGATE_LABEL'] = 'Делегировать';
$MESS ['BPAT_DELEGATE_SELECT'] = 'Выбрать';
$MESS ['BPAT_DELEGATE_CANCEL'] = 'Отмена';
$MESS['BPAT_ERROR_TASK_ALREADY_DONE'] = 'Задание уже выполнено';
$MESS['BPAT_ERROR_CURRENT_USER_NOT_TASK_MEMBER'] = 'Вы не участвуете в этом задании';
$MESS['BPAT_ERROR_TARGET_USER_NOT_TASK_MEMBER'] = 'Сотрудник уже не участвует в этом задании';
