<?
$MESS ['BPATL_MODIFIED'] = "Изменен";
$MESS ['BPATL_NAME'] = "Название";
$MESS ['BPATL_DESCRIPTION'] = "Описание";
$MESS ['BPATL_EMPTY'] = "Список задач пуст.";
$MESS ['BPATL_DOCUMENT'] = "Документ";
$MESS ['BPATL_DOCUMENT_TITLE'] = "Посмотреть документ";
$MESS ['BPATL_CURRENT_TASKS'] = "Текущие задания";
$MESS ['BPATL_FINISHED_TASKS'] = "Архив заданий";
$MESS ['BPWC_WLCT_TOTAL'] = "Всего";
$MESS ['BPATL_GROUP_ACTION_YES'] = "Утвердить";
$MESS ['BPATL_GROUP_ACTION_NO'] = "Отклонить";
$MESS ['BPATL_GROUP_ACTION_OK'] = "Выполнить";
$MESS ['BPATL_GROUP_ACTION_DELEGATE'] = "Делегировать";
?>