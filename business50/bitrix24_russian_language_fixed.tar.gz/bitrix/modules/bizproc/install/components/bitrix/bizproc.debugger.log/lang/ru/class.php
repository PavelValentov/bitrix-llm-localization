<?php

$MESS['BIZPROC_CMP_DEBUGGER_LOG_TITLE'] = 'Лог';
$MESS['BIZPROC_MODULE_NOT_INSTALLED'] = 'Модуль Бизнес-процессы не установлен';
$MESS['BIZPROC_CMP_DEBUGGER_LOG_NO_SESSION'] = 'Не удалось получить данные сессии отладки';
$MESS['BIZPROC_CMP_DEBUGGER_LOG_NO_DOCUMENT'] = 'Не удалось получить данные элемента';
$MESS['BIZPROC_CMP_DEBUGGER_LOG_NO_RIGHTS'] = 'Недостаточно прав для работы с отладкой. Обратитесь к администратору вашего Битрикс24 или сотруднику, который отвечает за CRM';
