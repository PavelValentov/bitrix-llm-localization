<?
$MESS ['BPWC_WRC_EMPTY_IBLOCK_TYPE'] = "Не указан тип информационного блока";
$MESS ['BPWC_WRC_EMPTY_IBLOCK'] = "Не указан код информационного блока";
$MESS ['BPWC_WRC_ACCESS_ERROR'] = "Сессия страницы истекла. Пожалуйста вернитесь на <a href='#URL#'>страницу списка</a> и повторите ваше действие еще раз";
$MESS ['BPWC_WRC_WRONG_IBLOCK_TYPE'] = "Указанный в настройках компонента тип информационного блока не найден";
$MESS ['BPWC_WRC_WRONG_IBLOCK'] = "Указанный в настройках компонента информационный блок не найден";
$MESS ['BPWC_WRC_0_TMPLS'] = "Не найдено ни одного доступного шаблона бизнес-процесса";
$MESS ['BPWC_WRC_Z'] = "Заявка";
$MESS ['BPWC_WRC_PAGE_TITLE'] = "#NAME#: Новая заявка";
$MESS ['BPWC_WRC_PAGE_NAV_CHAIN'] = "Новая заявка";
$MESS ['BPWC_WRC_ERROR'] = "Ошибка";
$MESS ['BPCGWTL_INVALID81'] = "Поле '#NAME#' должно быть обязательно заполнено";
?>