<?
$MESS ['BPWC_GROUP'] = "Бизнес-процесс";
$MESS ['BPWC_COMPONENT_NAME_DESCRIPTION'] = "Бизнес-процесс";
$MESS ['BPWC_COMPONENT_NAME'] = "Бизнес-процесс";
?>