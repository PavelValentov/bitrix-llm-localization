<?php

$MESS["BP_SCR_ED_CMP_TITLE"] = "Редактировать сценарий";
$MESS["BP_SCR_ED_CMP_TITLE_NEW"] = "Новый сценарий";
$MESS["BP_SCR_ED_CMP_SCRIPT_CREATE_ERROR"] = "Не переданы необходимые данные о создаваемом Умном сценарии";
$MESS["BP_SCR_ED_CMP_SCRIPT_NOT_FOUND"] = "Умный сценарий не найден";
$MESS["BP_SCR_ED_CMP_SCRIPT_CAN_CREATE_ERROR"] = "Недостаточно прав для создания Умного сценария";
$MESS["BP_SCR_ED_CMP_SCRIPT_CAN_EDIT_ERROR"] = "Недостаточно прав для редактирования Умного сценария";
$MESS["BP_SCR_ED_CMP_HELP_BUTTON_TITLE"] = "Помощь";