<?php
$MESS['BIZPROC_SCRIPT_QUEUE_LIST_CONFIRM_TERMINATE'] = 'Вы действительно хотите остановить запущенный сценарий?';
$MESS['BIZPROC_SCRIPT_QUEUE_LIST_BTN_TERMINATE'] = 'Остановить';
$MESS['BIZPROC_SCRIPT_QUEUE_LIST_CONFIRM_DELETE'] = 'Вы действительно хотите удалить запущенный сценарий?';
$MESS['BIZPROC_SCRIPT_QUEUE_LIST_BTN_DELETE'] = 'Удалить';