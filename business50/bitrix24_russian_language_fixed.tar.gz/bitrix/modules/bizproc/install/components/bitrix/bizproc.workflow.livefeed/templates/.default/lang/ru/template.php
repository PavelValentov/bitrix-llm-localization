<?php

$MESS['BPATL_TASK_TITLE_MSGVER_1'] = "Задание";
$MESS["BPATL_USER_STATUS_YES"] = "Вы утвердили документ";
$MESS["BPATL_USER_STATUS_NO"] = "Вы отклонили документ";
$MESS["BPATL_USER_STATUS_OK"] = "Вы ознакомились с документом";
$MESS["BPATL_BEGIN"] = "Приступить";
$MESS["BPATL_TASK_LINK_TITLE"] = "Подробнее";
