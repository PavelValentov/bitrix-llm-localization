<?
$MESS ['BPWC_WVC_WRONG_TMPL'] = "Шаблон бизнес-процесса не найден";
$MESS ['BPWC_WVC_PAGE_TITLE'] = "#NAME#: Переменные бизнес-процесса";
$MESS ['BPWC_WVC_PAGE_NAV_CHAIN'] = "Переменные бизнес-процесса";
$MESS ['BPWC_WVC_ERROR'] = "Ошибка";
?>