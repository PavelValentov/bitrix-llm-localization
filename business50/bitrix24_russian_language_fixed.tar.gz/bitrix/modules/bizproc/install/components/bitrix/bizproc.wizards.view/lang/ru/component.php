<?
$MESS ['BPWC_WNC_EMPTY_IBLOCK_TYPE'] = "Не указан тип информационного блока";
$MESS ['BPWC_WNC_WRONG_IBLOCK_TYPE'] = "Указанный в настройках компонента тип информационного блока не найден";
$MESS ['BPWC_WLC_EMPTY_BPID'] = "Не указан код бизнес-процесса";
$MESS ['BPWC_WLC_EMPTY_IBLOCK'] = "Не указан код информационного блока";
$MESS ['BPWC_WLC_WRONG_IBLOCK'] = "Указанный в настройках компонента информационный блок не найден";
$MESS ['BPWC_WLC_WRONG_BP'] = "Бизнес-процесс не найден";
$MESS ['BPWC_WNC_SESSID'] = "Ошибка безопасности. Необходимо повторно заполнить форму";
$MESS ['BPABL_PAGE_TITLE'] = "Бизнес-процесс";
$MESS ['BPWC_WLC_ERROR'] = "Ошибка";
?>