<?php
$MESS['BIZPROC_SCRIPT_QDL_CONFIRM_TERMINATE'] = 'Остановить этот бизнес-процесс?';
$MESS['BIZPROC_SCRIPT_QDL_BTN_TERMINATE'] = 'Остановить';
$MESS['BIZPROC_SCRIPT_QDL_TERMINATE_SUCCESS'] = 'Бизнес-процесс остановлен';
