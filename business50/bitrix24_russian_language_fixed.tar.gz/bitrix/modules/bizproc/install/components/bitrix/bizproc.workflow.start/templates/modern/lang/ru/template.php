<?
$MESS ['BPABS_MESSAGE_SUCCESS'] = "Бизнес-процесс по шаблону '#TEMPLATE#' успешно запущен";
$MESS ['BPABS_TAB'] = "Бизнес-процесс";
$MESS ['BPABS_TAB_TITLE'] = "Задайте параметры запуска бизнес-процесса";
$MESS ['BPABS_DESCRIPTION'] = "Описание шаблона бизнес-процесса";
$MESS ['BPABS_NAME'] = "Название шаблона бизнес-процесса";
$MESS ['BPABS_DO_CANCEL'] = "Отменить";
$MESS ['BPABS_MESSAGE_ERROR'] = "Бизнес-процесс по шаблону '#TEMPLATE#' не запущен";
$MESS ['BPABS_NO'] = "Нет";
$MESS ['BPABS_NO_TEMPLATES'] = "Нет ни одного шаблона бизнес-процесса.";
$MESS ['BPABS_DO_START'] = "Запустить";
$MESS ['BPABS_INVALID_TYPE'] = "Тип параметра не определен.";
$MESS ['BPABS_YES'] = "Да";
?>