<?
$MESS ['BPWC_WCT_EMPTY_BLOCK'] = "Не указан код информационного блока";
$MESS["BIZPROC_EDIT_MENU_LIST_MESSAGE"] = "Бизнес-процессы";
$MESS["BIZPROC_EDIT_MENU_LIST_TITLE_MESSAGE"] = "Запущенные бизнес-процессы";
?>