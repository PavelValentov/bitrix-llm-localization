<?php

$MESS['BIZPROC_DEBUGGER_START_TEMPLATE_TITLE'] = 'Отладчик роботов';
$MESS['BIZPROC_DEBUGGER_START_TEMPLATE_SUBTITLE'] = 'Отладчик поможет протестировать роботов и убедиться в правильной работе сценариев. Отладка проходит на конкретной сделке и позволяет по шагам отследить все действия роботов';
$MESS['BIZPROC_DEBUGGER_START_TEMPLATE_SELECT_DEAL'] = 'Выберите режим для отладки роботов';
$MESS['BIZPROC_DEBUGGER_START_TEMPLATE_TEST_DEAL_TITLE'] = 'Отладка на тестовой сделке';
$MESS['BIZPROC_DEBUGGER_START_TEMPLATE_TEST_DEAL_SUBTITLE'] = 'Проверьте настройки роботов в любой удобный для вас момент. После запуска режима отладчик создаст тестовую сделку, на которой тут же можно начинать проверку';
$MESS['BIZPROC_DEBUGGER_START_TEMPLATE_INTERCEPTION_DEAL_TITLE'] = 'Перехват сделки из других каналов';
$MESS['BIZPROC_DEBUGGER_START_TEMPLATE_INTERCEPTION_DEAL_SUBTITLE'] = 'Проследите за действиями роботов с самого начала пути клиента. Отладчик дождется новую сделку из звонка, формы, чата, лида и других каналов, и запустит на ней отладку';
$MESS['BIZPROC_DEBUGGER_START_TEMPLATE_INFO_MESSAGE'] = 'Подробнее про режимы отладки';
$MESS['BIPZROC_DEBUGGER_START_TEMPLATE_START'] = 'Запустить';
$MESS['BIPZROC_DEBUGGER_START_TEMPLATE_FINISH'] = 'Завершить';
