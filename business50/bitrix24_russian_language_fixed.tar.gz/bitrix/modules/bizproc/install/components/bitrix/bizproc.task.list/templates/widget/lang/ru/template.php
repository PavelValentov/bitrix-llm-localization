<?
$MESS["BPTLWGT_TITLE"] = "Бизнес-процессы";
$MESS["BPTLWGT_RUNNING"] = "Ждут реакции";
$MESS["BPTLWGT_MODULE_DISK"] = "Документы";
$MESS["BPTLWGT_MODULE_IBLOCK"] = "Списки";
$MESS["BPTLWGT_MODULE_LISTS"] = "Процессы";
$MESS["BPTLWGT_MY_PROCESSES"] = "Мои процессы";
?>