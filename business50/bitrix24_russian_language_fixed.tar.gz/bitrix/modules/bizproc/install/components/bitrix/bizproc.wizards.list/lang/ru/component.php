<?
$MESS["BPWC_WLC_EMPTY_IBLOCK_TYPE"] = "Не указан тип информационного блока";
$MESS["BPWC_WLC_EMPTY_IBLOCK"] = "Не указан код информационного блока";
$MESS["BPWC_WLC_WRONG_IBLOCK_TYPE"] = "Указанный в настройках компонента тип информационного блока не найден";
$MESS["BPWC_WLC_WRONG_IBLOCK"] = "Информационный блок не найден";
$MESS["BPWC_WLC_MISSING_DOCUMENT"] = "Документ не найден";
$MESS["BPWC_WLC_MISSING_BP"] = "Бизнес-процесс не найден";
$MESS["BPWC_WLC_ERROR"] = "Ошибка";
$MESS["JHGFDC_STOP"] = "Остановить";
$MESS["JHGFDC_STOP_ALT"] = "Вы уверены, что хотите остановить этот процесс?";
$MESS["JHGFDC_STOP_DELETE"] = "Удалить";
$MESS["JHGFDC_STOP_DELETE_ALT"] = "Вы уверены, что хотите удалить этот процесс?";
$MESS["BPWC_WLCT_SAVE"] = "Отправить";
$MESS["INTS_TASKS_NAV"] = "Бизнес-процессы";
$MESS ['BPWC_WLCT_F_NAME'] = "Название";
$MESS ['BPWC_WLCT_F_STATE'] = "Статус";
$MESS ['BPWC_WLCT_F_EVENTS'] = "События";
$MESS ['BPWC_WLCT_F_TASKS'] = "Задания";
$MESS ['BPWC_WLCT_F_AUTHOR'] = "Автор";
$MESS ['BPWC_WLC_NOT_SET'] = "[не установлено]";
$MESS ['BPWC_WLC_NOT_DETAIL'] = "Подробнее";
?>