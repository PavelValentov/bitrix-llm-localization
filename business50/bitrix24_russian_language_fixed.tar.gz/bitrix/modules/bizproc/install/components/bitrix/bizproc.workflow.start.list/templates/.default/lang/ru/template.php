<?php

$MESS['BIZPROC_CMP_TMP_WORKKFLOW_START_LIST_START_COUNTER'] = 'Вы запустили [bold]#COUNTER#[/bold]';
$MESS['BIZPROC_CMP_WORKKFLOW_START_LIST_START_RIGHTS_ERROR'] = 'Недостаточно прав для добавления и редактирования шаблонов бизнес-процессов. Обратитесь к руководителю или администратору вашего Битрикс24';
$MESS['BIZPROC_CMP_WORKKFLOW_START_LIST_START_MODULE_ERROR'] = 'Добавление и редактирование шаблонов бизнес-процессов не поддерживается в этом модуле. Обратитесь к руководителю или администратору вашего Битрикс24';
