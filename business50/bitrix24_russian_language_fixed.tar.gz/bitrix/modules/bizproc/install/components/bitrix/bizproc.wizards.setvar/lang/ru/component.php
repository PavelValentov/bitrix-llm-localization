<?
$MESS ['BPWC_WVC_EMPTY_IBLOCK_TYPE'] = "Не указан тип информационного блока";
$MESS ['BPWC_WVC_EMPTY_IBLOCK'] = "Не указан код информационного блока";
$MESS ['BPWC_WVC_WRONG_IBLOCK_TYPE'] = "Указанный в настройках компонента тип информационного блока не найден";
$MESS ['BPWC_WVC_WRONG_IBLOCK'] = "Информационный блок не найден";
$MESS ['BPWC_WVC_WRONG_TMPL'] = "Шаблон бизнес-процесса не найден";
$MESS ['BPWC_WVC_PAGE_TITLE'] = "#NAME#: Переменные бизнес-процесса";
$MESS ['BPWC_WVC_PAGE_NAV_CHAIN'] = "Переменные бизнес-процесса";
$MESS ['BPWC_WVC_ERROR'] = "Ошибка";
?>