<?
$MESS ['BPWFSCT_EMPTY'] = "У данного бизнес-процесса нет настроек";
$MESS ['BPWFSCT_SAVE'] = "Сохранить";
?>