<?
$MESS ['BPWC_WRCT_SUCCESS'] = "Запрос успешно создан.";
$MESS ['BPWC_WRCT_ERROR'] = "Запрос не запущен.";
$MESS ['BPWC_WRCT_2LIST'] = "Список бизнес-процессов";
$MESS ['BPWC_WRCT_SUBTITLE'] = "Запуск нового бизнес-процесса";
$MESS ['BPWC_WRCT_NAME'] = "Название";
$MESS ['BPWC_WRCT_DESCR'] = "Описание";
$MESS ['BPWC_WRCT_SAVE'] = "Создать заявку";
$MESS ['BPWC_WRCT_CANCEL'] = "Отмена";
?>