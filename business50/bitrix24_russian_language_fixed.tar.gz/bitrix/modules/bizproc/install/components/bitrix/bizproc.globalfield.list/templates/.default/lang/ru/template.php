<?php

$MESS['BIZPROC_GLOBALFIELDS_LIST_CONFIRM_VARIABLE_DELETE'] = 'Вы действительно хотите удалить переменную?';
$MESS['BIZPROC_GLOBALFIELDS_LIST_CONFIRM_CONSTANT_DELETE'] = 'Вы действительно хотите удалить константу?';
$MESS['BIZPROC_GLOBALFIELDS_LIST_BTN_DELETE'] = 'Удалить';
$MESS['BIZPROC_GLOBALFIELDS_LIST_CONFIRM_VARIABLES_DELETE'] = 'Вы действительно хотите удалить переменные?';
$MESS['BIZPROC_GLOBALFIELDS_LIST_CONFIRM_CONSTANTS_DELETE'] = 'Вы действительно хотите удалить константы?';