<?php
$MESS["BPWFI_WORKFLOW_NOT_FOUND"] = 'Процесс не найден.';
$MESS["BPWFI_PAGE_TITLE"] = 'Бизнес-процесс';
?>