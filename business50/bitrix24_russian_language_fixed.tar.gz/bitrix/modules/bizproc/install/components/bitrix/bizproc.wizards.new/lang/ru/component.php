<?
$MESS ['BPWC_WNC_EMPTY_IBLOCK_TYPE'] = "Не указан тип информационного блока";
$MESS ['BPWC_WNC_WRONG_IBLOCK_TYPE'] = "Указанный в настройках компонента тип информационного блока не найден";
$MESS ['BPWC_WNC_SESSID'] = "Ошибка безопасности. Необходимо повторно заполнить форму";
$MESS ['BPWC_WNC_PS'] = "Процессы";
$MESS ['BPWC_WNC_P'] = "Процесс";
$MESS ['BPWC_WNC_EMPTY_NAME'] = "Не указано название бизнес-процесса";
$MESS ['BPWC_WNC_WRONG_TMPL'] = "Шаблон бизнес-процесса не найден";
$MESS ['BPWC_WNC_ERROR_TMPL'] = "Шаблон рабочего процесса не корректен";
$MESS ['BPWC_WNC_PAGE_TITLE'] = "#NAME#: Новый бизнес-процесс";
$MESS ['BPWC_WNC_PAGE_NAV_CHAIN'] = "Новый бизнес-процесс";
$MESS ['BPWC_WNC_ERROR'] = "Ошибка";
$MESS ['BPWC_WNC_PNADD'] = "Новая заявка";
?>