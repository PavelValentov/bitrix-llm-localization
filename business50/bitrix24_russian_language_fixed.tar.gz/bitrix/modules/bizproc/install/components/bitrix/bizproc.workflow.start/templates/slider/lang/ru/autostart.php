<?php

$MESS['BIZPROC_CMP_WORKFLOW_START_TMP_AUTOSTART_TITLE'] = 'Бизнес-процесс запущен автоматически';
$MESS['BIZPROC_CMP_WORKFLOW_START_TMP_AUTOSTART_DESCRIPTION'] = 'Бизнес-процессы могут запускаться автоматически, когда вы создаёте новый элемент или изменяете существующий. Это зависит от настроек в шаблонах бизнес-процессов';
$MESS['BIZPROC_CMP_WORKFLOW_START_TMP_AUTOSTART_STEP_AUTOSTART_TITLE'] = 'Информация о процессе';
$MESS['BIZPROC_CMP_WORKFLOW_START_TMP_AUTOSTART_EXIT_DIALOG_CONFIRM'] = 'Да, отменить';
$MESS['BIZPROC_CMP_WORKFLOW_START_TMP_AUTOSTART_EXIT_DIALOG_CANCEL'] = 'Не отменять';
$MESS['BIZPROC_CMP_WORKFLOW_START_TMP_AUTOSTART_EXIT_DIALOG_TITLE'] = 'Отменить заполнение полей?';
$MESS['BIZPROC_CMP_WORKFLOW_START_TMP_AUTOSTART_EXIT_DIALOG_DESCRIPTION'] = 'Бизнес-процесс запустится, даже если вы не заполните поля';
