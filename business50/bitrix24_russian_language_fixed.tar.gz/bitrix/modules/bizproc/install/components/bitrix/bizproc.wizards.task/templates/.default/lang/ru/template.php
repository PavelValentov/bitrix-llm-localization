<?php

$MESS ['BPWC_WTCT_NAME'] = "Название";
$MESS ['BPWC_WTCT_DESCR'] = "Описание";
$MESS ['BPWTC_WRCT_2LIST'] = "Список бизнес-процессов";
$MESS ['BPWTC_WRCT_SUBTITLE_MSGVER_1'] = "Задание";
