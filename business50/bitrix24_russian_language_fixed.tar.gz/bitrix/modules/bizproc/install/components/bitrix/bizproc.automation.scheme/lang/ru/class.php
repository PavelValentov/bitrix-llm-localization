<?php

$MESS['BIZPROC_AUTOMATION_SCHEME_MODULE_NOT_INSTALLED_MSGVER_1'] = 'Модуль "bizproc" не установлен';
$MESS['BIZPROC_AUTOMATION_SCHEME_UNKNOWN_DOCUMENT_MSGVER_1'] = 'Элемент не найден, возможно он был удалён';
$MESS['BIZPROC_AUTOMATION_SCHEME_UNKNOWN_ACTION'] = 'Выбрано неизвестное действие';
$MESS['BIZPROC_AUTOMATION_SCHEME_SCHEME_ERROR_MSGVER_1'] = 'Невозможно выполнить копирование роботов и триггеров';
$MESS['BIZPROC_AUTOMATION_SCHEME_RIGHTS_ERROR'] = 'Недостаточно прав';
