<?
$MESS ['BPWFSP_PAGE_TITLE'] = "#NAME#: Входящие параметры бизнес-процесса";
$MESS ['BPWFSP_ERROR'] = "Ошибка";
$MESS ['BPWFSP_ARGUMENT_NULL'] = "Не заполнено обязательное значение '#PARAM#'.";
$MESS ['BPWFSP_ARGUMENT_ERROR'] = "#PARAM#: #ERROR#";
?>