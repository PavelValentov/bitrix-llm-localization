<?php

$MESS ['BPWC_WTC_EMPTY_IBLOCK_TYPE'] = "Не указан тип информационного блока";
$MESS ['BPWC_WTC_EMPTY_IBLOCK'] = "Не указан код информационного блока";
$MESS ['BPWC_WTC_PERMS_ERROR'] = "Сессия страницы истекла. Пожалуйста вернитесь на <a href='#URL#'>страницу списка</a> и повторите ваше действие еще раз";
$MESS ['BPWC_WTC_WRONG_TASK_MSGVER_1'] = "Задание не найдено";
$MESS ['BPWC_WTC_WRONG_IBLOCK_TYPE'] = "Указанный в настройках компонента тип информационного блока не найден";
$MESS ['BPWC_WTC_WRONG_IBLOCK'] = "Указанный в настройках компонента информационный блок не найден";
$MESS ['BPWC_WTC_PAGE_TITLE_MSGVER_1'] = "Задание '#NAME#'";
$MESS ['BPWC_WTC_PAGE_NAV_CHAIN_MSGVER_1'] = "Задание '#NAME#'";
$MESS ['BPWC_WTC_ERROR'] = "Ошибка";
