<?
$MESS ['BPWC_WP_PERMS'] = "Доступ";
$MESS ['BPWC_WP_SEF_INDEX'] = "Список блоков";
$MESS ['BPWC_WP_SEF_NEW'] = "Новый блок";
$MESS ['BPWC_WP_SEF_LIST'] = "Список запущенных процессов";
$MESS ['BPWC_WP_SEF_VIEW'] = "Просмотр запущенного процесса";
$MESS ['BPWC_WP_SEF_START'] = "Запуск процесса";
$MESS ['BPWC_WP_TASK'] = "Задача";
$MESS ['BPWC_WP_BP'] = "Бизнес-процессы";
$MESS ['BPWC_WP_SETVAR'] = "Переменные бизнес-процессов";
$MESS ['BPWC_WP_SET_NAV_CHAIN'] = "Устанавливать цепочку навигации";
$MESS ['BPWC_WP_SKIP_BLOCK'] = "Только один процесс";
$MESS ['BPWC_WP_IBLOCK_TYPE'] = "Тип информационного блока";
$MESS ['BPWC_WP_ADMIN_ACCESS'] = "Административный доступ";
$MESS ['BPWC_WP_LOG'] = "Лог";
$MESS ['BPWC_WP_SEF_EDIT'] = "Редактирование блока";
?>