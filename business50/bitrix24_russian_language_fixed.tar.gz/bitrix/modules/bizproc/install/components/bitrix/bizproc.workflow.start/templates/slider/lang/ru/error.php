<?php

$MESS['BIZPROC__CMP_WORKFLOW_START_TMP_ERROR_TITLE'] = 'Запуск бизнес-процесса';
