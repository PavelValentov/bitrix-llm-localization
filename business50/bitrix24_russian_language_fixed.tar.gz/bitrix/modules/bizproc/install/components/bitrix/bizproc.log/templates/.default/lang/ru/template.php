<?
$MESS ['BPABL_STATE_MODIFIED_1'] = "Дата текущего статуса";
$MESS ['BPABL_STATE_NAME_1'] = "Текущий статус бизнес-процесса";
$MESS ['BPABL_LOG'] = "История выполнения бизнес-процесса";
$MESS ['BPABL_TYPE_1_1'] = "Запущено действие '#ACTIVITY#'#NOTE#";
$MESS ['BPABL_TYPE_2_1'] = "Завершено действие '#ACTIVITY#' со статусом '#STATUS#' и результатом '#RESULT#'#NOTE#";
$MESS ['BPABL_TYPE_3_1'] = "Отменено действие '#ACTIVITY#'#NOTE#";
$MESS ['BPABL_TYPE_4_1'] = "Ошибка действия '#ACTIVITY#'#NOTE#";
$MESS ['BPABL_TYPE_5_1'] = "Действие '#ACTIVITY#'#NOTE#";
$MESS ['BPABL_TYPE_6_1'] = "Что-то сделали с действием '#ACTIVITY#'#NOTE#";
$MESS ['BPABL_STATUS_1'] = "Инициализировано";
$MESS ['BPABL_STATUS_2'] = "Выполняется";
$MESS ['BPABL_STATUS_3'] = "Отменяется";
$MESS ['BPABL_STATUS_4'] = "Завершено";
$MESS ['BPABL_STATUS_5'] = "Ошибка";
$MESS ['BPABL_STATUS_6'] = "Не определено";
$MESS ['BPABL_RES_1'] = "Нет";
$MESS ['BPABL_RES_2'] = "Успешно";
$MESS ['BPABL_RES_3'] = "Отменено";
$MESS ['BPABL_RES_4'] = "Ошибка";
$MESS ['BPABL_RES_5'] = "Не инициализировано";
$MESS ['BPABL_RES_6'] = "Не определено";
$MESS ['BPWC_WLCT_TOTAL'] = "Всего";
?>