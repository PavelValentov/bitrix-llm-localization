<?php

$MESS['BIZPROC_TMP_DEBUGGER_LOG_NO_LOG'] = 'Отсутствует лог сессии отладки';