<?php

$MESS['BIZPROC_MODULE_NOT_INSTALLED'] = 'Модуль Бизнес-процессы не установлен';
$MESS['BIZPROC_DEBUGGER_START_ERROR_DOCUMENT_TYPE'] = 'Для этого элемента отладка недоступна';
$MESS['BIZPROC_DEBUGGER_START_ERROR_RIGHTS'] = 'Недостаточно прав для запуска отладчика. Обратитесь к администратору вашего Битрикс24 или сотруднику, который отвечает за CRM';
