<?
$MESS ['BPATT_NAV'] = "Шаблоны бизнес-процессов";
$MESS ['BPATT_TITLE'] = "Шаблоны бизнес-процессов";
$MESS ['BPATT_AE_CREATE'] = "Создание";
$MESS ['BPATT_AE_DELETE'] = "Удаление";
$MESS ['BPATT_AE_NONE'] = "Нет";
$MESS ['BPATT_NO_ENTITY'] = "Не указана сущность, для которой запускается бизнес-процесс.";
$MESS ['BPATT_NO_DOCUMENT_TYPE'] = "Не указан тип документа.";
$MESS ['BPATT_NO_MODULE_ID'] = "Не указан модуль.";
$MESS ['BPATT_AE_EDIT'] = "Изменение";
$MESS ['BPATT_NO_PERMS'] = "Доступ запрещен.";
$MESS ['BPATT_DO_EDIT1'] = "Изменить";
$MESS ['BPATT_DO_DELETE1'] = "Удалить";
$MESS ['BPATT_DO_DELETE1_CONFIRM'] = "Вы уверены, что хотите удалить этот шаблон?";
$MESS ['BPATT_DO_N_LOAD_CREATE_TITLE'] = "Не запускать бизнес-процесс при создании документов";
$MESS ['BPATT_DO_N_LOAD_CREATE'] = "Не запускать при создании";
$MESS ['BPATT_DO_LOAD_CREATE_TITLE'] = "Запускать бизнес-процесс при создании документов";
$MESS ['BPATT_DO_LOAD_CREATE'] = "Запускать при создании";
$MESS ['BPATT_DO_N_LOAD_EDIT_TITLE'] = "Не запускать бизнес-процесс при изменении документов";
$MESS ['BPATT_DO_N_LOAD_EDIT'] = "Не запускать при изменении";
$MESS ['BPATT_DO_LOAD_EDIT_TITLE'] = "Запускать бизнес-процесс при изменении документов";
$MESS ['BPATT_DO_LOAD_EDIT'] = "Запускать при изменении";
$MESS ['BPATT_DO_EDIT_VARS'] = "Изменить начальные значения переменных";
$MESS ['BPATT_DO_EDIT_VARS1'] = "Переменные";
$MESS ['BPATT_DO_EDIT_CONSTANTS'] = "Задать значения констант";
$MESS ['BPATT_DO_EDIT_CONSTANTS1'] = "Константы";
?>