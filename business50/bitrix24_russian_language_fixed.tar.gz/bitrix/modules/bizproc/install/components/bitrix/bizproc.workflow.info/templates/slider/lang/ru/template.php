<?php

$MESS['BPWFI_SLIDER_TASK'] = 'Задание';
$MESS['BPWFI_SLIDER_TIMELINE_MSGVER_1'] = 'Протокол';
$MESS['BPWFI_SLIDER_DOCUMENT'] = 'Элемент';
$MESS['BPWFI_SLIDER_NAME'] = 'Название';
$MESS['BPWFI_SLIDER_TYPE'] = 'Тип процесса';
$MESS['BPWFI_SLIDER_DESCRIPTION'] = 'Описание';
$MESS['BPWFI_SLIDER_NOT_MY_TASK'] = 'Вы открыли задание сотрудника #USER#';
$MESS['BPWFI_SLIDER_DISCUSSION_TITLE'] = 'Обсуждение процесса';
$MESS['BPWFI_SLIDER_DISCUSSION_COMMENTS_COUNT'] = 'Комментариев: #COMMENTS_COUNT#';
$MESS['BPWFI_SLIDER_DISCUSSION_ZERO_COMMENTS_COUNT'] = 'Комментариев к процессу пока нет';
$MESS['BPWFI_SLIDER_BANNER_TITLE'] = 'Комментариев к процессу пока нет';
$MESS['BPWFI_SLIDER_BANNER_BODY'] = 'Оставляйте комментарии и задавайте вопросы участникам процесса';
$MESS['BPWFI_SLIDER_FIELDS_TITLE'] = 'Поля для заполнения';
$MESS['BPWFI_SLIDER_BUTTON_DELEGATE'] = 'Делегировать';

$MESS['BPWFI_SLIDER_CONFIRM_TITLE'] = 'Отменить изменения в карточке процесса?';
$MESS['BPWFI_SLIDER_CONFIRM_DESCRIPTION'] = 'Если вы отмените изменения в карточке процесса, информация в полях не сохранится';
$MESS['BPWFI_SLIDER_CONFIRM_ACCEPT'] = 'Да, отменить';
$MESS['BPWFI_SLIDER_CONFIRM_CANCEL'] = 'Не отменять';