<?
$MESS ['BPWC_WNCT_2LIST'] = "Список бизнес-процессов";
$MESS ['BPWC_WNCT_SUBTITLE1'] = "Создание нового бизнес-процесса";
$MESS ['BPWC_WNCT_SUBTITLE11'] = "Изменение бизнес-процесса";
$MESS ['BPWC_WNCT_NAME'] = "Название бизнес-процесса";
$MESS ['BPWC_WNCT_DESCR'] = "Описание бизнес-процесса";
$MESS ['BPWC_WNCT_SORT'] = "Индекс сортировки бизнес-процесса";
$MESS ['BPWC_WNCT_ICON'] = "Иконка бизнес-процесса";
$MESS ['BPWC_WNCT_PS'] = "Множественное название элементов бизнес-процесса";
$MESS ['BPWC_WNCT_P'] = "Единственное название элементов бизнес-процесса";
$MESS ['BPWC_WNCT_PERMS'] = "Кто имеет право видеть бизнес-процесс";
$MESS ['BPWC_WNCT_TMPL'] = "Шаблон бизнес-процесса";
$MESS ['BPWC_WNCT_NEW_TMPL'] = "Новый шаблон (последовательный)";
$MESS ['BPWC_WNCT_NEW_TMPL_1'] = "Новый шаблон (со статусами)";
$MESS ['BPWC_WNCT_SUBTITLE2'] = "Настройка нового бизнес-процесса";
$MESS ['BPWC_WNCT_SAVE1'] = "Создать бизнес-процесс";
$MESS ['BPWC_WNCT_SAVE2'] = "Далее";
$MESS ['BPWC_WNCT_CANCEL'] = "Отмена";
$MESS ['BPWC_WNCT_EADD'] = "Подпись 'Добавить элемент'";
$MESS ['BPWC_WNCT_SAVE0'] = "Изменить";
$MESS ['BPWC_WNCT_FILTERABLEFIELDS'] = "Поля, доступные для фильтрования";
$MESS ['BPWC_WNCT_VISIBLEFIELDS'] = "Поля, доступные для просмотра";
$MESS ['BPWC_WNCT_COMP_START_TPL'] = "Шаблон компонента запуска бизнес-процесса";
$MESS ['BPWC_WNCT_COMP_LIST_TPL'] = "Шаблон компонента списка бизнес-процессов";
$MESS ['BPWC_WNCT_COMP_VIEW_TPL'] = "Шаблон компонента бизнес-процесса";
$MESS ['BPWC_WNCT_COMP_TPL_DEF'] = "(по-умолчанию)";
?>