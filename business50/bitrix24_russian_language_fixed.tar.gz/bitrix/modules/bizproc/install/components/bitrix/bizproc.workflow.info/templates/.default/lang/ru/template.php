<?
$MESS['BPWFITPL_DOC_HISTORY'] = "История изменений документа";
$MESS['BPWFITPL_COMMENTS'] = "Комментарии";