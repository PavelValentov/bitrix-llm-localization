<?php
$MESS["BIZPROC_AUTOMATION_TITLE"] = "Роботы";
$MESS["BIZPROC_MODULE_NOT_INSTALLED"] = "Модуль bizproc не установлен.";
$MESS["BIZPROC_AUTOMATION_NOT_SUPPORTED"] = "Функционал компонента недоступен для данной сущности.";
$MESS["BIZPROC_AUTOMATION_ACCESS_DENIED"] = "У вас нет доступа к запрашиваемой сущности";
$MESS["BIZPROC_AUTOMATION_NO_EDIT_PERMISSIONS"] = "Недостаточно прав для настройки автоматизации";
$MESS["BIZPROC_AUTOMATION_NOT_AVAILABLE"] = "Использование роботов недоступно";
$MESS["BIZPROC_AUTOMATION_TO_HEAD"] = "Руководителю";
$MESS["BIZPROC_AUTOMATION_DELAY_MIN_LIMIT"] = "Минимальный период ожидания: #VAL#";