<?
$MESS ['BPWC_WLCT_NEW'] = "Новая заявка";
$MESS ['BPWC_WLCT_VARS'] = "Переменные бизнес-процесса";
$MESS ['BPWC_WLCT_BP'] = "Бизнес-процесс";
$MESS ['BPWC_WLCT_F_NAME'] = "Название";
$MESS ['BPWC_WLCT_F_STATUS'] = "Статус";
$MESS ['BPWC_WLCT_F_DATE'] = "Дата";
$MESS ['BPWC_WLCT_F_TYPE'] = "Тип";
$MESS ['BPWC_WLCT_F_RESULT'] = "Результат";
$MESS ['BPWC_WLCT_F_NOTE'] = "Примечание";
$MESS ['BPWC_WLCT_SAVE'] = "Сохранить";
$MESS ['BPWC_WLCT_STOP'] = "Остановить";
$MESS ['BPWC_WLCT_LIST'] = "Список бизнес-процессов";
$MESS ['BPWC_WLCT_F_AUTHOR'] = "Автор";
$MESS ['BPWC_WLCT_TOTAL'] = "Всего";
?>