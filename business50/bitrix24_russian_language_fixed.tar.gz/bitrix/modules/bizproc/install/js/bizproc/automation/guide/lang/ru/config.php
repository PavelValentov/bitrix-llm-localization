<?php

$MESS['BIZPROC_JS_WOW_MOMENT_CRM_HOW_CHECK_TRIGGER_TITLE'] = 'Как проверить настройки триггера?';
$MESS['BIZPROC_JS_WOW_MOMENT_CRM_HOW_CHECK_TRIGGER_TEXT'] = 'Чтобы увидеть ваш триггер в действии, имитируйте в любом элементе действие, указанное в названии триггера. Например, заполните форму. Проверьте, изменилась ли стадия у элемента. После этого откройте элемент для просмотра результата';
$MESS['BIZPROC_JS_WOW_MOMENT_CRM_HOW_CHECK_ROBOT_TITLE'] = 'Как проверить настройки робота?';
$MESS['BIZPROC_JS_WOW_MOMENT_CRM_HOW_CHECK_ROBOT_TEXT'] = 'Чтобы увидеть вашего робота в действии, перенесите любой элемент на ту стадию, где настроен робот. После этого откройте элемент для просмотра результата';

$MESS['BIZPROC_JS_WOW_MOMENT_CRM_CHECK_AUTOMATION_TITLE'] = 'Посмотрите, как отработала автоматизация';
$MESS['BIZPROC_JS_WOW_MOMENT_CRM_CHECK_AUTOMATION_TEXT'] = 'Перейдите на вкладку роботы и посмотрите, как отработали ваши роботы и триггеры';
$MESS['BIZPROC_JS_WOW_MOMENT_CRM_SUCCESS_AUTOMATION_TITLE'] = 'Статусы роботов и триггеров';
$MESS['BIZPROC_JS_WOW_MOMENT_CRM_SUCCESS_AUTOMATION_TEXT'] = 'Обратите внимание, что успешно отработанные роботы и триггеры выделены зеленым цветом.
<br/>Узнайте подробнее о других статусах в статье';
