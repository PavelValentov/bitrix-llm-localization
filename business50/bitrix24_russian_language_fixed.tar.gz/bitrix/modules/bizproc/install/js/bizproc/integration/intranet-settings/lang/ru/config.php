<?php

$MESS['BIZPROC_INTRANET_SETTINGS_TITLE_PAGE_AUTOMATION'] = 'Автоматизация';
$MESS['BIZPROC_INTRANET_SETTINGS_DESCRIPTION_PAGE_AUTOMATION'] = 'Автоматизация поможет сократить время на выполнение рутинных задач, снизить нагрузку на сотрудников и сделать процессы в компании более прозрачными';