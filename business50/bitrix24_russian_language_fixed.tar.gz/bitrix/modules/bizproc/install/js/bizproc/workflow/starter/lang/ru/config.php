<?php

$MESS['BIZPROC_JS_WORKFLOW_STARTER_EMPTY_TEMPLATES'] = 'Нет ни одного шаблона бизнес-процессов';
$MESS['BIZPROC_JS_WORKFLOW_STARTER_REQUEST_FAILED'] = 'Во время запроса произошла ошибка. Попробуйте перезагрузить страницу';
