<?php
$MESS['BIZPROC_SCRIPT_MANAGER_START_NOTHING_SELECTED'] = 'Ничего не выбрано';
$MESS['BIZPROC_SCRIPT_MANAGER_START_TEXT_START'] = 'Сценарий будет запущен для всех выбранных элементов. Выбрано: #CNT#.';
$MESS['BIZPROC_SCRIPT_MANAGER_START_BUTTON_START'] = 'Запустить';
$MESS['BIZPROC_SCRIPT_MANAGER_START_QUEUED'] = 'Сценарий успешно запущен';
$MESS['BIZPROC_SCRIPT_MANAGER_START_FINISHED'] = 'Выполнение сценария завершено';
$MESS['BIZPROC_SCRIPT_MANAGER_START_BUTTON_SEND_PARAMS'] = 'Отправить';
$MESS['BIZPROC_SCRIPT_MANAGER_START_PARAMS_POPUP_TITLE'] = 'Параметры сценария';
