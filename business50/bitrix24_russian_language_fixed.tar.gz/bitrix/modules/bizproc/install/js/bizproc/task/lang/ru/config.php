<?php

$MESS['BIZPROC_TASK_STATUS_YES'] = 'Вы утвердили документ';
$MESS['BIZPROC_TASK_STATUS_NO'] = 'Вы отклонили документ';
$MESS['BIZPROC_TASK_STATUS_OK'] = 'Вы ознакомились с документом';

$MESS['BIZPROC_TASK_DEFAULT_TASK_BUTTON'] = 'Приступить';
