<?
$MESS ['BPMC_EMPTY_CONDITION'] = "Условие не указано";
?>