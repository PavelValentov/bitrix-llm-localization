<?
$MESS ['BPC_DESCR_DESCR'] = "PHP код";
$MESS ['BPC_DESCR_NAME'] = "PHP код";
?>