<?php

$MESS['BPSWFA_ERROR_DOCUMENT_ID'] = "Не указан ID документа";
$MESS['BPSWFA_ERROR_TEMPLATE'] = "Не выбран шаблон";
$MESS['BPSWFA_TEMPLATE_PARAMETERS'] = "Параметры бизнес-процесса";
$MESS['BPSWFA_TEMPLATE_PARAMETERS_ERROR'] = "Не заполнен обязательный параметр: #NAME#";
$MESS['BPSWFA_START_ERROR'] = "Ошибка запуска: #MESSAGE#";
$MESS['BPSWFA_SELFSTART_ERROR'] = "Рекурсивный запуск шаблона заблокирован";
$MESS['BPSWFA_ACCESS_DENIED_1'] = 'Настройки действия доступны только администраторам портала.';
$MESS['BPSWFA_RPD_DOCUMENT_ID'] = 'ID документа';
$MESS['BPSWFA_DOCTYPE_NOT_FOUND_ERROR'] = 'Не удалось найти целевой документ (указан неверный ID?)';
$MESS['BPSWFA_DOCTYPE_ERROR_1'] = 'Тип документа не соответствует типу из целевого шаблона Бизнес-процесса';
$MESS['BPSWFA_RPD_ENTITY'] = "Сущность";
$MESS['BPSWFA_RPD_DOCUMENT_TYPE'] = "Тип документа";
$MESS['BPSWFA_RPD_TEMPLATE'] = "Шаблон";
$MESS['BPSWFA_RPD_USE_SUBSCRIPTION'] = "Ожидать завершения бизнес-процесса";
$MESS['BPSWFA_TEMPLATE_NOT_FOUND_ERROR'] = 'Не удалось найти целевой шаблон';
