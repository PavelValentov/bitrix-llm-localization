<?php

$MESS['BPSNMA_DESCR_NAME'] = 'Сообщение соц.сети';
$MESS['BPSNMA_DESCR_DESCR_1'] = 'Отправляет уведомление сотруднику от выбранного отправителя';
$MESS['BPSNMA_DESCR_ROBOT_TITLE_1'] = 'Добавить уведомление';

