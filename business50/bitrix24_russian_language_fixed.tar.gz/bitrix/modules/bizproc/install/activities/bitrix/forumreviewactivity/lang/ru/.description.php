<?
$MESS ['BPSNMA_DESCR_NAME'] = "Запись в форум";
$MESS ['BPSNMA_DESCR_DESCR'] = "Запись в форум";
?>