<?
$MESS ['BPSNMA_EMPTY_CALENDARUSER'] = "Свойство 'Пользователь' не указано.";
$MESS ['BPSNMA_EMPTY_CALENDARNAME'] = "Свойство 'Название события' не указано.";
$MESS ['BPSNMA_EMPTY_CALENDARFROM'] = "Свойство 'Дата начала' не указано.";
$MESS ['BPSNMA_EMPTY_CALENDARTO'] = "Свойство 'Дата окончания' не указано.";
?>