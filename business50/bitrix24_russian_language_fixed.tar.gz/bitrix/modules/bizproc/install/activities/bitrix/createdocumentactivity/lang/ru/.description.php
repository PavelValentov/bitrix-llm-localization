<?php

$MESS ['BPCDA_DESCR_DESCR'] = "Создание нового документа";
$MESS ['BPCDA_DESCR_NAME'] = "Создание нового документа";
$MESS ['BPCDA_DESCR_ERROR_MESSAGE'] = "Текст ошибки создания";
$MESS ['BPCDA_CREATED_ITEM_ID'] = "ID созданного документа";
