<?php

$MESS["BPRDA_PROPERTY_WAIT_WORKDAY_USER_NAME"] = "Ожидать начала рабочего дня сотрудника";
$MESS["BPRDA_SUBSCRIBED"] = "Ожидание начала или продолжения рабочего дня сотрудника: #user#";
