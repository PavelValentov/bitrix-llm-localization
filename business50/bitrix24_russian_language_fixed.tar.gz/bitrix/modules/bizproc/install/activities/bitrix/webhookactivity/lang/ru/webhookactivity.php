<?php

$MESS['BPWHA_HANDLER_NAME'] = 'Хендлер';
$MESS['BPWHA_EMPTY_TEXT'] = 'Не указан хендлер';
