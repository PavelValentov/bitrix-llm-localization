<?php

$MESS ['BPRIOA_ACT_TRACK1'] = "Предоставить дополнительную информацию должен #VAL#";
$MESS ['BPRIOA_ACT_INFO'] = "Ожидание дополнительной информации";
$MESS ['BPRIOA_LOG_COMMENTS'] = "Комментарий";
$MESS ['BPRIOA_ACT_APPROVE_TRACK'] = "Пользователь #PERSON# ввел дополнительную информацию#COMMENT#";
$MESS ['BPRIOA_ACT_CANCEL_TRACK'] = "Пользователь #PERSON# отменил ввод дополнительной информации#COMMENT#";
$MESS ['BPRIOA_ACT_COMMENT'] = "Комментарий";
$MESS ['BPRIOA_ACT_BUTTON1'] = "Сохранить";
$MESS ['BPRIOA_ARGUMENT_NULL'] = "Не заполнено обязательное значение '#PARAM#'";
$MESS ['BPRIOA_ACT_PROP_EMPTY1'] = "Свойство 'Пользователи' не указано.";
$MESS ['BPRIOA_ACT_PROP_EMPTY4'] = "Свойство 'Название' не указано.";
$MESS ['BPRIOA_ACT_PROP_EMPTY2'] = "Не указано ни одного поля.";
$MESS ['BPRIOA_ACT_BUTTON2'] = "Отклонить";
$MESS ['BPRIOA_ACT_COMMENT_ERROR'] = "Не заполнено поле: #COMMENT_LABEL#";

$MESS["BPRIA_PD_CANCEL_TYPE"] = "Тип отклонения";
$MESS["BPRIA_PD_CANCEL_TYPE_ANY"] = "Любой сотрудник";
$MESS["BPRIA_PD_CANCEL_TYPE_ALL"] = "Все сотрудники";
$MESS["BPAR_PD_TASK_BUTTON_CANCEL_MESSAGE_MSGVER_1"] = "Текст кнопки отклонения в задании";
$MESS["BPSFA_PD_CANCEL"] = "Отмена";
$MESS["BPRIA_PD_SAVE_VARIABLES"] = 'Сохранять значения в случае отказа';
$MESS["BPSFA_PD_YES"] = "Да";
$MESS["BPSFA_PD_NO"] = "Нет";

$MESS['BPSFA_COMMENT_REQUIRED_YA'] = 'Только при утверждении';
$MESS['BPSFA_COMMENT_REQUIRED_YR'] = 'Только при отклонении';
