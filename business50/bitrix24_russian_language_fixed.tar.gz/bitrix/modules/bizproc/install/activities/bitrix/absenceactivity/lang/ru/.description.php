<?
$MESS ['BPAA2_DESCR_DESCR'] = "Добавление события в график отсутствия";
$MESS ['BPAA2_DESCR_NAME'] = "График отсутствия";
?>