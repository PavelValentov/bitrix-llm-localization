<?php

$MESS["BPGUIA_TARGET_USER_NAME"] = "Сотрудник";
$MESS["BPGUIA_ERROR_USER_NOT_FOUND"] = "Сотрудник с ID=#ID# не найден";
$MESS["BPGUIA_ERROR_1"] = "Не указан целевой сотрудник";
$MESS["BPGUIA_ERROR_2"] = "Некорректный целевой сотрудник (Недостаточно прав)";
$MESS["BPGUIA_TIMEMAN_STATUS"] = "Статус рабочего дня";
$MESS["BPGUIA_IS_ABSENT"] = "Отсутствует (по графику отсутствий)";
