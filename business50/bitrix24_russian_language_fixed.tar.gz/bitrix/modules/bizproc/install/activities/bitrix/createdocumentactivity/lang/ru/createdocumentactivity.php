<?php

$MESS['BPCDA_FIELD_REQUIED'] = "Поле '#FIELD#' обязательно для заполнения.";
$MESS['BPCDA_RECURSION_ERROR_1'] = 'Рекурсивный запуск действия заблокирован';
