<?
$MESS ['BPIEBA_DESCR_DESCR'] = "Ветка условия";
$MESS ['BPIEBA_DESCR_NAME'] = "Условие";
?>