<?php

$MESS['BP_FRA_DESCR_NAME'] = 'Установить результат бизнес-процесса';
$MESS['BP_FRA_DESCR_DESCR'] = 'Позволяет выбрать результат выполнения бизнес-процесса';
$MESS['BP_FRA_DESCR_ERROR_MESSAGE'] = 'Не удалось сохранить результат';
