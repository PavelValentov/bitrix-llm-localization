<?
$MESS ['BPSPA_DESCR_NAME'] = "Установка прав";
$MESS ['BPSPA_DESCR_DESCR'] = "Установка прав на доступ к документу.";
?>