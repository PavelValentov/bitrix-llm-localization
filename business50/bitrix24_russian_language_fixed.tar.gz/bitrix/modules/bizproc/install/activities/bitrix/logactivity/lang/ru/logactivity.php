<?
$MESS ['BPCAL_EMPTY_TEXT'] = "Не указан текст сообщения";
?>