<?php

$MESS['BPFEA_NO_SOURCE'] = 'Не указан источник';
