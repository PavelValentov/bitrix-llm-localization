<?
$MESS ['BPSVA_DESCR_NAME'] = "Изменение переменных";
$MESS ['BPSVA_DESCR_DESCR'] = "Изменение переменных";
?>