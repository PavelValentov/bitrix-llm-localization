<?
$MESS ['BPSNMA_EMPTY_ABSENCEUSER'] = "Свойство 'Пользователь' не указано.";
$MESS ['BPSNMA_EMPTY_ABSENCENAME'] = "Свойство 'Название события' не указано.";
$MESS ['BPSNMA_EMPTY_ABSENCEFROM'] = "Свойство 'Дата начала' не указано.";
$MESS ['BPSNMA_EMPTY_ABSENCETO'] = "Свойство 'Дата окончания' не указано.";
$MESS ['BPAA2_NO_PERMS'] = "У вас нет прав на запись в календарь отсутствий.";
?>