<?
$MESS ['SEQWF_END'] = "Конец";
$MESS ['SEQWF_BEG'] = "Начало";
$MESS['SEQWF_CONF_1'] = 'Выбранное действие будет удалено из списка ваших действий. Продолжить?';
$MESS['SEQWF_SNIP_NAME'] = 'Название:';
$MESS['SEQWF_SNIP_DEL_1'] = 'Удалить это действие';
$MESS['SEQWF_SNIP_TITLE_1'] = 'Свойства избранного действия';
$MESS['SEQWF_SNIP_DD_1'] = 'Перетащите сюда действие для сохранения';
$MESS['SEQWF_SNIP_1'] = 'Мои действия';
$MESS['SEQWF_MARKETPLACE_ADD'] = 'Добавить еще...';
?>