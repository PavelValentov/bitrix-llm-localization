<?
$MESS ['INTE_ADD_TASK_DATES_EMPTY'] = "нет";
$MESS ['INTASK_TO_DATE_TLP'] = "до #DATE#";
$MESS ['INTASK_FROM_DATE_TLP'] = "с #DATE#";
$MESS ['INTAST_T6654_LOG'] = "Статус: #STATUS#
Важность: #PRIORITY#
Срок: #TIME#
Ответственный: #RESP#";
?>