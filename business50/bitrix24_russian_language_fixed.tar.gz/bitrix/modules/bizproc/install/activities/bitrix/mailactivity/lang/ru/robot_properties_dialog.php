<?
$MESS["BPMA_RPD_FROM_EMPTY"] = "Не выбрано";
$MESS["BPMA_RPD_FROM_ADD"] = "Добавить отправителя";
?>