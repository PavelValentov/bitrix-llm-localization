<?
$MESS ['BPPVC_DESCR_DESCR'] = "Значение переменной или параметра";
$MESS ['BPPVC_DESCR_NAME'] = "Значение переменной";
?>