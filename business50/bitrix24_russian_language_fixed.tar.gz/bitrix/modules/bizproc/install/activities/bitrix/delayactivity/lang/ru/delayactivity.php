<?php

$MESS['BPDA_EMPTY_PROP'] = "Свойство 'Период' не указано.";
$MESS['BPDA_TRACK1'] = "Отложено до #PERIOD#";
$MESS['BPDA_TRACK2'] = "Не задан период откладывания";
$MESS['BPDA_TRACK3'] = "Пауза пропущена. Вычисленное время паузы меньше текущего времени";
$MESS['BPDA_TRACK4'] = "Отложено на #PERIOD1#, до #PERIOD2#";
$MESS['BPDA_SUBSCRIBE_ERROR_MSGVER_1'] = "В процессе постановки задания планировщика произошла системная ошибка";
$MESS['BPDA_DEBUG_EVENT'] = "Пауза пропущена по событию отладчика";
