<?php

$MESS["BPRDA_DESCR_NAME"] = "Пауза робота";
$MESS["BPRDA_DESCR_DESCR"] = "Действие позволяет управлять паузами в роботах";
