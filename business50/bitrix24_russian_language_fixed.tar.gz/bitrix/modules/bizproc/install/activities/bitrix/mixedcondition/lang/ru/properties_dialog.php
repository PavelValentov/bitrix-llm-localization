<?php

$MESS['BPMC_PD_ADD'] = "Добавить условие";
$MESS['BPMC_PD_AND'] = "И";
$MESS['BPMC_PD_OR'] = "ИЛИ";
$MESS['BPMC_PD_CONDITION'] = "Условие";
$MESS['BPMC_PD_DELETE'] = "Удалить";
$MESS['BPMC_PD_FIELD'] = "Источник";
$MESS['BPMC_PD_VALUE'] = "Значение";
