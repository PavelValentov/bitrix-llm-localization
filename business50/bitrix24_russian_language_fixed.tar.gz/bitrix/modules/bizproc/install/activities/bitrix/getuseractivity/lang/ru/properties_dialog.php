<?
$MESS["BPCRU_PD_TYPE"] = "Тип";
$MESS["BPCRU_PD_USER_RANDOM"] = "Из пользователей";
$MESS["BPCRU_PD_USER_BOSS"] = "Для пользователя";
$MESS["BPCRU_PD_USER2"] = "Резервные пользователи";
$MESS["BPCRU_PD_MAX_LEVEL"] = "Уровень начальника (чем больше, тем выше уровень)";
$MESS["BPCRU_PD_TYPE_RANDOM"] = "случайный";
$MESS["BPCRU_PD_TYPE_BOSS"] = "начальник";
$MESS["BPCRU_PD_TYPE_ORDER"] = "последовательный";
$MESS["BPCRU_PD_MAX_LEVEL_1"] = "1 (непосредственный начальник)";
$MESS["BPCRU_PD_SKIP_ABSENT"] = "Пропускать отсутствующих";
$MESS["BPCRU_PD_SKIP_TIMEMAN"] = "Пропускать с завершенным рабочим днем";
$MESS["BPCRU_PD_YES"] = "Да";
$MESS["BPCRU_PD_NO"] = "Нет";
$MESS["BPCRU_PD_SKIP_RESERVE"] = "Применить к резервным";