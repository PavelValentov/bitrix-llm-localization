<?php

$MESS['BPWHA_DESCR_DESCR_1'] = 'Передаёт информацию в другие системы с помощью Вебхука';
$MESS['BPWHA_DESCR_NAME_1'] = 'Исходящий Вебхук';
