<?
$MESS ['BPWA_CONDITION_NOT_SET'] = "Не установлено условие выполнения цикла";
$MESS ['BPWA_NO_CONDITION'] = "Условие не найдено";
$MESS ['BPWA_INVALID_CONDITION_TYPE'] = "Тип условия не найден";
$MESS ['BPWA_CYCLE_LIMIT'] = "Превышен лимит итераций цикла";
?>