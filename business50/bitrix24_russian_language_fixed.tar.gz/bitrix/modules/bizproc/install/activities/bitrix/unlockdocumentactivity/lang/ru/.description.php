<?
$MESS ['BPUDA_DESCR_NAME'] = "Разблокировка документа";
$MESS ['BPUDA_DESCR_DESCR'] = "Разблокировка документа";
?>