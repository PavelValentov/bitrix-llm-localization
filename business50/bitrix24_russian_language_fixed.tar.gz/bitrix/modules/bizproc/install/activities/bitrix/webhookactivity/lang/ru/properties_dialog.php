<?
$MESS ['BPWHA_PD_TEXT'] = "Хендлер";
?>