<?
$MESS ['BPCA_DESCR_DESCR'] = "Выполнение произвольного PHP кода";
$MESS ['BPCA_DESCR_NAME'] = "PHP код";
?>