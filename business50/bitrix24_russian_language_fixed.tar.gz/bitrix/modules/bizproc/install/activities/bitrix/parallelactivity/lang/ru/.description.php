<?
$MESS ['BPPA_DESCR_DESCR'] = "Выполнение действий параллельно";
$MESS ['BPPA_DESCR_NAME'] = "Параллельное выполнение";
?>