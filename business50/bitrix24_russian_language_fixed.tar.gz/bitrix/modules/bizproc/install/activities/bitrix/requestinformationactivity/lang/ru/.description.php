<?
$MESS ['BPRIA_DESCR_NAME_1'] = "Запрос дополнительной информации";
$MESS ['BPRIA_DESCR_DESCR_1'] = "Запрос дополнительной информации";
$MESS ['BPAA_DESCR_CM'] = "Комментарий";
$MESS ['BPAA_DESCR_LU'] = "Пользователь, предоставивший информацию";
$MESS ['BPAA_DESCR_TA1'] = "Автоматическое завершение";
$MESS ['BPAA_DESCR_TASKS'] = 'Задания';
$MESS ['BPAA_DESCR_CHANGES'] = "Измененные поля";
?>