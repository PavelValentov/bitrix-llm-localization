<?php

$MESS['BPMA_DESCR_NAME'] = 'Почтовое сообщение';
$MESS['BPMA_DESCR_ROBOT_TITLE'] = 'Отправить письмо сотруднику';
$MESS['BPMA_DESCR_DESCR_1'] = 'Отправляет письмо сотруднику от выбранного отправителя';
