<?
$MESS ['APPR_NO'] = "Нет";
$MESS ['APPR_YES'] = "Да";
?>