<?php

$MESS ['BPAR_ACT_COMMENT'] = "Комментарий";
$MESS ['BPAR_ACT_INFO'] = "Ознакомлено #PERCENT#% (#REVIEWED# из #TOTAL#)";
$MESS ['BPAR_ACT_BUTTON2'] = "Ознакомлен";
$MESS ['BPAR_ACT_REVIEWED'] = "Ознакомление с документом завершено.";
$MESS ['BPAR_ACT_TRACK3'] = "Ознакомление с документом пользователями из списка: #VAL#";
$MESS ['BPAR_ACT_REVIEW_TRACK'] = "Пользователь #PERSON# ознакомился с документом#COMMENT#";
$MESS ['BPAR_ACT_PROP_EMPTY1'] = "Свойство 'Пользователи' не указано.";
$MESS ['BPAR_ACT_PROP_EMPTY4'] = "Свойство 'Название' не указано.";
$MESS ['BPAA_ACT_APPROVERS_NONE'] = "нет";
$MESS ['BPAA_ACT_NO_ACTION'] = "Неверно указано действие";
$MESS ['BPAA_ACT_COMMENT_ERROR'] = "Не заполнено поле: #COMMENT_LABEL#";
