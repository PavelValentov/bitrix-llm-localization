<?
$MESS ['BPTC_DESCR_DESCR'] = "Истина";
$MESS ['BPTC_DESCR_NAME'] = "Истина";
?>