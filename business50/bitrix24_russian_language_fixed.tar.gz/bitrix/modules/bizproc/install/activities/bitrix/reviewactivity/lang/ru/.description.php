<?
$MESS ['BPAR_DESCR_NAME'] = "Ознакомление с документом";
$MESS ['BPAR_DESCR_DESCR'] = "Ознакомление с документом с возможностью оставить отзыв на него.";
$MESS ['BPAR_DESCR_RC'] = "Сколько ознакомлено";
$MESS ['BPAR_DESCR_TC'] = "Сколько должно быть ознакомлено";
$MESS ['BPAR_DESCR_TA1'] = "Автоматическое ознакомление";
$MESS ['BPAA_DESCR_CM'] = "Комментарии";
$MESS ['BPAR_DESCR_LR'] = "Последний ознакомившийся";
$MESS ['BPAR_DESCR_LR_COMMENT'] = "Комментарий последнего ознакомившегося";
$MESS ['BPAR_DESCR_TASKS'] = 'Задания';
?>