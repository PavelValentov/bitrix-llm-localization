<?
$MESS ['BPFC_DESCR_DESCR'] = "Поле документа";
$MESS ['BPFC_DESCR_NAME'] = "Поле документа";
?>