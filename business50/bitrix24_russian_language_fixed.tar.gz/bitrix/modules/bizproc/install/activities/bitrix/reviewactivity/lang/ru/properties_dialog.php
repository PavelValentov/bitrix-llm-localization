<?
$MESS["BPAR_PD_REVIEWERS"] = "Ознакомить пользователей";
$MESS["BPAR_PD_DESCR"] = "Описание задания";
$MESS["BPAR_PD_NAME"] = "Название задания";
$MESS["BPAR_PD_APPROVE_TYPE"] = "Должны ознакомиться";
$MESS["BPAR_PD_APPROVE_TYPE_ALL"] = "Все сотрудники";
$MESS["BPAR_PD_APPROVE_TYPE_ANY"] = "Любой сотрудник";
$MESS["BPAR_PD_SET_STATUS_MESSAGE"] = "Устанавливать текст статуса";
$MESS["BPAR_PD_YES"] = "Да";
$MESS["BPAR_PD_NO"] = "Нет";
$MESS["BPAR_PD_STATUS_MESSAGE"] = "Текст статуса";
$MESS["BPAR_PD_TASK_BUTTON_MESSAGE"] = "Текст кнопки в задании";
$MESS["BPAR_PD_TIMEOUT_DURATION"] = "Период ознакомления";
$MESS["BPAR_PD_TIMEOUT_DURATION_HINT"] = "По окончании периода ознакомление будет автоматически завершено. Пустое значение или 0 - отсутствие периода.";
$MESS["BPAR_PD_TIME_D"] = "дней";
$MESS["BPAR_PD_TIME_H"] = "часов";
$MESS["BPAR_PD_TIME_M"] = "минут";
$MESS["BPAR_PD_TIME_S"] = "секунд";
$MESS["BPAR_PD_STATUS_MESSAGE_HINT1"] = "Можно использовать модификаторы #PERCENT# - процент, #REVIEWED# - ознакомлено человек, #TOTAL# - всего должно быть ознакомлено, #REVIEWERS# - кто ознакомлен";
$MESS["BPAR_PD_SHOW_COMMENT"] = "Показывать поле ввода комментария";
$MESS["BPAR_PD_COMMENT_REQUIRED"] = "Обязательность комментария";
$MESS["BPAR_PD_COMMENT_LABEL_MESSAGE"] = "Метка для поля комментария";
$MESS["BPAR_PD_ACCESS_CONTROL"] = "Ограничить доступ";
$MESS["BPAR_PD_TIMEOUT_LIMIT"] = "Минимальный период ознакомления";
$MESS["BPAR_PD_DELEGATION_TYPE"] = "Тип делегирования";
?>