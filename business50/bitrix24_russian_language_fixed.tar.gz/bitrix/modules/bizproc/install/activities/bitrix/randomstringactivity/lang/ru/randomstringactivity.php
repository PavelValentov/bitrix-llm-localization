<?
$MESS ['BPRNDSA_SIZE_NAME'] = "Длина строки";
$MESS ['BPRNDSA_ALPHABET_NAME'] = "Алфавит";
$MESS ['BPRNDSA_ALPHABET_NUM'] = "Числа";
$MESS ['BPRNDSA_ALPHABET_ALPHALOWER'] = "Прописные буквы";
$MESS ['BPRNDSA_ALPHABET_ALPHAUPPER'] = "Заглавные буквы";
$MESS ['BPRNDSA_ALPHABET_SPECIAL'] = "Специальные символы";
$MESS ['BPRNDSA_EMPTY_SIZE'] = "Не указана длина строки";
$MESS ['BPRNDSA_EMPTY_ALPHABET'] = "Не указан алфавит";
$MESS ['BPRNDSA_RESULT_STRING'] = "Код";
?>