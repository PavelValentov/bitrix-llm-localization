<?
$MESS ['BPLA_INVALID_ACTIVITY_1'] = "Действие типа 'ListenActivity' может содержать в себе только действия типа 'EventDrivenActivity'.";
?>