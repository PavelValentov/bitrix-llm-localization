<?
$MESS ['BPCC_PD_CODE'] = "PHP код условия";
?>