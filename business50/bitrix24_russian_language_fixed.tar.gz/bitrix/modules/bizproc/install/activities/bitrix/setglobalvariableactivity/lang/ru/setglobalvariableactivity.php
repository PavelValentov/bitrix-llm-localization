<?php

$MESS['BPSGCA_EMPTY_VARIABLES'] = 'Не указано значение ни одной глобальной переменной';
$MESS['BPSGVA_TEXT'] = 'Своё значение';
$MESS['BPSGVA_DOCUMENT'] = 'Значение поля';

$MESS['BPSGVA_VARIABLE'] = 'Выбрать переменную';
$MESS['BPSGVA_PARAMETER'] = 'Выбрать параметр';
$MESS['BPSGVA_TYPE_OF_PARAMETER'] = 'Тип параметра';
$MESS['BPSGVA_LIST_OF_VALUES'] = 'Список значений';
$MESS['BPSGVA_EMPTY'] = 'Не выбрано';
$MESS['BPSGVA_INPUT_TEXT'] = 'Введите значение';

$MESS['BPSGVA_BOOL_YES'] = 'Да';
$MESS['BPSGVA_BOOL_NO'] = 'Нет';
$MESS['BPSGVA_ADD_VARIABLE'] = '+ добавить переменную';
$MESS['BPSGVA_ADD_PARAMETER'] = '+ добавить параметр';
$MESS['BPSGVA_CLEAR'] = 'Очистить';

$MESS['BPSGVA_CREATE_GVARIABLE'] = 'Создать переменную';
$MESS['BPSGVA_GVARIABLE_NO_EXIST'] = 'Переменных пока нет';
$MESS['BPSGVA_GVARIABLE_NOT_FOUND'] = 'Переменная не найдена';
$MESS['BPSGVA_CREATE_GVARIABLE_QUESTION'] = 'Создать новую переменную?';

$MESS['BPSGVA_CREATE_GCONSTANT'] = 'Создать константу';
$MESS['BPSGVA_GCONSTANT_NO_EXIST'] = 'Констант пока нет';
$MESS['BPSGVA_GCONSTANT_NOT_FOUND'] = 'Константа не найдена';
$MESS['BPSGVA_CREATE_GCONSTANT_QUESTION'] = 'Создать новую константу?';