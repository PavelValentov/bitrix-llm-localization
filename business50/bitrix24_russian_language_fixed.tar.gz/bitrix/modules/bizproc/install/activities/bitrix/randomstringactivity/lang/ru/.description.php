<?php

$MESS['BPRNDSA_DESCR_NAME'] = 'Сгенерировать код';
$MESS['BPRNDSA_DESCR_RESULT_STRING'] = 'Код';
$MESS['BPRNDSA_DESCR_DESCR_MSGVER_1'] = 'Генерирует код, который можно сохранить в карточке элемента. Вспомогательный робот';
