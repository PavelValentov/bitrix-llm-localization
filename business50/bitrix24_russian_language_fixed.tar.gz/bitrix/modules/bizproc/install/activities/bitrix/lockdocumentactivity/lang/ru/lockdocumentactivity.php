<?
$MESS ["BPLDA_SUBSCRIBE_ON_UNLOCK"] = "Ожидание разблокировки документа";
?>