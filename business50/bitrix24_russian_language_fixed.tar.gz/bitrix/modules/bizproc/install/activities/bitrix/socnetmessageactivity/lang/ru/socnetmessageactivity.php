<?
$MESS["BPSNMA_EMPTY_MESSAGE"] = "Свойство 'Текст сообщения' не указано.";
$MESS["BPSNMA_EMPTY_TO"] = "Свойство 'Получатель' не указано.";
$MESS["BPSNMA_EMPTY_FROM"] = "Свойство 'Отправитель' не указано.";
$MESS["BPSNMA_MESSAGE"] = "Текст сообщения";
$MESS["BPSNMA_TO"] = "Получатель сообщения";
$MESS["BPSNMA_FROM"] = "Отправитель сообщения";
$MESS["BPSNMA_FORMAT_ROBOT"] = "Уведомление Робот";
?>