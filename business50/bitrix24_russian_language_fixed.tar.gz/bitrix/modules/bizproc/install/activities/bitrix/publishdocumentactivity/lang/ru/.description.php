<?
$MESS ['BPPDA_DESCR_NAME'] = "Публикация документа";
$MESS ['BPPDA_DESCR_DESCR'] = "Публикация документа";
?>