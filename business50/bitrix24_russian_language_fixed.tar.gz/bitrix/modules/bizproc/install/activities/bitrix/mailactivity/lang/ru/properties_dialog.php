<?php

$MESS["BPMA_PD_CP"] = "Кодировка";
$MESS["BPMA_PD_BODY"] = "Текст сообщения";
$MESS["BPMA_PD_MESS_TYPE"] = "Тип сообщения";
$MESS["BPMA_PD_TO"] = "Получатель сообщения";
$MESS["BPMA_PD_FROM"] = "Отправитель сообщения";
$MESS["BPMA_PD_SUBJECT"] = "Тема сообщения";
$MESS["BPMA_PD_TEXT"] = "Текст";
$MESS["BPMA_PD_DIRRECT_MAIL"] = "Способ отправки";
$MESS["BPMA_PD_DIRRECT_MAIL_Y"] = "Прямая отправка";
$MESS["BPMA_PD_DIRRECT_MAIL_N"] = "Отправка через систему сообщений";
$MESS["BPMA_PD_MAIL_SITE"] = "Сайт шаблона сообщения";
$MESS["BPMA_PD_MAIL_SITE_OTHER"] = "другой";
$MESS["BPMA_PD_MAIL_SEPARATOR"] = "Разделитель почтовых адресов";
$MESS["BPMA_PD_FILE"] = "Вложения";
$MESS["BPMA_PD_FILE_SELECT"] = "выбрать";
$MESS["BPMA_PD_FROM_LIMITATION"] = "Не допускается использование E-Mail адресов, не подключенных или не подтвержденных для отправки в Битрикс24";
$MESS["BPMA_PD_TO_LIMITATION"] = "Письмо будет отправлено не более чем на 10 адресов";
