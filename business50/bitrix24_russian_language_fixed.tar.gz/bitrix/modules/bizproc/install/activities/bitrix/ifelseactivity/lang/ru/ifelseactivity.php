<?
$MESS ['BPIEA_INVALID_CHILD_1'] = "Действие типа 'IfElseActivity' может содержать в себе только действия типа 'IfElseBranchActivity'.";
?>