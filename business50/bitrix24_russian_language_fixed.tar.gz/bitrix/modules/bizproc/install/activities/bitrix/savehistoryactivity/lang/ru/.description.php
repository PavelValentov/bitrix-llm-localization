<?
$MESS ['BPSHA_DESCR_NAME'] = "Сохранение истории";
$MESS ['BPSHA_DESCR_DESCR'] = "Сохранение истории документа";
?>