<?php

$MESS ['BPWWD_DESCR_NAME'] = "Ожидание рабочего дня сотрудника";
$MESS ['BPWWD_DESCR_DESCR'] = "Ожидание рабочего дня сотрудника";
