<?
$MESS['BPSSA_ERROR_EMPTY_STATE'] = "Не указан целевой статус";
$MESS['BPSSA_CANCEL_CURRENT_STATE'] = "Прервать выполнение текущего статуса";
$MESS['BPSSA_EXECUTE_CANCEL'] = "Выполнение текущего статуса прервано";
