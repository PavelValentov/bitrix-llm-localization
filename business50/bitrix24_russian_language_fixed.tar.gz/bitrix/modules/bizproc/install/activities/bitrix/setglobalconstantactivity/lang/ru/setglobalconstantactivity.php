<?php
$MESS["BPSGCA_EMPTY_CONSTANTS"] = "Не указано значение ни одной глобальной константы";
