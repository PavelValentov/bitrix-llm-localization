<?php

$MESS['BPDDA_DESCR_NAME'] = 'Удаление документа';
$MESS['BPDDA_DESCR_ROBOT_TITLE_1'] = 'Удалить элемент';
$MESS['BPDDA_DESCR_DESCR_1'] = 'Удаляет элемент, когда больше нет необходимости его хранить';
