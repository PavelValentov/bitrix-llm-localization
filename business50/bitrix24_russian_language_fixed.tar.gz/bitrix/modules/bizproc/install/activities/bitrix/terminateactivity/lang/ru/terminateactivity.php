<?php

$MESS["BPTA1_STATE_TITLE_MSGVER_1"] = "Выполнение прервано";
$MESS["BPTA1_STATE_TITLE_NAME"] = "Текст статуса";
$MESS["BPTA1_KILL_WF_NAME"] = "Удалить данные процесса";

$MESS["BPTA1_TERMINATE"] = "Прервать процесс";
$MESS["BPTA1_TERMINATE_CURRENT"] = "Текущий";
$MESS["BPTA1_TERMINATE_ALL_EXCEPT_CURRENT"] = "Все процессы шаблона, кроме текущего";
$MESS["BPTA1_TERMINATE_ALL"] = "Все процессы шаблона";
