<?
$MESS ['BPSVA_PD_ADD'] = "Добавить условие";
$MESS ['BPSVA_PD_CALENDAR'] = "Календарь";
$MESS ['BPSVA_PD_DELETE'] = "Удалить";
$MESS ['BPSVA_PD_NO'] = "Нет";
$MESS ['BPSVA_PD_YES'] = "Да";
?>