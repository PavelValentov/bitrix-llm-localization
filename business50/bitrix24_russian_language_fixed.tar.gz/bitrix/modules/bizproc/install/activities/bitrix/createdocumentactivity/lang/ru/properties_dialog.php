<?
$MESS ['BPCDA_PD_ADD'] = "Добавить";
$MESS ['BPCDA_PD_CALENDAR'] = "Календарь";
$MESS ['BPCDA_PD_NO'] = "Нет";
$MESS ['BPCDA_PD_WRONG_TYPE'] = "Тип параметра не определен";
$MESS ['BPCDA_PD_YES'] = "Да";
?>