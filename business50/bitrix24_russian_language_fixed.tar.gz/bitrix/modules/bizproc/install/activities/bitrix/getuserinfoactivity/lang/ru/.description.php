<?php

$MESS['BPGUIA_DESCR_NAME_1'] = 'Получить информацию о сотруднике';
$MESS['BPGUIA_DESCR_DESCR_MSGVER_1'] = 'Передаёт данные о сотруднике другим роботам. Вспомогательный робот';
$MESS["BPGUIA_DESCR_TIMEMAN_STATUS"] = "Статус рабочего дня";
$MESS["BPGUIA_DESCR_IS_ABSENT"] = "Отсутствует (по графику отсутствий)";
