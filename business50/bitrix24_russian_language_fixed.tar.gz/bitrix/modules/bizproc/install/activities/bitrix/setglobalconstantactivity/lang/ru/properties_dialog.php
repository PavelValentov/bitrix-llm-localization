<?php
$MESS["BPSGCA_PD_DELETE"] = "Удалить";
$MESS["BPSGCA_PD_ADD"] = "Добавить условие";
