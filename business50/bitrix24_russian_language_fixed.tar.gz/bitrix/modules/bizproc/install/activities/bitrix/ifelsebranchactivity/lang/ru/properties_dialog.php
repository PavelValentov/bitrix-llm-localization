<?
$MESS ['BPIEBA_CONDITION'] = "Тип условия";
?>