<?
$MESS ['CPAD_DP_TIME_D'] = "дней";
$MESS ['CPAD_DP_TIME_H'] = "часов";
$MESS ['CPAD_DP_TIME_M'] = "минут";
$MESS ['CPAD_DP_TIME'] = "Время ожидания";
$MESS ['CPAD_DP_TIME_S'] = "секунд";
$MESS ['CPAD_DP_TIME_SELECT'] = "Режим";
$MESS ['CPAD_DP_TIME_SELECT_DELAY'] = "Промежуток";
$MESS ['CPAD_DP_TIME_SELECT_TIME'] = "Время";
$MESS ['CPAD_DP_TIME1'] = "Дата";
$MESS ['CPAD_PD_TIMEOUT_LIMIT'] = "Минимальное время ожидания";
$MESS ['CPAD_DP_TIME_SERVER'] = "Время сервера";
$MESS ['CPAD_DP_TIME_LOCAL'] = "Локальное время";
$MESS ['CPAD_DP_WRITE_TO_LOG'] = "Сохранять в журнал Бизнес-процесса информацию о паузах";
?>