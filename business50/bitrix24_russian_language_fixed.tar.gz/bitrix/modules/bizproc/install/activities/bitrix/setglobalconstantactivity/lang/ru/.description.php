<?php
$MESS["BPSGCA_DESCR_NAME"] = "Изменение глобальных констант";
$MESS["BPSGCA_DESCR_DESCR"] = "Позволяет изменить глобальную константу";
$MESS["BPSGCA_DESCR_ROBOT_TITLE_1"] = "Изменение глобальных констант";
