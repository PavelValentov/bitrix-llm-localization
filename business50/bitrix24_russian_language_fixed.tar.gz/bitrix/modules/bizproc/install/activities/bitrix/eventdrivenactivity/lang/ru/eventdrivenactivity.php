<?
$MESS ['BPEDA_INVALID_CHILD_1'] = "Действие типа 'EventDrivenActivity' первым поддействием должно содержать действие, реализующее интерфейс 'IBPEventDrivenActivity'.";
$MESS ['BPEDA_INVALID_CHILD_1_B24_MSGVER_1'] = "Для параллельного ожидания первым действием обязательно должна быть Пауза или Команда.";
?>