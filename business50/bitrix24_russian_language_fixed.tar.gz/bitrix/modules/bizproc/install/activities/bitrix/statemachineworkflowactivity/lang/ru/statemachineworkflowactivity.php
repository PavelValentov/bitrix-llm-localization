<?
$MESS ['BPSMWA_INVALID_CHILD'] = "Действие типа 'StateMachineWorkflowActivity' может содержать в себе только действия типа 'StateActivity'.";
$MESS ['BPSMWA_EMPTY_VAR'] = "Переменная '#NAME#' не определена";
?>