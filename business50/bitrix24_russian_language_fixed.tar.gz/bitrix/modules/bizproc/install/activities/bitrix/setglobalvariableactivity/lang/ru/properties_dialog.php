<?php

$MESS['BPSGVA_PD_DELETE'] = 'Удалить';
$MESS['BPSGVA_PD_ADD'] = 'Добавить условие';

