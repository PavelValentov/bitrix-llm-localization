<?php

$MESS ['BPSWA_COMPLETED'] = "Завершен";
$MESS ['BPSWA_IN_PROGRESS'] = "Выполняется";
