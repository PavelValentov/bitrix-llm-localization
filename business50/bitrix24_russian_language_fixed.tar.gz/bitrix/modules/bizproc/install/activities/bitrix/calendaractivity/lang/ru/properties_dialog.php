<?
$MESS ['BPSNMA_PD_CUSER'] = "Пользователь";
$MESS ['BPSNMA_PD_CNAME'] = "Название события";
$MESS ['BPSNMA_PD_CDESCR'] = "Описание события";
$MESS ['BPSNMA_PD_CFROM'] = "Дата начала";
$MESS ['BPSNMA_PD_CTO'] = "Дата окончания";
?>