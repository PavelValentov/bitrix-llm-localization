<?
$MESS ['BPCA_EMPTY_CODE'] = "PHP код для выполнения не указан";
$MESS ['BPCA_NO_PERMS'] = "У вас нет прав на изменение PHP кода";
?>