<?php

$MESS["BPWWD_DEBUG_EVENT"] = "Ожидание пропущено по событию отладчика";
$MESS["BPWWD_PROP_TARGET_USER"] = "Сотрудник";

$MESS["BPWWD_PROP_ERROR_EMPTY_USER"] = "Не указан целевой сотрудник";
$MESS["BPWWD_ERROR_EMPTY_USER"] = "Не удалось определить целевого сотрудника";
$MESS["BPWWD_SUBSCRIBE_SKIPPED"] = "Ожидание пропущено. У сотрудника открыт рабочий день";
$MESS["BPWWD_SUBSCRIBED"] = "Ожидание начала или продолжения рабочего дня сотрудника: #user#";


