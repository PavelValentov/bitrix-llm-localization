<?php
$MESS['BPSA_ERROR_MOVE_1'] = 'Вы не можете переместить действие в подчиненное этому же действию!';
$MESS['BPSA_MY_ACTIVITIES_1'] = 'Мои действия';
$MESS['BPSA_MARKETPLACE_ADD_TITLE_2'] = 'Установить из Битрикс24.Маркет';
$MESS['BPSA_MARKETPLACE_ADD_DESCR_3'] = 'Добавить действия из Битрикс24.Маркет';