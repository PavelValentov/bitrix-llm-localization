<?php
$MESS ['BPDDA_TERMINATE_CURRENT_WORKFLOW'] = 'Прервать текущий Бизнес-процесс';
$MESS ['BPDDA_DELETED_ID'] = 'Удален элемент';
