<?php

$MESS['BPSWFA_DESCR_WORKFLOW_ID'] = 'ID запущенного БП';
$MESS['BPSWFA_DESCR_NAME_1'] = 'Запустить бизнес-процесс';
$MESS['BPSWFA_DESCR_DESCR_1'] = 'Запускает бизнес-процесс по шаблону';
