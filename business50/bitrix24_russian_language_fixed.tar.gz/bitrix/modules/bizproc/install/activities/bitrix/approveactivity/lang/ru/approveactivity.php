<?php

$MESS ['BPAA_ACT_BUTTON1'] = "Утвердить документ";
$MESS ['BPAA_LOG_Y'] = "Утвержден";
$MESS ['BPAA_ACT_COMMENT'] = "Комментарий";
$MESS ['BPAA_LOG_COMMENTS'] = "Комментарий";
$MESS ['BPAA_ACT_BUTTON2_MSGVER_1'] = "Отклонить";
$MESS ['BPAA_LOG_N_MSGVER_1'] = "Отклонен";
$MESS ['BPAA_ACT_NO_ACTION'] = "Не указано действие";
$MESS ['BPAA_ACT_INFO'] = "Проголосовало #PERCENT#% (#VOTED# из #TOTAL#)";
$MESS ['BPAA_ACT_APPROVE'] = "Документ принят";
$MESS ['BPAA_ACT_NONAPPROVE'] = "Документ отклонен";
$MESS ['BPAA_ACT_TRACK2'] = "Документ должны принять все пользователи из списка: #VAL#";
$MESS ['BPAA_ACT_TRACK1'] = "Документ должен принять любой пользователь из списка: #VAL#";
$MESS ['BPAA_ACT_TRACK3'] = "Документ будет принят голосованием пользователей из списка: #VAL#";
$MESS ['BPAA_ACT_PROP_EMPTY4'] = "Свойство 'Название' не указано.";
$MESS ['BPAA_ACT_PROP_EMPTY2'] = "Свойство 'Тип одобрения' не указано.";
$MESS ['BPAA_ACT_APPROVE_TRACK'] = "Пользователь #PERSON# одобрил документ#COMMENT#";
$MESS ['BPAA_ACT_NONAPPROVE_TRACK'] = "Пользователь #PERSON# отклонил документ#COMMENT#";
$MESS ['BPAA_ACT_PROP_EMPTY1'] = "Свойство 'Пользователи' не указано.";
$MESS ['BPAA_ACT_PROP_EMPTY3'] = "Значение свойства 'Тип одобрения' не корректно.";
$MESS ['BPAA_ACT_APPROVERS_NONE'] = "нет";
$MESS ['BPAA_ACT_COMMENT_ERROR'] = "Не заполнено поле: #COMMENT_LABEL#";
