<?
$MESS["BPFEA_DESCR_DESCR"] = "Выполняет перебор значений во множественных переменных";
$MESS["BPFEA_DESCR_NAME"] = "Итератор";
$MESS["BPFEA_DESCR_RETURN_KEY"] = "Ключ";
$MESS["BPFEA_DESCR_RETURN_VALUE"] = "Значение";
?>