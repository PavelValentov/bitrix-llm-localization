<?
$MESS ['BPSNMA_DESCR_NAME'] = "Лог соц.сети";
$MESS ['BPSNMA_DESCR_DESCR'] = "Запись в лог модуля социальной сети";
?>