<?php

$MESS['BPSGVA_DESCR_NAME_MGVER_1'] = 'Изменение глобальных переменных';
$MESS['BPSGVA_DESCR_ROBOT_TITLE_2'] = 'Изменить переменную';
$MESS['BPSGVA_DESCR_DESCR_1'] = 'Изменяет параметр переменной';

