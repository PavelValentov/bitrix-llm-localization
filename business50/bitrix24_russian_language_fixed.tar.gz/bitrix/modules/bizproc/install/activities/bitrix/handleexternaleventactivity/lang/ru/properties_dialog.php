<?
$MESS ['BPHEEA_PD_NOT_SET'] = "не устанавливать";
$MESS ['BPHEEA_PD_SET_STATE'] = "После выполнения команды установить статус документа";
$MESS ['BPHEEA_PD_USERS'] = "Выполнить команду могут";
?>