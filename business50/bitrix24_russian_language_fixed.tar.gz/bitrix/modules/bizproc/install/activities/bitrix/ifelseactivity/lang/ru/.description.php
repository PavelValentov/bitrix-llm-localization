<?
$MESS ['BPIEA_DESCR_DESCR'] = "Условие";
$MESS ['BPIEA_DESCR_NAME'] = "Условие";
?>