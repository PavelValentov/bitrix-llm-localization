<?
$MESS ['STM_ADD_STATUS_1'] = "Добавить статус";
?>