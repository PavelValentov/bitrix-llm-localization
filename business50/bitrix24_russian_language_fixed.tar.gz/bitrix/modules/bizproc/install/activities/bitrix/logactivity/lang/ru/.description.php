<?
$MESS ['BPCAL_DESCR_DESCR'] = "Запись в отчет";
$MESS ['BPCAL_DESCR_NAME'] = "Запись в отчет";
$MESS ['BPCAL_DESCR_REPORT'] = "Отчет";
?>