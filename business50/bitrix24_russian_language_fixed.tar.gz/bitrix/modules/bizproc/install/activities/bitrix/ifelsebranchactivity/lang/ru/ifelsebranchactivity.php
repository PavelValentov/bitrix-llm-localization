<?
$MESS ['BPIEBA_EMPTY_TYPE'] = "Тип условия не найден";
?>