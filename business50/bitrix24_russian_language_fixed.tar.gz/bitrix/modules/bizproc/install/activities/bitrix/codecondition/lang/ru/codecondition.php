<?
$MESS ['BPCC_EMPTY_CODE'] = "PHP условие не указано";
$MESS ['BPCC_NO_PERMS'] = "У вас нет прав на изменение условия";
?>