<?
$MESS ['BPPVC_EMPTY_CONDITION'] = "Условие не указано";
?>