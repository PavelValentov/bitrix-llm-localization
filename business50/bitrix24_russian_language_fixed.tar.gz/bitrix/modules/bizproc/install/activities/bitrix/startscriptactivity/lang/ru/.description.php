<?php

$MESS['BP_SSA_DESCR_NAME'] = 'Запустить Умный сценарий';
$MESS['BP_SSA_DESCR_DESCR'] = 'Запускает Умный сценарий по шаблону';
