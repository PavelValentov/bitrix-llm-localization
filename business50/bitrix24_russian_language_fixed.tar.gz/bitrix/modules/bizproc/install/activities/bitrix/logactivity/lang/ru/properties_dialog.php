<?php

$MESS['BPCAL_PD_TEXT'] = "Текст";
$MESS['BPCAL_PD_SET_VAR'] = "Загрузить отчет для доступа из бизнес-процесса";
$MESS['BPCAL_PD_RESCTICTED_TRACKING'] = "Запись событий нужно дополнительно включить в параметрах шаблона";
