<?php

$MESS ['BPSFA_EMPTY_FIELDS'] = "Не указано значение ни одного свойства.";
$MESS ['BPSFA_ARGUMENT_NULL'] = "Не заполнено обязательное значение '#PARAM#'";
$MESS ['BPSFA_MERGE_MULTIPLE'] = "Дополнить множественные поля вместо перезаписи";
$MESS['BPSFA_MODIFIED_BY'] = "Изменять от имени";
