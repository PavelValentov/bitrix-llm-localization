<?
$MESS ['BPSWFA_PD_DOCUMENT_ID'] = "ID документа";
$MESS ['BPSWFA_PD_ENTITY'] = "Сущность";
$MESS ['BPSWFA_PD_DOCUMENT_TYPE'] = "Тип документа";
$MESS ['BPSWFA_PD_TEMPLATE'] = "Шаблон";
$MESS ['BPSWFA_PD_USE_SUBSCRIPTION'] = "Ожидать завершения бизнес-процесса";
$MESS ['BPSWFA_PD_ACCESS_DENIED_1'] = 'Настройки действия доступны только администраторам портала.';
?>