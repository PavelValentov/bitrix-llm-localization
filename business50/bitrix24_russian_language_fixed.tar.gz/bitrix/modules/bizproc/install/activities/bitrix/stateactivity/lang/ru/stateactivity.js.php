<?
$MESS ['STATEACT_BACK_1'] = "<< Вернуться к настройке статусов";
$MESS ['STATEACT_ADD'] = "Добавить";
$MESS ['STATEACT_MENU_COMMAND'] = "Команду";
$MESS ['STATEACT_MENU_DELAY'] = "Выполнение через заданное время";
$MESS ['STATEACT_EDITBP'] = "Редактировать этот бизнес-процесс";
$MESS ['STATEACT_SETT'] = "Настройки обработчика";
$MESS ['STATEACT_DEL'] = "Удалить обработчик";
$MESS ['STATEACT_MENU_INIT_1'] = "Обработчик входа в данный статус";
$MESS ['STATEACT_MENU_FIN_1'] = "Обработчик выхода из данного статуса";
?>