<?
$MESS ['BPSA_PD_PERM'] = "Право на операцию \"#OP#\" имеют";
$MESS ['BPSA_PD_PERM_REWRITE'] = "Перезаписать";
$MESS ['BPSA_PD_PERM_CLEAR'] = "Очистить";
$MESS ['BPSA_PD_PERM_HOLD'] = "Оставить";
$MESS ['BPSA_PD_PERM_CURRENT_LABEL'] = "Текущие права документа";
$MESS ['BPSA_PD_PERM_SCOPE_LABEL'] = "Область применения очистки и перезаписи";
$MESS ['BPSA_PD_PERM_SCOPE_WORFLOW'] = "Права, установленные текущим бизнес-процессом";
$MESS ['BPSA_PD_PERM_SCOPE_DOCUMENT'] = "Все права документа";
?>