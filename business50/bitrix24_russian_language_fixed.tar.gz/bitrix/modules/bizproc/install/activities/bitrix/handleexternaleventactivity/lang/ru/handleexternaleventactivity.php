<?
$MESS ['BPHEEA_TRACK'] = "Команду #EVENT# могут выполнить #VAL#";
?>