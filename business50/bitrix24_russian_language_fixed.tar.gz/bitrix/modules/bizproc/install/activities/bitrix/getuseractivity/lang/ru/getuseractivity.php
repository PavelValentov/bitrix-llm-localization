<?
$MESS ['BPARGUA_ACT_PROP_EMPTY1'] = "Свойство 'Пользователь' не указано.";
$MESS ['BPARGUA_ACT_PROP_EMPTY2'] = "Свойство 'Резервные пользователи' не указано.";
?>