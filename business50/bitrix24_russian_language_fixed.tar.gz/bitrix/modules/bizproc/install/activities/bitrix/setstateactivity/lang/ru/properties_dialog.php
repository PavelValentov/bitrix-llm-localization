<?
$MESS ['BPSFA_PD_STATE'] = "Перевести в статус";
$MESS ['BPSFA_PD_OTHER'] = "(другое)";
?>