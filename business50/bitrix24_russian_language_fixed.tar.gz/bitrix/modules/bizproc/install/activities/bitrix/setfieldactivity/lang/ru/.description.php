<?php

$MESS['BPSFA_DESCR_NAME_MGVER_1'] = 'Изменение документа';
$MESS['BPSFA_DESCR_DESCR_1'] = 'Изменяет или добавляет нужные данные в поля элемента';
$MESS['BPSFA_DESCR_ROBOT_TITLE_2'] = 'Изменить элемент';
$MESS['BPSFA_DESCR_ERROR_MESSAGE'] = "Текст ошибки изменения";
