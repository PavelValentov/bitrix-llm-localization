<?php

$MESS['BP_SSA_ACTIVITY_INCORRECT_TEMPLATE_ID'] = 'Некорректный ID шаблона';
$MESS['BP_SSA_ACTIVITY_EMPTY_DOCUMENT_ID'] = 'Не заполнен ID элемента';
$MESS['BP_SSA_ACTIVITY_EMPTY_START_BY'] = 'Не заполнено обязательное поле «Запустить от пользователя»';
$MESS['BP_SSA_ACTIVITY_TEMPLATE_PARAMETERS_ERROR'] = 'Не заполнен обязательный параметр «#NAME#«';
$MESS['BP_SSA_ACTIVITY_NOT_FOUND_TEMPLATE'] = 'Умный сценарий не найден или выключен';
$MESS['BP_SSA_ACTIVITY_NOT_FOUND_DOCUMENT'] = 'Элемент с таким ID не найден';
$MESS['BP_SSA_ACTIVITY_NOT_MATCH_DOCUMENT_TYPE'] = 'Указанный ID элемента не соответствует типу элементов, с которыми могут работать Умные сценарии';
$MESS['BP_SSA_ACTIVITY_LOOPING_ERROR'] = 'Рекурсивный запуск Умного сценария заблокирован';
$MESS['BP_SSA_ACTIVITY_MAP_DOCUMENT_ID'] = 'ID элемента';
$MESS['BP_SSA_ACTIVITY_MAP_TEMPLATE_ID'] = 'Умный сценарий';
$MESS['BP_SSA_ACTIVITY_MAP_START_BY'] = 'Запустить от пользователя';
$MESS['BP_SSA_ACTIVITY_MAP_PARAMETERS'] = 'Параметры запуска Умного сценария';
$MESS['BP_SSA_ACTIVITY_MAP_PARAMETERS_HIDDEN'] = 'Недостаточно прав для изменения настроек текущего Умного сценария';
$MESS['BP_SSA_ACTIVITY_VALIDATE_EMPTY_DOCUMENT_ID'] = 'Не заполнено обязательное поле «ID элемента»';
$MESS['BP_SSA_ACTIVITY_VALIDATE_EMPTY_TEMPLATE_ID'] = 'Не заполнено обязательное поле «Умный сценарий»';
$MESS['BP_SSA_ACTIVITY_VALIDATE_EMPTY_START_BY'] = 'Не заполнено обязательное поле «Запустить от пользователя»';
$MESS['BP_SSA_ACTIVITY_LIMIT_DOCUMENT_IDS'] = 'Превышен лимит запусков Умных сценариев';
$MESS['BP_SSA_ACTIVITY_LIMIT_QUEUE'] = 'Этот умный сценарий еще не завершен, вы не можете включить его второй раз';
