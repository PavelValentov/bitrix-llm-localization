<?
$MESS ['BPRIOA_OK'] = "Ок";
$MESS ['BPRIOA_CANCEL'] = "Отмена";
?>