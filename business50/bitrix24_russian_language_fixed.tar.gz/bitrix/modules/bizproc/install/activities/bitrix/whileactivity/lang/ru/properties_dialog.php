<?
$MESS ['BPWA_PD_TYPE'] = "Тип условия";
?>