<?
$MESS ['BPUPDA_DESCR_NAME'] = "Снятие документа с публикации";
$MESS ['BPUPDA_DESCR_DESCR'] = "Снятие документа с публикации";
?>