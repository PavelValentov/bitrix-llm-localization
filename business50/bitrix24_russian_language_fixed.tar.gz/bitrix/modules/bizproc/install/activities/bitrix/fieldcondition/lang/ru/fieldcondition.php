<?
$MESS ['BPFC_NO_WHERE'] = "Условие не указано";
?>