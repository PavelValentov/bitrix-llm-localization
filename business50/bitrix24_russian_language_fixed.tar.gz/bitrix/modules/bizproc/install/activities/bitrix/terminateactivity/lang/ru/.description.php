<?php

$MESS["BPTA1_DESCR_DESCR"] = "Прерывание выполнения бизнес-процесса";
$MESS["BPTA1_DESCR_NAME"] = "Прерывание процесса";
