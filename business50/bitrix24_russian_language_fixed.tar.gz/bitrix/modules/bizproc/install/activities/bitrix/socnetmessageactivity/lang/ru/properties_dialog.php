<?
$MESS ['BPSNMA_PD_MESSAGE'] = "Текст сообщения";
$MESS ['BPSNMA_PD_TO'] = "Получатель сообщения";
$MESS ['BPSNMA_PD_FROM'] = "Отправитель сообщения";
?>