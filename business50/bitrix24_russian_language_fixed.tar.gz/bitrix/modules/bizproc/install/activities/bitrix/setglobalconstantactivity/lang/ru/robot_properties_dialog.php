<?php
$MESS["BIZPROC_AUTOMATION_SGCA_CONSTANTS_LIST"] = "Выбрать глобальную константу";
$MESS["BIZPROC_AUTOMATION_SGCA_DELETE"] = "Удалить";
