<?php
$MESS["BPMA_EMPTY_PROP4"] = "Свойство 'Кодировка сообщения' не указано.";
$MESS["BPMA_EMPTY_PROP7"] = "Свойство 'Текст сообщения' не указано.";
$MESS["BPMA_EMPTY_PROP6"] = "Значение свойства 'Тип сообщения' не корректно.";
$MESS["BPMA_EMPTY_PROP5"] = "Свойство 'Тип сообщения' не указано.";
$MESS["BPMA_EMPTY_PROP2"] = "Свойство 'Получатель' не указано.";
$MESS["BPMA_EMPTY_PROP1"] = "Свойство 'Отправитель' не указано.";
$MESS["BPMA_EMPTY_PROP3"] = "Свойство 'Тема сообщения' не указано.";
$MESS["BPMA_ATTACHMENT_1"] = "Файлы";
$MESS["BPMA_ATTACHMENT_TYPE_1"] = "Расположение";
$MESS["BPMA_ATTACHMENT_FILE_1"] = "Поля элемента";
$MESS["BPMA_ATTACHMENT_DISK_1"] = "Диск";
$MESS["BPMA_MAIL_USER_FROM"] = "От кого";
$MESS["BPMA_MAIL_SUBJECT"] = "Тема";
$MESS["BPMA_MAIL_USER_TO"] = "Кому";
$MESS['BPMA_MAIL_TEXT'] = 'Текст сообщения';
