<?
$MESS ['BPLDA_DESCR_DESCR'] = "Блокировка документа";
$MESS ['BPLDA_DESCR_NAME'] = "Блокировка документа";
?>