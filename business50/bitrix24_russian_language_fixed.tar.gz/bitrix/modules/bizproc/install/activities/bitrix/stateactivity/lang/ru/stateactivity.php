<?
$MESS ['BPSA_INVALID_CHILD_1'] = "Действие типа 'StateActivity' может содержать в себе только действия типа 'StateInitializationActivity', 'StateFinalizationActivity' или 'EventDrivenActivity'.";
$MESS ['BPSA_TRACK_1'] = "Права на документ в этом статусе #VAL#";
$MESS ['BPSA_EMPTY_PERMS_1'] = "Не указаны права на операции над документом в данном статусе.";
?>