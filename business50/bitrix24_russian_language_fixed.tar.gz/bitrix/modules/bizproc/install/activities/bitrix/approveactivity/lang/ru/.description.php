<?
$MESS ['BPAA_DESCR_DESCR'] = "Утверждение документа";
$MESS ['BPAA_DESCR_NAME'] = "Утверждение документа";
$MESS ['BPAA_DESCR_VC'] = "Сколько проголосовало";
$MESS ['BPAA_DESCR_TC'] = "Сколько должно проголосовать";
$MESS ['BPAA_DESCR_VP'] = "Процент проголосовавших";
$MESS ['BPAA_DESCR_AP'] = "Процент утвердивших";
$MESS ['BPAA_DESCR_NAP'] = "Процент отклонивших";
$MESS ['BPAA_DESCR_AC'] = "Количество утвердивших";
$MESS ['BPAA_DESCR_NAC'] = "Количество отклонивших";
$MESS ['BPAA_DESCR_LA'] = "Последний голосовавший";
$MESS ['BPAA_DESCR_LA_COMMENT'] = "Комментарий последнего голосовавшего";
$MESS ['BPAA_DESCR_TA1'] = "Автоматическое отклонение";
$MESS ['BPAA_DESCR_CM'] = "Комментарии";
$MESS ['BPAA_DESCR_APPROVERS'] = "Утвердили пользователи";
$MESS ['BPAA_DESCR_APPROVERS_STRING'] = "Утвердили пользователи (текст)";
$MESS ['BPAA_DESCR_REJECTERS'] = "Отклонили пользователи";
$MESS ['BPAA_DESCR_REJECTERS_STRING'] = "Отклонили пользователи (текст)";
$MESS ['BPAA_DESCR_TASKS'] = 'Задания';
?>