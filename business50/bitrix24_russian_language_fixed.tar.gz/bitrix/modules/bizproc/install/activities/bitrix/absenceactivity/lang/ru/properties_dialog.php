<?
$MESS ['BPSNAA2_PD_CUSER'] = "Пользователь";
$MESS ['BPSNAA2_PD_CNAME'] = "Название события";
$MESS ['BPSNAA2_PD_CDESCR'] = "Описание события";
$MESS ['BPSNAA2_PD_CFROM'] = "Дата начала";
$MESS ['BPSNAA2_PD_CTO'] = "Дата окончания";
$MESS ['BPSNAA2_PD_CSTATE'] = "Состояние";
$MESS ['BPSNAA2_PD_CFSTATE'] = "Состояние завершения";
$MESS ['BPSNAA2_PD_CTYPES'] = "Тип отсутствия";
?>