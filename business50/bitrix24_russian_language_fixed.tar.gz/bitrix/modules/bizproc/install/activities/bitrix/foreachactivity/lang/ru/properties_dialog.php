<?php

$MESS['BPFEA_PD_SOURCE'] = 'Источник';
