<?
$MESS["BPGUA_DESCR_DESCR"] = "Выбор сотрудника";
$MESS["BPGUA_DESCR_NAME"] = "Выбор сотрудника";
$MESS["BPGUA_DESCR_RU"] = "Выбранный сотрудник";
?>