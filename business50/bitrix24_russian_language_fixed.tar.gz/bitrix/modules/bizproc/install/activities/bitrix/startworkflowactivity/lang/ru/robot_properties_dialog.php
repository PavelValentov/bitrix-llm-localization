<?php
$MESS ['BPSWFA_RPD_DOCUMENT_ID'] = "ID документа";
$MESS ['BPSWFA_RPD_ENTITY'] = "Сущность";
$MESS ['BPSWFA_RPD_DOCUMENT_TYPE_1'] = "Тип элемента";
$MESS ['BPSWFA_RPD_TEMPLATE'] = "Шаблон";
$MESS ['BPSWFA_RPD_USE_SUBSCRIPTION'] = "Ожидать завершения бизнес-процесса";
$MESS ['BPSWFA_RPD_ACCESS_DENIED_1'] = 'Настройки действия доступны только администраторам портала.';