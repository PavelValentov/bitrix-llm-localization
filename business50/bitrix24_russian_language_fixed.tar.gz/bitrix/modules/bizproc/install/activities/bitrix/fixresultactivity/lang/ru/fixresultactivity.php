<?php

$MESS['BP_FRA_RESULT_TYPE'] = 'Результат бизнес-процесса:';
$MESS['BP_FRA_RESULT_CREATED_ITEM'] = 'Элемент, поле или файл';
$MESS['BP_FRA_RESULT_POSITIVE_RESULT'] = 'Бизнес-процесс завершён для сотрудника';
$MESS['BP_FRA_RESULT_VALUE'] = 'Результат бизнес-процесса:';
$MESS['BP_FRA_RESULT_USER'] = 'Сотрудник:';
$MESS['BP_FRA_RESULT_SELECT_RESULT'] = 'Укажите результат';
$MESS['BP_FRA_RESULT_EXTRACT_ERROR'] = 'Не удалось получить данные';
$MESS['BP_FRA_RESULT_WHO_CAN_VIEW_RESULT'] = 'Кто сможет видеть результат:';
$MESS['BP_FRA_RESULT_ONLY_AUTHOR_CAN'] = 'Кто запустил бизнес-процесс';
$MESS['BP_FRA_RESULT_ALL_PARTICIPANTS_CAN'] = 'Все участники бизнес-процесса';
$MESS['BP_FRA_RESULT_SELECTED_USERS_CAN'] = 'Другие сотрудники';
$MESS['BP_FRA_RESULT_SELECT_USERS'] = 'Список сотрудников:';
