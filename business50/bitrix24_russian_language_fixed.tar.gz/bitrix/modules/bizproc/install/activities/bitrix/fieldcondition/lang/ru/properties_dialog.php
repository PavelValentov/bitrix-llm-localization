<?php

$MESS ['BPFC_PD_ADD'] = "Добавить условие";
$MESS ['BPFC_PD_AND'] = "И";
$MESS ['BPFC_PD_OR'] = "ИЛИ";
$MESS ['BPFC_PD_CALENDAR'] = "Календарь";
$MESS ['BPFC_PD_CONDITION'] = "Условие";
$MESS ['BPFC_PD_DELETE'] = "Удалить";
$MESS ['BPFC_PD_FIELD'] = "Поле документа";
$MESS ['BPFC_PD_NO'] = "Нет";
$MESS ['BPFC_PD_YES'] = "Да";
