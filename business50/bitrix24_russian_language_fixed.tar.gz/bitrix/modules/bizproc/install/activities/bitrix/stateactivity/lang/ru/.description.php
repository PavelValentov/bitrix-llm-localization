<?
$MESS ['BPSA_DESCR_DESCR'] = "Статус документа с определением прав доступа к нему.";
$MESS ['BPSA_DESCR_NAME'] = "Статус";
?>