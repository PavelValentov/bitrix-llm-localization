<?
$MESS ['BPCA_PD_PHP'] = "PHP код";
?>