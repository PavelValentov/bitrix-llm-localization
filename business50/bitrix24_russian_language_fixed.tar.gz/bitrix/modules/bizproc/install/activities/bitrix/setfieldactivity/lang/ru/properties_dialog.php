<?
$MESS ['BPSFA_PD_ADD'] = "Добавить условие";
$MESS ['BPSFA_PD_CALENDAR'] = "Календарь";
$MESS ['BPSFA_PD_DELETE'] = "Удалить";
$MESS ['BPSFA_PD_NO'] = "Нет";
$MESS ['BPSFA_PD_YES'] = "Да";
$MESS ['BPSFA_PD_CREATE'] = "Добавить поле";
$MESS ['BPSFA_PD_EMPTY_NAME'] = "Не указано название поля";
$MESS ['BPSFA_PD_EMPTY_CODE'] = "Не указан код поля";
$MESS ['BPSFA_PD_WRONG_CODE'] = "Код поля может содержать только латинские буквы и цифры и не может начинаться с цифры";
$MESS ['BPSFA_PD_FIELD'] = "Поле";
$MESS ['BPSFA_PD_F_NAME'] = "Название";
$MESS ['BPSFA_PD_F_CODE'] = "Код";
$MESS ['BPSFA_PD_F_TYPE'] = "Тип";
$MESS ['BPSFA_PD_F_MULT'] = "Множественное";
$MESS ['BPSFA_PD_F_REQ'] = "Обязательное";
$MESS ['BPSFA_PD_F_LIST'] = "Список значений";
$MESS ['BPSFA_PD_SAVE'] = "Сохранить";
$MESS ['BPSFA_PD_SAVE_HINT'] = "Создать поле";
$MESS ['BPSFA_PD_CANCEL'] = "Отмена";
$MESS ['BPSFA_PD_CANCEL_HINT'] = "Отмена";
$MESS ['BPSFA_PD_MODIFIED_BY'] = "Изменять от имени";
?>