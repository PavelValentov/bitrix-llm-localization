<?
$MESS ['BPHEEA_DESCR_DESCR_MSGVER_1'] = "Запуск команды, которая также является отдельным бизнес-процессом";
$MESS ['BPHEEA_DESCR_NAME_MSGVER_1'] = "Команда";
$MESS ['BPAA_DESCR_SENDER_USER_ID_MSGVER_1'] = "Пользователь, отправивший команду";
?>